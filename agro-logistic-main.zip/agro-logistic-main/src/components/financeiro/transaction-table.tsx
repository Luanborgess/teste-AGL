"use client";

import { ArrowDownUp, ChevronLeft, ChevronRight, Eye, Pencil, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { EmptyFinancialState } from "@/components/financeiro/empty-financial-state";
import type { FinancialTransaction } from "@/lib/financeiro";
import { transactionTypeLabels } from "@/lib/financeiro";
import { formatCurrencyBRL, formatDateBR } from "@/lib/formatters";
import { cn } from "@/lib/utils";

export type TransactionSortKey = "date" | "amount";
export type TransactionSortDirection = "asc" | "desc";

function typeBadgeClass(type: FinancialTransaction["type"]) {
  if (type === "RECEITA") {
    return "border-emerald-500/20 bg-emerald-500/10 text-emerald-300";
  }

  if (type === "DESPESA") {
    return "border-red-500/20 bg-red-500/10 text-red-300";
  }

  return "border-sky-500/20 bg-sky-500/10 text-sky-300";
}

function amountClass(type: FinancialTransaction["type"]) {
  if (type === "RECEITA") {
    return "text-emerald-300";
  }

  if (type === "DESPESA") {
    return "text-red-300";
  }

  return "text-sky-300";
}

function amountLabel(transaction: FinancialTransaction) {
  if (transaction.type === "RECEITA") {
    return `+ ${formatCurrencyBRL(transaction.amount)}`;
  }

  if (transaction.type === "DESPESA") {
    return `- ${formatCurrencyBRL(transaction.amount)}`;
  }

  return formatCurrencyBRL(transaction.amount);
}

export function TransactionTable({
  transactions,
  totalResults,
  page,
  totalPages,
  sortKey,
  sortDirection,
  onSort,
  onPageChange,
  onCreate,
  onView,
  onEdit,
  onDelete,
}: {
  transactions: FinancialTransaction[];
  totalResults: number;
  page: number;
  totalPages: number;
  sortKey: TransactionSortKey;
  sortDirection: TransactionSortDirection;
  onSort: (key: TransactionSortKey) => void;
  onPageChange: (page: number) => void;
  onCreate: () => void;
  onView: (transaction: FinancialTransaction) => void;
  onEdit: (transaction: FinancialTransaction) => void;
  onDelete: (transaction: FinancialTransaction) => void;
}) {
  if (totalResults === 0) {
    return (
      <EmptyFinancialState
        title="Sem resultados"
        description="Nenhuma transacao corresponde aos filtros aplicados."
        onCreate={onCreate}
      />
    );
  }

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <CardTitle className="text-base">Transacoes</CardTitle>
          <p className="mt-1 text-sm text-muted-foreground">{totalResults} registro(s) encontrados</p>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead>
                <Button variant="ghost" size="sm" className="-ml-2" onClick={() => onSort("date")}>
                  Data
                  <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "date" && "text-emerald-300")} />
                </Button>
              </TableHead>
              <TableHead>Descricao</TableHead>
              <TableHead>Categoria</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" size="sm" className="-mr-2" onClick={() => onSort("amount")}>
                  Valor
                  <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "amount" && "text-emerald-300")} />
                </Button>
              </TableHead>
              <TableHead className="text-right">Acoes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {transactions.map((transaction) => (
              <TableRow key={transaction.id} className="border-foreground/10">
                <TableCell className="font-mono text-xs text-muted-foreground">
                  {formatDateBR(transaction.date)}
                </TableCell>
                <TableCell>
                  <div className="max-w-64">
                    <p className="truncate font-medium">{transaction.description}</p>
                    {transaction.notes ? (
                      <p className="truncate text-xs text-muted-foreground">{transaction.notes}</p>
                    ) : null}
                  </div>
                </TableCell>
                <TableCell className="text-muted-foreground">{transaction.category}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={typeBadgeClass(transaction.type)}>
                    {transactionTypeLabels[transaction.type]}
                  </Badge>
                </TableCell>
                <TableCell className={cn("text-right font-mono font-medium", amountClass(transaction.type))}>
                  {amountLabel(transaction)}
                </TableCell>
                <TableCell>
                  <div className="flex justify-end gap-1">
                    <Button variant="ghost" size="icon-sm" title="Visualizar" onClick={() => onView(transaction)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon-sm" title="Editar" onClick={() => onEdit(transaction)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon-sm" title="Excluir" onClick={() => onDelete(transaction)}>
                      <Trash2 className="h-4 w-4 text-red-300" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        <div className="mt-4 flex flex-col gap-3 border-t border-foreground/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-muted-foreground">
            Pagina {page} de {totalPages} - ordenado por {sortKey === "date" ? "data" : "valor"} (
            {sortDirection === "desc" ? "desc" : "asc"})
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => onPageChange(page - 1)} disabled={page <= 1}>
              <ChevronLeft className="h-4 w-4" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" onClick={() => onPageChange(page + 1)} disabled={page >= totalPages}>
              Proxima
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
