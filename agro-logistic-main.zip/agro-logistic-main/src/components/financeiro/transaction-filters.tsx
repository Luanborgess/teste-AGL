"use client";

import { Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { TransactionTypeValue } from "@/lib/validations";

export type TransactionFiltersState = {
  search: string;
  type: "ALL" | TransactionTypeValue;
  category: "ALL" | string;
};

export function TransactionFilters({
  filters,
  categories,
  onChange,
  onReset,
}: {
  filters: TransactionFiltersState;
  categories: string[];
  onChange: (filters: TransactionFiltersState) => void;
  onReset: () => void;
}) {
  return (
    <div className="grid gap-3 rounded-xl border border-foreground/10 bg-card/70 p-3 md:grid-cols-[1fr_12rem_14rem_auto]">
      <label className="relative block">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          className="pl-8"
          placeholder="Buscar descricao ou categoria"
          value={filters.search}
          onChange={(event) => onChange({ ...filters, search: event.target.value })}
        />
      </label>

      <Select
        value={filters.type}
        onValueChange={(type) => onChange({ ...filters, type: type as TransactionFiltersState["type"] })}
      >
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Tipo" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="ALL">Todos os tipos</SelectItem>
          <SelectItem value="RECEITA">Receita</SelectItem>
          <SelectItem value="DESPESA">Despesa</SelectItem>
          <SelectItem value="INVESTIMENTO">Investimento</SelectItem>
        </SelectContent>
      </Select>

      <Select
        value={filters.category}
        onValueChange={(category) => onChange({ ...filters, category })}
      >
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Categoria" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="ALL">Todas as categorias</SelectItem>
          {categories.map((category) => (
            <SelectItem key={category} value={category}>
              {category}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Button variant="outline" onClick={onReset}>
        <X className="h-4 w-4" />
        Limpar
      </Button>
    </div>
  );
}
