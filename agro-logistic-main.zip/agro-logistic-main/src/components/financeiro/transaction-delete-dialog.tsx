"use client";

import { Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { FinancialTransaction } from "@/lib/financeiro";
import { formatCurrencyBRL } from "@/lib/formatters";

export function TransactionDeleteDialog({
  transaction,
  deleting,
  onOpenChange,
  onConfirm,
}: {
  transaction: FinancialTransaction | null;
  deleting: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => Promise<void>;
}) {
  return (
    <Dialog open={Boolean(transaction)} onOpenChange={onOpenChange}>
      <DialogContent className="border-red-500/15 bg-popover/95 sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Excluir transacao</DialogTitle>
          <DialogDescription>
            Esta acao nao pode ser desfeita. A transacao sera removida do banco e os indicadores serao recalculados.
          </DialogDescription>
        </DialogHeader>

        {transaction ? (
          <div className="rounded-xl border border-red-500/15 bg-red-500/10 p-4 text-sm">
            <p className="font-medium">{transaction.description}</p>
            <p className="mt-1 text-muted-foreground">
              {transaction.category} - {formatCurrencyBRL(transaction.amount)}
            </p>
          </div>
        ) : null}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={deleting}>
            Cancelar
          </Button>
          <Button variant="destructive" onClick={onConfirm} disabled={deleting}>
            {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            {deleting ? "Excluindo..." : "Excluir"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
