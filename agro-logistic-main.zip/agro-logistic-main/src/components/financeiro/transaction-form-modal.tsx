"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import type { FinancialTransaction } from "@/lib/financeiro";
import { transactionSchema, type TransactionInput, type TransactionValues } from "@/lib/validations";

type TransactionModalMode = "create" | "edit" | "view";

const emptyValues: TransactionInput = {
  description: "",
  amount: 0,
  category: "",
  type: "RECEITA",
  date: new Date().toISOString().slice(0, 10),
  notes: "",
};

function valuesFromTransaction(transaction: FinancialTransaction | null): TransactionInput {
  if (!transaction) {
    return emptyValues;
  }

  return {
    description: transaction.description,
    amount: transaction.amount,
    category: transaction.category,
    type: transaction.type,
    date: new Date(transaction.date).toISOString().slice(0, 10),
    notes: transaction.notes ?? "",
  };
}

export function TransactionFormModal({
  open,
  mode,
  transaction,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  mode: TransactionModalMode;
  transaction: FinancialTransaction | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: TransactionValues) => Promise<void>;
}) {
  const readOnly = mode === "view";
  const form = useForm<TransactionInput, unknown, TransactionValues>({
    resolver: zodResolver(transactionSchema),
    defaultValues: valuesFromTransaction(transaction),
  });
  const selectedType = useWatch({ control: form.control, name: "type" });

  useEffect(() => {
    if (open) {
      form.reset(valuesFromTransaction(transaction));
    }
  }, [form, open, transaction]);

  async function submit(values: TransactionValues) {
    if (readOnly) {
      return;
    }

    await onSubmit(values);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {mode === "create" ? "Nova transacao" : mode === "edit" ? "Editar transacao" : "Detalhes da transacao"}
          </DialogTitle>
          <DialogDescription>
            {readOnly
              ? "Confira os dados salvos no financeiro."
              : "Registre valores reais da operacao. Os indicadores serao recalculados automaticamente."}
          </DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Descricao" error={form.formState.errors.description?.message} className="md:col-span-2">
            <TextInput disabled={readOnly || saving} placeholder="Venda de soja" {...form.register("description")} />
          </Field>

          <Field label="Valor" error={form.formState.errors.amount?.message}>
            <TextInput
              disabled={readOnly || saving}
              type="number"
              min="0"
              step="0.01"
              placeholder="100000"
              {...form.register("amount")}
            />
          </Field>

          <Field label="Categoria" error={form.formState.errors.category?.message}>
            <TextInput disabled={readOnly || saving} placeholder="Vendas, Insumos, Maquinas..." {...form.register("category")} />
          </Field>

          <Field label="Tipo" error={form.formState.errors.type?.message}>
            <Select
              disabled={readOnly || saving}
              value={selectedType}
              onValueChange={(value) => form.setValue("type", value as TransactionValues["type"], { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="RECEITA">Receita</SelectItem>
                <SelectItem value="DESPESA">Despesa</SelectItem>
                <SelectItem value="INVESTIMENTO">Investimento</SelectItem>
              </SelectContent>
            </Select>
          </Field>

          <Field label="Data" error={form.formState.errors.date?.message}>
            <TextInput disabled={readOnly || saving} type="date" {...form.register("date")} />
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput
              disabled={readOnly || saving}
              placeholder="Contrato, fornecedor, condicoes de pagamento..."
              {...form.register("notes")}
            />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              {readOnly ? "Fechar" : "Cancelar"}
            </Button>
            {!readOnly ? (
              <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {saving ? "Salvando..." : "Salvar"}
              </Button>
            ) : null}
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
