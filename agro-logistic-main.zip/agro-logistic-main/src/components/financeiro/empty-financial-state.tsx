"use client";

import { CircleDollarSign, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

export function EmptyFinancialState({
  title = "Nenhuma transacao financeira",
  description = "Cadastre receitas, despesas e investimentos para acompanhar o fluxo de caixa real da operacao.",
  onCreate,
}: {
  title?: string;
  description?: string;
  onCreate?: () => void;
}) {
  return (
    <div className="flex min-h-72 flex-col items-center justify-center rounded-xl border border-dashed border-emerald-500/20 bg-card/55 p-8 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-emerald-400/25 bg-emerald-500/10 text-emerald-300">
        <CircleDollarSign className="h-5 w-5" />
      </div>
      <h3 className="mt-4 text-base font-semibold">{title}</h3>
      <p className="mt-2 max-w-md text-sm text-muted-foreground">{description}</p>
      {onCreate ? (
        <Button className="mt-5 bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={onCreate}>
          <Plus className="h-4 w-4" />
          Nova transacao
        </Button>
      ) : null}
    </div>
  );
}
