"use client";

import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrencyBRL } from "@/lib/formatters";
import type { MonthlyFinancialData } from "@/lib/financeiro";

export function FinancialChart({ data }: { data: MonthlyFinancialData[] }) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-base">Fluxo mensal</CardTitle>
          <p className="mt-1 text-sm text-muted-foreground">Valores agrupados por mes a partir das transacoes salvas.</p>
        </div>
      </CardHeader>
      <CardContent className="h-[22rem]">
        <ResponsiveContainer width="100%" height="100%" minWidth={0}>
          <ComposedChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} vertical={false} />
            <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} />
            <YAxis
              tickLine={false}
              axisLine={false}
              fontSize={12}
              tickFormatter={(value) => `${Number(value) / 1000}k`}
            />
            <Tooltip
              cursor={{ fill: "rgba(255,255,255,0.04)" }}
              contentStyle={{
                background: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "12px",
                color: "hsl(var(--popover-foreground))",
              }}
              formatter={(value, name) => [formatCurrencyBRL(Number(value)), String(name)]}
            />
            <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
            <Bar name="Receitas" dataKey="receita" fill="#10b981" radius={[8, 8, 0, 0]} animationDuration={500} />
            <Bar name="Despesas" dataKey="despesa" fill="#ef4444" radius={[8, 8, 0, 0]} animationDuration={500} />
            <Line
              name="Investimentos"
              type="monotone"
              dataKey="investimento"
              stroke="#38bdf8"
              strokeWidth={3}
              dot={{ r: 3, fill: "#38bdf8", strokeWidth: 0 }}
              activeDot={{ r: 5 }}
              animationDuration={500}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
