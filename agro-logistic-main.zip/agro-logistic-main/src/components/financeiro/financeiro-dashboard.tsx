"use client";

import { Download, Plus, RefreshCw } from "lucide-react";
import dynamic from "next/dynamic";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { EmptyFinancialState } from "@/components/financeiro/empty-financial-state";
import { FinancialSummaryCards } from "@/components/financeiro/financial-summary-cards";
import { TransactionDeleteDialog } from "@/components/financeiro/transaction-delete-dialog";
import { TransactionFilters, type TransactionFiltersState } from "@/components/financeiro/transaction-filters";
import { TransactionFormModal } from "@/components/financeiro/transaction-form-modal";
import {
  TransactionTable,
  type TransactionSortDirection,
  type TransactionSortKey,
} from "@/components/financeiro/transaction-table";
import {
  buildFinancialChartData,
  calculateFinancialTotals,
  getTransactionCategories,
  transactionTypeLabels,
  type FinancialTransaction,
} from "@/lib/financeiro";
import { formatCurrencyBRL, formatDateBR } from "@/lib/formatters";
import type { TransactionValues } from "@/lib/validations";

const pageSize = 8;

const FinancialChart = dynamic(
  () => import("@/components/financeiro/financial-chart").then((mod) => mod.FinancialChart),
  {
    ssr: false,
    loading: () => <div className="h-[22rem] animate-pulse rounded-xl border border-foreground/10 bg-card/70" />,
  },
);

function normalizeTransaction(transaction: FinancialTransaction): FinancialTransaction {
  return {
    ...transaction,
    date: new Date(transaction.date).toISOString(),
    createdAt: transaction.createdAt ? new Date(transaction.createdAt).toISOString() : undefined,
    updatedAt: transaction.updatedAt ? new Date(transaction.updatedAt).toISOString() : undefined,
  };
}

function getApiError(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string") {
    return payload.error;
  }

  return fallback;
}

function toCsvValue(value: string | number) {
  const text = String(value).replace(/"/g, '""');
  return `"${text}"`;
}

export function FinanceiroDashboard({ initialTransactions }: { initialTransactions: FinancialTransaction[] }) {
  const [transactions, setTransactions] = useState(() => initialTransactions.map(normalizeTransaction));
  const [filters, setFilters] = useState<TransactionFiltersState>({ search: "", type: "ALL", category: "ALL" });
  const [sortKey, setSortKey] = useState<TransactionSortKey>("date");
  const [sortDirection, setSortDirection] = useState<TransactionSortDirection>("desc");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalMode, setModalMode] = useState<"create" | "edit" | "view">("create");
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<FinancialTransaction | null>(null);
  const [transactionToDelete, setTransactionToDelete] = useState<FinancialTransaction | null>(null);

  const totals = useMemo(() => calculateFinancialTotals(transactions), [transactions]);
  const chartData = useMemo(() => buildFinancialChartData(transactions), [transactions]);
  const categories = useMemo(() => getTransactionCategories(transactions), [transactions]);

  const filteredTransactions = useMemo(() => {
    const search = filters.search.trim().toLocaleLowerCase("pt-BR");

    return transactions
      .filter((transaction) => {
        const matchesSearch =
          !search ||
          transaction.description.toLocaleLowerCase("pt-BR").includes(search) ||
          transaction.category.toLocaleLowerCase("pt-BR").includes(search);
        const matchesType = filters.type === "ALL" || transaction.type === filters.type;
        const matchesCategory = filters.category === "ALL" || transaction.category === filters.category;

        return matchesSearch && matchesType && matchesCategory;
      })
      .sort((a, b) => {
        const aValue = sortKey === "date" ? new Date(a.date).getTime() : a.amount;
        const bValue = sortKey === "date" ? new Date(b.date).getTime() : b.amount;
        return sortDirection === "desc" ? bValue - aValue : aValue - bValue;
      });
  }, [filters, sortDirection, sortKey, transactions]);

  const totalPages = Math.max(1, Math.ceil(filteredTransactions.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginatedTransactions = filteredTransactions.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  async function loadTransactions() {
    setLoading(true);
    setError(null);

    const response = await fetch("/api/financeiro/transactions", { cache: "no-store" });
    const payload = await response.json().catch(() => null);
    setLoading(false);

    if (!response.ok) {
      const message = getApiError(payload, "Nao foi possivel carregar as transacoes.");
      setError(message);
      toast.error(message);
      return;
    }

    setTransactions((payload.transactions as FinancialTransaction[]).map(normalizeTransaction));
  }

  function openCreateModal() {
    setSelectedTransaction(null);
    setModalMode("create");
    setModalOpen(true);
  }

  function openEditModal(transaction: FinancialTransaction) {
    setSelectedTransaction(transaction);
    setModalMode("edit");
    setModalOpen(true);
  }

  function openViewModal(transaction: FinancialTransaction) {
    setSelectedTransaction(transaction);
    setModalMode("view");
    setModalOpen(true);
  }

  async function saveTransaction(values: TransactionValues) {
    setSaving(true);

    const isEdit = modalMode === "edit" && selectedTransaction;
    const response = await fetch(
      isEdit ? `/api/financeiro/transactions/${selectedTransaction.id}` : "/api/financeiro/transactions",
      {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      },
    );
    const payload = await response.json().catch(() => null);
    setSaving(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel salvar a transacao."));
      return;
    }

    toast.success(isEdit ? "Transacao atualizada." : "Transacao criada.");
    setModalOpen(false);
    setSelectedTransaction(null);
    await loadTransactions();
  }

  async function deleteTransaction() {
    if (!transactionToDelete) {
      return;
    }

    setDeleting(true);
    const response = await fetch(`/api/financeiro/transactions/${transactionToDelete.id}`, {
      method: "DELETE",
    });
    const payload = await response.json().catch(() => null);
    setDeleting(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel excluir a transacao."));
      return;
    }

    toast.success("Transacao excluida.");
    setTransactionToDelete(null);
    await loadTransactions();
  }

  function exportCsv() {
    const rows = [
      ["Data", "Descricao", "Categoria", "Tipo", "Valor", "Observacoes"],
      ...filteredTransactions.map((transaction) => [
        formatDateBR(transaction.date),
        transaction.description,
        transaction.category,
        transactionTypeLabels[transaction.type],
        formatCurrencyBRL(transaction.amount),
        transaction.notes ?? "",
      ]),
    ];

    const csv = rows.map((row) => row.map(toCsvValue).join(";")).join("\n");
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "agrologistic-financeiro.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  function toggleSort(key: TransactionSortKey) {
    setPage(1);

    if (key === sortKey) {
      setSortDirection((current) => (current === "desc" ? "asc" : "desc"));
      return;
    }

    setSortKey(key);
    setSortDirection("desc");
  }

  if (loading && transactions.length === 0) {
    return <FinancialSkeleton />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 rounded-xl border border-emerald-500/15 bg-card/70 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium">Carteira financeira</p>
          <p className="text-sm text-muted-foreground">
            Lucro operacional considera receitas menos despesas; investimentos ficam acompanhados separadamente.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={openCreateModal}>
            <Plus className="h-4 w-4" />
            Nova transacao
          </Button>
          <Button variant="outline" onClick={exportCsv} disabled={filteredTransactions.length === 0}>
            <Download className="h-4 w-4" />
            Exportar CSV
          </Button>
          <Button variant="outline" onClick={loadTransactions} disabled={loading}>
            <RefreshCw className={loading ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
            Atualizar
          </Button>
        </div>
      </div>

      {error ? (
        <Card className="rounded-xl border-red-500/20 bg-red-500/10">
          <CardContent className="p-4 text-sm text-red-200">{error}</CardContent>
        </Card>
      ) : null}

      <FinancialSummaryCards totals={totals} />
      <FinancialChart data={chartData} />

      {transactions.length === 0 ? (
        <EmptyFinancialState onCreate={openCreateModal} />
      ) : (
        <>
          <TransactionFilters
            filters={filters}
            categories={categories}
            onChange={(nextFilters) => {
              setFilters(nextFilters);
              setPage(1);
            }}
            onReset={() => {
              setFilters({ search: "", type: "ALL", category: "ALL" });
              setPage(1);
            }}
          />
          <TransactionTable
            transactions={paginatedTransactions}
            totalResults={filteredTransactions.length}
            page={currentPage}
            totalPages={totalPages}
            sortKey={sortKey}
            sortDirection={sortDirection}
            onSort={toggleSort}
            onPageChange={(nextPage) => setPage(Math.min(Math.max(nextPage, 1), totalPages))}
            onCreate={openCreateModal}
            onView={openViewModal}
            onEdit={openEditModal}
            onDelete={setTransactionToDelete}
          />
        </>
      )}

      <TransactionFormModal
        open={modalOpen}
        mode={modalMode}
        transaction={selectedTransaction}
        saving={saving}
        onOpenChange={setModalOpen}
        onSubmit={saveTransaction}
      />
      <TransactionDeleteDialog
        transaction={transactionToDelete}
        deleting={deleting}
        onOpenChange={(open) => {
          if (!open) {
            setTransactionToDelete(null);
          }
        }}
        onConfirm={deleteTransaction}
      />
    </div>
  );
}

function FinancialSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {["receita", "despesa", "investimento", "lucro"].map((item) => (
          <div key={item} className="h-32 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
        ))}
      </div>
      <div className="h-96 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
      <div className="h-72 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
    </div>
  );
}
