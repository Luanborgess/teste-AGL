"use client";

import { ArrowDownRight, ArrowUpRight, Landmark, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrencyBRL } from "@/lib/formatters";
import type { FinancialTotals } from "@/lib/financeiro";
import { cn } from "@/lib/utils";

const cards = [
  {
    label: "Receita Total",
    key: "revenue",
    icon: ArrowUpRight,
    tone: "text-emerald-300",
    surface: "border-emerald-500/20 bg-emerald-500/10",
    helper: "Entradas confirmadas",
  },
  {
    label: "Despesas Totais",
    key: "expenses",
    icon: ArrowDownRight,
    tone: "text-red-300",
    surface: "border-red-500/20 bg-red-500/10",
    helper: "Saidas operacionais",
  },
  {
    label: "Investimentos",
    key: "investments",
    icon: Landmark,
    tone: "text-sky-300",
    surface: "border-sky-500/20 bg-sky-500/10",
    helper: "Aportes e ativos",
  },
  {
    label: "Lucro Liquido",
    key: "netProfit",
    icon: TrendingUp,
    tone: "text-emerald-300",
    surface: "border-emerald-500/20 bg-emerald-500/10",
    helper: "Receita - despesas",
  },
] as const;

export function FinancialSummaryCards({ totals }: { totals: FinancialTotals }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => {
        const value = totals[card.key];
        const isProfit = card.key === "netProfit";
        const profitTone = value < 0 ? "text-red-300" : "text-emerald-300";
        const profitSurface =
          value < 0 ? "border-red-500/20 bg-red-500/10" : "border-emerald-500/20 bg-emerald-500/10";

        return (
          <Card key={card.label} className="overflow-hidden rounded-xl border-foreground/10 bg-card/80 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm text-muted-foreground">{card.label}</p>
                  <p className={cn("mt-3 font-mono text-2xl font-semibold tracking-normal", isProfit ? profitTone : card.tone)}>
                    {formatCurrencyBRL(value)}
                  </p>
                </div>
                <span className={cn("flex h-10 w-10 items-center justify-center rounded-xl border", isProfit ? profitSurface : card.surface)}>
                  <card.icon className={cn("h-4 w-4", isProfit ? profitTone : card.tone)} />
                </span>
              </div>
              <p className="mt-4 text-xs text-muted-foreground">{card.helper}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
