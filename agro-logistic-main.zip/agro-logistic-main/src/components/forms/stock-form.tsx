"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, NativeSelect, TextInput } from "@/components/forms/form-fields";
import {
  stockMovementSchema,
  type StockMovementInput,
  type StockMovementValues,
} from "@/lib/validations";

export function StockForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const form = useForm<StockMovementInput, unknown, StockMovementValues>({
    resolver: zodResolver(stockMovementSchema),
    defaultValues: {
      type: "IN",
      description: "",
      quantity: 0,
      date: new Date().toISOString().slice(0, 10),
    },
  });

  async function onSubmit(values: StockMovementValues) {
    setLoading(true);
    const response = await fetch("/api/estoque", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    setLoading(false);

    if (!response.ok) {
      const body = await response.json().catch(() => null);
      toast.error(body?.error ?? "Não foi possível salvar a movimentação.");
      return;
    }

    form.reset({ ...form.getValues(), description: "", quantity: 0 });
    toast.success("Movimentação salva.");
    router.refresh();
  }

  return (
    <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(onSubmit)}>
      <Field label="Tipo" error={form.formState.errors.type?.message}>
        <NativeSelect {...form.register("type")}>
          <option value="IN">Entrada</option>
          <option value="OUT">Saída</option>
        </NativeSelect>
      </Field>
      <Field label="Data" error={form.formState.errors.date?.message}>
        <TextInput type="date" {...form.register("date")} />
      </Field>
      <Field label="Descrição" error={form.formState.errors.description?.message}>
        <TextInput {...form.register("description")} />
      </Field>
      <Field label="Quantidade" error={form.formState.errors.quantity?.message}>
        <TextInput type="number" step="0.01" {...form.register("quantity")} />
      </Field>
      <div className="flex items-end">
        <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={loading}>
          {loading ? "Salvando..." : "Criar movimentação"}
        </Button>
      </div>
    </form>
  );
}
