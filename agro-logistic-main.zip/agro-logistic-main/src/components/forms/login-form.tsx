"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Field, TextInput } from "@/components/forms/form-fields";
import { loginSchema, type LoginInput } from "@/lib/validations";

export function LoginForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const form = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: { name: "", email: "" },
  });

  async function onSubmit(values: LoginInput) {
    setLoading(true);
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    setLoading(false);

    if (!response.ok) {
      toast.error("Não foi possível entrar.");
      return;
    }

    router.push("/onboarding");
  }

  return (
    <Card className="w-full max-w-md rounded-md border-emerald-500/20 bg-card/90 shadow-2xl">
      <CardHeader>
        <CardTitle>Acessar operação</CardTitle>
      </CardHeader>
      <CardContent>
        <form className="space-y-4" onSubmit={form.handleSubmit(onSubmit)}>
          <Field label="Nome" error={form.formState.errors.name?.message}>
            <TextInput placeholder="Seu nome" {...form.register("name")} />
          </Field>
          <Field label="E-mail" error={form.formState.errors.email?.message}>
            <TextInput placeholder="voce@fazenda.com" inputMode="email" {...form.register("email")} />
          </Field>
          <Button className="w-full bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={loading}>
            {loading ? "Entrando..." : "Entrar no AgroLogistic"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
