"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, NativeSelect, TextInput } from "@/components/forms/form-fields";
import {
  financialEntrySchema,
  type FinancialEntryInput,
  type FinancialEntryValues,
} from "@/lib/validations";

export function FinancialForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const form = useForm<FinancialEntryInput, unknown, FinancialEntryValues>({
    resolver: zodResolver(financialEntrySchema),
    defaultValues: {
      type: "REVENUE",
      description: "",
      category: "",
      amount: 0,
      date: new Date().toISOString().slice(0, 10),
    },
  });

  async function onSubmit(values: FinancialEntryValues) {
    setLoading(true);
    const response = await fetch("/api/financeiro", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    setLoading(false);

    if (!response.ok) {
      toast.error("Não foi possível salvar o lançamento.");
      return;
    }

    form.reset({ ...form.getValues(), description: "", category: "", amount: 0 });
    toast.success("Lançamento salvo.");
    router.refresh();
  }

  return (
    <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(onSubmit)}>
      <Field label="Tipo" error={form.formState.errors.type?.message}>
        <NativeSelect {...form.register("type")}>
          <option value="REVENUE">Receita</option>
          <option value="EXPENSE">Despesa</option>
        </NativeSelect>
      </Field>
      <Field label="Data" error={form.formState.errors.date?.message}>
        <TextInput type="date" {...form.register("date")} />
      </Field>
      <Field label="Descrição" error={form.formState.errors.description?.message}>
        <TextInput {...form.register("description")} />
      </Field>
      <Field label="Categoria" error={form.formState.errors.category?.message}>
        <TextInput placeholder="Venda, insumos, folha..." {...form.register("category")} />
      </Field>
      <Field label="Valor" error={form.formState.errors.amount?.message}>
        <TextInput type="number" step="0.01" {...form.register("amount")} />
      </Field>
      <div className="flex items-end">
        <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={loading}>
          {loading ? "Salvando..." : "Criar lançamento"}
        </Button>
      </div>
    </form>
  );
}
