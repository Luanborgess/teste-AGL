"use client";

import type { FarmProfile } from "@prisma/client";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Field, NativeSelect, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import {
  farmProfileSchema,
  type FarmProfileInput,
  type FarmProfileValues,
} from "@/lib/validations";

const sojaScenario: FarmProfileInput = {
  farmName: "Mais Soja",
  responsible: "Ícaro Almeida dos Santos Machado",
  phone: "(64) 99999-0000",
  operationType: "Produtor rural",
  totalArea: 1000,
  productiveArea: 850,
  mainCrop: "Soja",
  productivityPerHectare: 60,
  pricePerUnit: 125,
  estimatedCosts: 4800000,
  initialStock: 5000,
  machines: 8,
  loadCapacity: 500,
  monthlyVolume: 10000,
  city: "Rio Verde",
  state: "GO",
  notes: "Cenário obrigatório de validação do MVP.",
};

export function OnboardingForm({ profile }: { profile?: FarmProfile | null }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const form = useForm<FarmProfileInput, unknown, FarmProfileValues>({
    resolver: zodResolver(farmProfileSchema),
    defaultValues: profile
      ? {
          farmName: profile.farmName,
          responsible: profile.responsible,
          phone: profile.phone,
          operationType: profile.operationType,
          totalArea: profile.totalArea,
          productiveArea: profile.productiveArea,
          mainCrop: profile.mainCrop,
          productivityPerHectare: profile.productivityPerHectare,
          pricePerUnit: profile.pricePerUnit,
          estimatedCosts: profile.estimatedCosts,
          initialStock: profile.initialStock,
          machines: profile.machines,
          loadCapacity: profile.loadCapacity,
          monthlyVolume: profile.monthlyVolume,
          city: profile.city,
          state: profile.state,
          notes: profile.notes ?? "",
        }
      : {
          farmName: "",
          responsible: "",
          phone: "",
          operationType: "Produtor rural",
          totalArea: 0,
          productiveArea: 0,
          mainCrop: "",
          productivityPerHectare: 0,
          pricePerUnit: 0,
          estimatedCosts: 0,
          initialStock: 0,
          machines: 0,
          loadCapacity: 0,
          monthlyVolume: 0,
          city: "",
          state: "",
          notes: "",
        },
  });

  async function onSubmit(values: FarmProfileValues) {
    setLoading(true);
    const response = await fetch("/api/onboarding", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    setLoading(false);

    if (!response.ok) {
      toast.error("Revise os campos do perfil operacional.");
      return;
    }

    toast.success("Perfil operacional salvo.");
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <Card className="rounded-md bg-card/88">
      <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <CardTitle>Questionário operacional</CardTitle>
        <Button type="button" variant="outline" onClick={() => form.reset(sojaScenario)}>
          Preencher cenário Mais Soja
        </Button>
      </CardHeader>
      <CardContent>
        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(onSubmit)}>
          <Field label="Nome da fazenda ou empresa" error={form.formState.errors.farmName?.message}>
            <TextInput {...form.register("farmName")} />
          </Field>
          <Field label="Responsável" error={form.formState.errors.responsible?.message}>
            <TextInput {...form.register("responsible")} />
          </Field>
          <Field label="Telefone/WhatsApp" error={form.formState.errors.phone?.message}>
            <TextInput {...form.register("phone")} />
          </Field>
          <Field label="Tipo de operação" error={form.formState.errors.operationType?.message}>
            <NativeSelect {...form.register("operationType")}>
              <option>Produtor rural</option>
              <option>Cooperativa</option>
              <option>Armazém</option>
              <option>Trading</option>
              <option>Transportadora agrícola</option>
            </NativeSelect>
          </Field>
          <Field label="Área total (ha)" error={form.formState.errors.totalArea?.message}>
            <TextInput type="number" step="0.01" {...form.register("totalArea")} />
          </Field>
          <Field label="Área produtiva (ha)" error={form.formState.errors.productiveArea?.message}>
            <TextInput type="number" step="0.01" {...form.register("productiveArea")} />
          </Field>
          <Field label="Cultura principal" error={form.formState.errors.mainCrop?.message}>
            <TextInput {...form.register("mainCrop")} />
          </Field>
          <Field label="Produtividade por hectare" error={form.formState.errors.productivityPerHectare?.message}>
            <TextInput type="number" step="0.01" {...form.register("productivityPerHectare")} />
          </Field>
          <Field label="Preço por saca/unidade" error={form.formState.errors.pricePerUnit?.message}>
            <TextInput type="number" step="0.01" {...form.register("pricePerUnit")} />
          </Field>
          <Field label="Custos estimados" error={form.formState.errors.estimatedCosts?.message}>
            <TextInput type="number" step="0.01" {...form.register("estimatedCosts")} />
          </Field>
          <Field label="Estoque inicial" error={form.formState.errors.initialStock?.message}>
            <TextInput type="number" step="0.01" {...form.register("initialStock")} />
          </Field>
          <Field label="Número de máquinas" error={form.formState.errors.machines?.message}>
            <TextInput type="number" {...form.register("machines")} />
          </Field>
          <Field label="Capacidade por carga" error={form.formState.errors.loadCapacity?.message}>
            <TextInput type="number" step="0.01" {...form.register("loadCapacity")} />
          </Field>
          <Field label="Volume médio movimentado por mês" error={form.formState.errors.monthlyVolume?.message}>
            <TextInput type="number" step="0.01" {...form.register("monthlyVolume")} />
          </Field>
          <Field label="Cidade" error={form.formState.errors.city?.message}>
            <TextInput {...form.register("city")} />
          </Field>
          <Field label="Estado" error={form.formState.errors.state?.message}>
            <TextInput maxLength={2} placeholder="UF" {...form.register("state")} />
          </Field>
          <Field className="md:col-span-2" label="Observações" error={form.formState.errors.notes?.message}>
            <TextAreaInput {...form.register("notes")} />
          </Field>
          <div className="md:col-span-2">
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={loading}>
              {loading ? "Salvando..." : "Salvar e abrir dashboard"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
