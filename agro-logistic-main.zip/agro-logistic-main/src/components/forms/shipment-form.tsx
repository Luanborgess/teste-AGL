"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, NativeSelect, TextInput } from "@/components/forms/form-fields";
import { shipmentSchema, type ShipmentInput, type ShipmentValues } from "@/lib/validations";

export function ShipmentForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const form = useForm<ShipmentInput, unknown, ShipmentValues>({
    resolver: zodResolver(shipmentSchema),
    defaultValues: {
      origin: "",
      destination: "",
      carrier: "",
      status: "PLANNED",
      volume: 0,
      freightCost: 0,
      date: new Date().toISOString().slice(0, 10),
    },
  });

  async function onSubmit(values: ShipmentValues) {
    setLoading(true);
    const response = await fetch("/api/logistica", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    setLoading(false);

    if (!response.ok) {
      toast.error("Não foi possível salvar o embarque.");
      return;
    }

    form.reset({ ...form.getValues(), origin: "", destination: "", carrier: "", volume: 0, freightCost: 0 });
    toast.success("Embarque salvo.");
    router.refresh();
  }

  return (
    <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(onSubmit)}>
      <Field label="Origem" error={form.formState.errors.origin?.message}>
        <TextInput {...form.register("origin")} />
      </Field>
      <Field label="Destino" error={form.formState.errors.destination?.message}>
        <TextInput {...form.register("destination")} />
      </Field>
      <Field label="Transportadora" error={form.formState.errors.carrier?.message}>
        <TextInput {...form.register("carrier")} />
      </Field>
      <Field label="Status" error={form.formState.errors.status?.message}>
        <NativeSelect {...form.register("status")}>
          <option value="PLANNED">Planejado</option>
          <option value="IN_TRANSIT">Em trânsito</option>
          <option value="DELIVERED">Entregue</option>
          <option value="DELAYED">Atrasado</option>
          <option value="CANCELED">Cancelado</option>
        </NativeSelect>
      </Field>
      <Field label="Volume" error={form.formState.errors.volume?.message}>
        <TextInput type="number" step="0.01" {...form.register("volume")} />
      </Field>
      <Field label="Custo do frete" error={form.formState.errors.freightCost?.message}>
        <TextInput type="number" step="0.01" {...form.register("freightCost")} />
      </Field>
      <Field label="Data" error={form.formState.errors.date?.message}>
        <TextInput type="date" {...form.register("date")} />
      </Field>
      <div className="flex items-end">
        <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={loading}>
          {loading ? "Salvando..." : "Criar embarque"}
        </Button>
      </div>
    </form>
  );
}
