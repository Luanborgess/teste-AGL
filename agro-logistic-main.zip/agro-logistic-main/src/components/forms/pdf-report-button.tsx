"use client";

import { jsPDF } from "jspdf";
import { FileDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export function PdfReportButton() {
  async function exportPdf() {
    const data = await fetch("/api/report").then((response) => response.json());
    const doc = new jsPDF();

    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text("AgroLogistic - Relatorio Operacional", 16, 18);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    doc.text(`Fazenda/empresa: ${data.farm}`, 16, 32);
    doc.text(`Responsavel: ${data.responsible}`, 16, 40);
    doc.text(`Cultura: ${data.crop}`, 16, 48);
    doc.text(`Localizacao: ${data.city}/${data.state}`, 16, 56);

    const rows = [
      ["Producao estimada", data.metrics.production],
      ["Receita estimada", data.metrics.revenue],
      ["Lucro estimado", data.metrics.profit],
      ["Margem", data.metrics.margin],
      ["Estoque atual", data.metrics.stock],
      ["Cargas necessarias", data.metrics.loads],
      ["Meses para escoar", data.metrics.monthsToShip],
      ["Custo por hectare", data.metrics.costPerHectare],
      ["Custo por saca", data.metrics.costPerUnit],
    ];

    let y = 72;
    rows.forEach(([label, value]) => {
      doc.setFont("helvetica", "bold");
      doc.text(`${label}:`, 16, y);
      doc.setFont("helvetica", "normal");
      doc.text(String(value), 72, y);
      y += 10;
    });

    doc.save(`agrologistic-${data.farm}.pdf`);
  }

  return (
    <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={exportPdf}>
      <FileDown className="mr-2 h-4 w-4" />
      Exportar PDF
    </Button>
  );
}
