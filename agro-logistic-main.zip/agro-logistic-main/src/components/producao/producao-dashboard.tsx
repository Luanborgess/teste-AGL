"use client";

import { Download, Plus, RefreshCw } from "lucide-react";
import dynamic from "next/dynamic";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CropDeleteDialog } from "@/components/producao/crop-delete-dialog";
import { CropDetailsModal } from "@/components/producao/crop-details-modal";
import { CropFilters, type CropFiltersState } from "@/components/producao/crop-filters";
import { CropFormModal, type CropModalMode } from "@/components/producao/crop-form-modal";
import {
  CropsTable,
  type CropSortDirection,
  type CropSortKey,
} from "@/components/producao/crops-table";
import { EmptyProductionState } from "@/components/producao/empty-production-state";
import { ProductionSummaryCards } from "@/components/producao/production-summary-cards";
import {
  buildProductionChartData,
  buildProductionSummary,
  cropStatusLabels,
  type SerializedCrop,
} from "@/lib/production-calculations";
import { formatDateBR, formatNumber } from "@/lib/formatters";
import type { CropValues } from "@/lib/validations";

const pageSize = 8;

const ProductionChart = dynamic(
  () => import("@/components/producao/production-chart").then((mod) => mod.ProductionChart),
  {
    ssr: false,
    loading: () => <div className="h-[22rem] animate-pulse rounded-xl border border-foreground/10 bg-card/70" />,
  },
);

function normalizeCrop(crop: SerializedCrop): SerializedCrop {
  return {
    ...crop,
    plantingDate: new Date(crop.plantingDate).toISOString(),
    expectedHarvestDate: new Date(crop.expectedHarvestDate).toISOString(),
    createdAt: new Date(crop.createdAt).toISOString(),
    updatedAt: new Date(crop.updatedAt).toISOString(),
  };
}

function getApiError(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string") {
    return payload.error;
  }

  return fallback;
}

function sortValue(crop: SerializedCrop, key: CropSortKey) {
  if (key === "plantingDate" || key === "expectedHarvestDate") {
    return new Date(crop[key]).getTime();
  }

  return crop[key];
}

function toCsvValue(value: string | number) {
  const text = String(value).replace(/"/g, '""');
  return `"${text}"`;
}

export function ProducaoDashboard({ initialCrops }: { initialCrops: SerializedCrop[] }) {
  const [crops, setCrops] = useState(() => initialCrops.map(normalizeCrop));
  const [filters, setFilters] = useState<CropFiltersState>({ search: "", status: "ALL" });
  const [sortKey, setSortKey] = useState<CropSortKey>("expectedHarvestDate");
  const [sortDirection, setSortDirection] = useState<CropSortDirection>("asc");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalMode, setModalMode] = useState<CropModalMode>("create");
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedCrop, setSelectedCrop] = useState<SerializedCrop | null>(null);
  const [detailsCrop, setDetailsCrop] = useState<SerializedCrop | null>(null);
  const [cropToDelete, setCropToDelete] = useState<SerializedCrop | null>(null);

  const summary = useMemo(() => buildProductionSummary(crops), [crops]);
  const chartData = useMemo(() => buildProductionChartData(crops), [crops]);

  const filteredCrops = useMemo(() => {
    const search = filters.search.trim().toLocaleLowerCase("pt-BR");

    return crops
      .filter((crop) => {
        const matchesSearch =
          !search ||
          crop.name.toLocaleLowerCase("pt-BR").includes(search) ||
          (crop.variety ?? "").toLocaleLowerCase("pt-BR").includes(search);
        const matchesStatus = filters.status === "ALL" || crop.status === filters.status;

        return matchesSearch && matchesStatus;
      })
      .sort((a, b) => {
        const aValue = sortValue(a, sortKey);
        const bValue = sortValue(b, sortKey);
        return sortDirection === "desc" ? bValue - aValue : aValue - bValue;
      });
  }, [crops, filters, sortDirection, sortKey]);

  const totalPages = Math.max(1, Math.ceil(filteredCrops.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginatedCrops = filteredCrops.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  async function loadCrops() {
    setLoading(true);
    setError(null);

    const response = await fetch("/api/producao/crops", { cache: "no-store" });
    const payload = await response.json().catch(() => null);
    setLoading(false);

    if (!response.ok) {
      const message = getApiError(payload, "Nao foi possivel carregar os cultivos.");
      setError(message);
      toast.error(message);
      return;
    }

    setCrops((payload.crops as SerializedCrop[]).map(normalizeCrop));
  }

  function openCreateModal() {
    setSelectedCrop(null);
    setModalMode("create");
    setModalOpen(true);
  }

  function openEditModal(crop: SerializedCrop) {
    setSelectedCrop(crop);
    setModalMode("edit");
    setModalOpen(true);
  }

  function openHarvestModal(crop: SerializedCrop) {
    setSelectedCrop(crop);
    setModalMode("harvest");
    setModalOpen(true);
  }

  async function saveCrop(values: CropValues) {
    setSaving(true);

    const isEdit = selectedCrop && modalMode !== "create";
    const response = await fetch(isEdit ? `/api/producao/crops/${selectedCrop.id}` : "/api/producao/crops", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSaving(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel salvar o cultivo."));
      return;
    }

    toast.success(isEdit ? "Cultivo atualizado." : "Cultivo criado.");
    setModalOpen(false);
    setSelectedCrop(null);
    await loadCrops();
  }

  async function deleteCrop() {
    if (!cropToDelete) {
      return;
    }

    setDeleting(true);
    const response = await fetch(`/api/producao/crops/${cropToDelete.id}`, { method: "DELETE" });
    const payload = await response.json().catch(() => null);
    setDeleting(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel excluir o cultivo."));
      return;
    }

    toast.success("Cultivo excluido.");
    setCropToDelete(null);
    await loadCrops();
  }

  function exportCsv() {
    const rows = [
      ["Cultivo", "Variedade", "Area", "Plantio", "Colheita prevista", "Producao esperada", "Producao colhida", "Status"],
      ...filteredCrops.map((crop) => [
        crop.name,
        crop.variety ?? "",
        formatNumber(crop.plantedArea, " ha"),
        formatDateBR(crop.plantingDate),
        formatDateBR(crop.expectedHarvestDate),
        formatNumber(crop.expectedProduction, " sacas"),
        formatNumber(crop.harvestedProduction, " sacas"),
        cropStatusLabels[crop.status],
      ]),
    ];

    const csv = rows.map((row) => row.map(toCsvValue).join(";")).join("\n");
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "agrologistic-producao.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  function toggleSort(key: CropSortKey) {
    setPage(1);

    if (key === sortKey) {
      setSortDirection((current) => (current === "desc" ? "asc" : "desc"));
      return;
    }

    setSortKey(key);
    setSortDirection(key === "expectedHarvestDate" || key === "plantingDate" ? "asc" : "desc");
  }

  if (loading && crops.length === 0) {
    return <ProductionSkeleton />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 rounded-xl border border-emerald-500/15 bg-card/70 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium">Gestao da safra</p>
          <p className="text-sm text-muted-foreground">
            Cultivos reais cadastrados no banco, com previsao, colheita e acompanhamento de progresso.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={openCreateModal}>
            <Plus className="h-4 w-4" />
            Novo cultivo
          </Button>
          <Button variant="outline" onClick={exportCsv} disabled={filteredCrops.length === 0}>
            <Download className="h-4 w-4" />
            Exportar CSV
          </Button>
          <Button variant="outline" onClick={loadCrops} disabled={loading}>
            <RefreshCw className={loading ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
            Atualizar
          </Button>
        </div>
      </div>

      {error ? (
        <Card className="rounded-xl border-red-500/20 bg-red-500/10">
          <CardContent className="p-4 text-sm text-red-200">{error}</CardContent>
        </Card>
      ) : null}

      <ProductionSummaryCards summary={summary} />

      {crops.length === 0 ? (
        <EmptyProductionState onCreate={openCreateModal} />
      ) : (
        <>
          <ProductionChart data={chartData} />
          <CropFilters
            filters={filters}
            onChange={(nextFilters) => {
              setFilters(nextFilters);
              setPage(1);
            }}
          />
          <CropsTable
            crops={paginatedCrops}
            totalResults={filteredCrops.length}
            page={currentPage}
            totalPages={totalPages}
            sortKey={sortKey}
            sortDirection={sortDirection}
            onSort={toggleSort}
            onPageChange={(nextPage) => setPage(Math.min(Math.max(nextPage, 1), totalPages))}
            onCreate={openCreateModal}
            onView={setDetailsCrop}
            onEdit={openEditModal}
            onHarvest={openHarvestModal}
            onDelete={setCropToDelete}
          />
        </>
      )}

      <CropFormModal
        open={modalOpen}
        mode={modalMode}
        crop={selectedCrop}
        saving={saving}
        onOpenChange={setModalOpen}
        onSubmit={saveCrop}
      />
      <CropDetailsModal
        crop={detailsCrop}
        onOpenChange={(open) => {
          if (!open) {
            setDetailsCrop(null);
          }
        }}
      />
      <CropDeleteDialog
        crop={cropToDelete}
        deleting={deleting}
        onOpenChange={(open) => {
          if (!open) {
            setCropToDelete(null);
          }
        }}
        onConfirm={deleteCrop}
      />
    </div>
  );
}

function ProductionSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {["ativos", "area", "esperada", "colhida", "progresso"].map((item) => (
          <div key={item} className="h-32 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
        ))}
      </div>
      <div className="h-96 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
      <div className="h-72 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
    </div>
  );
}
