"use client";

import { CalendarDays, Gauge, Sprout } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  calculateDaysUntilHarvest,
  calculateExpectedYieldPerHectare,
  calculateHarvestedYieldPerHectare,
  calculateSeasonProgress,
  cropStatusLabels,
  type SerializedCrop,
} from "@/lib/production-calculations";
import { formatDateBR, formatNumber, formatPercent } from "@/lib/formatters";

function statusClass(status: SerializedCrop["status"]) {
  if (status === "PLANTADO") {
    return "border-blue-500/20 bg-blue-500/10 text-blue-300";
  }

  if (status === "EM_CRESCIMENTO") {
    return "border-emerald-500/20 bg-emerald-500/10 text-emerald-300";
  }

  if (status === "COLHIDO") {
    return "border-amber-500/25 bg-amber-500/10 text-amber-300";
  }

  return "border-red-500/20 bg-red-500/10 text-red-300";
}

function DetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-foreground/10 bg-background/45 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 font-medium">{value}</p>
    </div>
  );
}

export function CropDetailsModal({
  crop,
  onOpenChange,
}: {
  crop: SerializedCrop | null;
  onOpenChange: (open: boolean) => void;
}) {
  const progress = crop ? calculateSeasonProgress(crop.expectedProduction, crop.harvestedProduction) : 0;
  const daysUntilHarvest = crop ? calculateDaysUntilHarvest(crop.expectedHarvestDate) : null;
  const expectedYield = crop ? calculateExpectedYieldPerHectare(crop) : null;
  const harvestedYield = crop ? calculateHarvestedYieldPerHectare(crop) : null;

  return (
    <Dialog open={Boolean(crop)} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sprout className="h-5 w-5 text-emerald-300" />
            {crop ? crop.name : "Cultivo"}
          </DialogTitle>
          <DialogDescription>Detalhes operacionais do cultivo salvo no banco.</DialogDescription>
        </DialogHeader>

        {crop ? (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className={statusClass(crop.status)}>
                {cropStatusLabels[crop.status]}
              </Badge>
              <Badge variant="outline">{crop.variety || "Sem variedade"}</Badge>
              <Badge variant="outline" className="gap-1">
                <CalendarDays className="h-3.5 w-3.5" />
                {daysUntilHarvest === null
                  ? "Prazo indisponivel"
                  : daysUntilHarvest >= 0
                    ? `${daysUntilHarvest} dia(s) ate a colheita`
                    : `${Math.abs(daysUntilHarvest)} dia(s) apos a previsao`}
              </Badge>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <DetailItem label="Area plantada" value={formatNumber(crop.plantedArea, " ha")} />
              <DetailItem label="Plantio" value={formatDateBR(crop.plantingDate)} />
              <DetailItem label="Colheita prevista" value={formatDateBR(crop.expectedHarvestDate)} />
              <DetailItem label="Producao esperada" value={formatNumber(crop.expectedProduction, " sacas")} />
              <DetailItem label="Producao colhida" value={formatNumber(crop.harvestedProduction, " sacas")} />
              <DetailItem label="Progresso da colheita" value={formatPercent(progress)} />
              <DetailItem label="Produtividade esperada" value={formatNumber(expectedYield, " sacas/ha")} />
              <DetailItem label="Produtividade colhida" value={formatNumber(harvestedYield, " sacas/ha")} />
              <DetailItem label="Criado em" value={formatDateBR(crop.createdAt)} />
              <DetailItem label="Ultima atualizacao" value={formatDateBR(crop.updatedAt)} />
            </div>

            <div className="rounded-xl border border-emerald-500/15 bg-emerald-500/10 p-4">
              <div className="mb-2 flex items-center gap-2 text-sm font-medium">
                <Gauge className="h-4 w-4 text-emerald-300" />
                Observacoes
              </div>
              <p className="text-sm text-muted-foreground">{crop.notes || "Nenhuma observacao registrada."}</p>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
