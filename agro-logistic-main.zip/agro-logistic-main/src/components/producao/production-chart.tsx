"use client";

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatNumber } from "@/lib/formatters";

export type ProductionChartRow = {
  name: string;
  esperado: number;
  colhido: number;
};

export function ProductionChart({ data }: { data: ProductionChartRow[] }) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Producao por Cultivo (sacas)</CardTitle>
        <p className="text-sm text-muted-foreground">Comparativo entre previsao e volume colhido nos cultivos salvos.</p>
      </CardHeader>
      <CardContent className="h-[22rem]">
        <ResponsiveContainer width="100%" height="100%" minWidth={0}>
          <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} vertical={false} />
            <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} />
            <YAxis
              tickLine={false}
              axisLine={false}
              fontSize={12}
              tickFormatter={(value) => `${Number(value) / 1000}k`}
            />
            <Tooltip
              cursor={{ fill: "rgba(255,255,255,0.04)" }}
              contentStyle={{
                background: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "12px",
                color: "hsl(var(--popover-foreground))",
              }}
              formatter={(value, name) => [formatNumber(Number(value), " sacas"), String(name)]}
            />
            <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
            <Bar name="Producao esperada" dataKey="esperado" fill="#6ee7b7" radius={[8, 8, 0, 0]} animationDuration={500} />
            <Bar name="Producao colhida" dataKey="colhido" fill="#10b981" radius={[8, 8, 0, 0]} animationDuration={500} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
