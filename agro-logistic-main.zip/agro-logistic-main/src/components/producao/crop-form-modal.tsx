"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { AlertTriangle, Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import { cropStatusLabels, type SerializedCrop } from "@/lib/production-calculations";
import { cropSchema, type CropInput, type CropValues } from "@/lib/validations";

export type CropModalMode = "create" | "edit" | "harvest";

const emptyValues: CropInput = {
  name: "",
  variety: "",
  plantedArea: 0,
  plantingDate: new Date().toISOString().slice(0, 10),
  expectedHarvestDate: new Date().toISOString().slice(0, 10),
  expectedProduction: 0,
  harvestedProduction: 0,
  status: "PLANTADO",
  notes: "",
};

function valuesFromCrop(crop: SerializedCrop | null): CropInput {
  if (!crop) {
    return emptyValues;
  }

  return {
    name: crop.name,
    variety: crop.variety ?? "",
    plantedArea: crop.plantedArea,
    plantingDate: new Date(crop.plantingDate).toISOString().slice(0, 10),
    expectedHarvestDate: new Date(crop.expectedHarvestDate).toISOString().slice(0, 10),
    expectedProduction: crop.expectedProduction,
    harvestedProduction: crop.harvestedProduction,
    status: crop.status,
    notes: crop.notes ?? "",
  };
}

function modalTitle(mode: CropModalMode) {
  if (mode === "create") {
    return "Novo cultivo";
  }

  if (mode === "harvest") {
    return "Registrar producao colhida";
  }

  return "Editar cultivo";
}

export function CropFormModal({
  open,
  mode,
  crop,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  mode: CropModalMode;
  crop: SerializedCrop | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: CropValues) => Promise<void>;
}) {
  const form = useForm<CropInput, unknown, CropValues>({
    resolver: zodResolver(cropSchema),
    defaultValues: valuesFromCrop(crop),
  });
  const selectedStatus = useWatch({ control: form.control, name: "status" });
  const expectedProduction = Number(useWatch({ control: form.control, name: "expectedProduction" }) ?? 0);
  const harvestedProduction = Number(useWatch({ control: form.control, name: "harvestedProduction" }) ?? 0);
  const showHarvestWarning = harvestedProduction > expectedProduction && expectedProduction >= 0;

  useEffect(() => {
    if (open) {
      form.reset(valuesFromCrop(crop));
    }
  }, [crop, form, open]);

  async function submit(values: CropValues) {
    await onSubmit(values);

    if (mode === "create") {
      form.reset(emptyValues);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{modalTitle(mode)}</DialogTitle>
          <DialogDescription>
            Registre dados reais de plantio, previsao e colheita. Os indicadores sao recalculados ao salvar.
          </DialogDescription>
        </DialogHeader>

        {showHarvestWarning ? (
          <Alert className="rounded-xl border-amber-500/25 bg-amber-500/10">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Producao acima do previsto</AlertTitle>
            <AlertDescription>
              A producao colhida informada e maior que a producao esperada. O valor sera salvo, mas revise se a
              previsao precisa ser ajustada.
            </AlertDescription>
          </Alert>
        ) : null}

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Cultivo" error={form.formState.errors.name?.message}>
            <TextInput disabled={saving} placeholder="Soja" {...form.register("name")} />
          </Field>

          <Field label="Variedade" error={form.formState.errors.variety?.message}>
            <TextInput disabled={saving} placeholder="BRS 1010" {...form.register("variety")} />
          </Field>

          <Field label="Area plantada" error={form.formState.errors.plantedArea?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" placeholder="850" {...form.register("plantedArea")} />
          </Field>

          <Field label="Status" error={form.formState.errors.status?.message}>
            <Select
              disabled={saving}
              value={selectedStatus}
              onValueChange={(value) => form.setValue("status", value as CropValues["status"], { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o status" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(cropStatusLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Data de plantio" error={form.formState.errors.plantingDate?.message}>
            <TextInput disabled={saving} type="date" {...form.register("plantingDate")} />
          </Field>

          <Field label="Colheita prevista" error={form.formState.errors.expectedHarvestDate?.message}>
            <TextInput disabled={saving} type="date" {...form.register("expectedHarvestDate")} />
          </Field>

          <Field label="Producao esperada" error={form.formState.errors.expectedProduction?.message}>
            <TextInput
              disabled={saving}
              type="number"
              min="0"
              step="0.01"
              placeholder="51000"
              {...form.register("expectedProduction")}
            />
          </Field>

          <Field label="Producao colhida" error={form.formState.errors.harvestedProduction?.message}>
            <TextInput
              disabled={saving}
              type="number"
              min="0"
              step="0.01"
              placeholder="0"
              {...form.register("harvestedProduction")}
            />
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Talhao, manejo, clima, observacoes de campo..." {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
