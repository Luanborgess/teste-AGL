"use client";

import { Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { SerializedCrop } from "@/lib/production-calculations";
import { formatNumber } from "@/lib/formatters";

export function CropDeleteDialog({
  crop,
  deleting,
  onOpenChange,
  onConfirm,
}: {
  crop: SerializedCrop | null;
  deleting: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => Promise<void>;
}) {
  return (
    <Dialog open={Boolean(crop)} onOpenChange={onOpenChange}>
      <DialogContent className="border-red-500/15 bg-popover/95 sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Excluir cultivo</DialogTitle>
          <DialogDescription>
            Esta acao nao pode ser desfeita. O cultivo sera removido do banco e os indicadores serao recalculados.
          </DialogDescription>
        </DialogHeader>

        {crop ? (
          <div className="rounded-xl border border-red-500/15 bg-red-500/10 p-4 text-sm">
            <p className="font-medium">{crop.name}</p>
            <p className="mt-1 text-muted-foreground">
              {crop.variety || "Sem variedade"} - {formatNumber(crop.plantedArea, " ha")}
            </p>
          </div>
        ) : null}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={deleting}>
            Cancelar
          </Button>
          <Button variant="destructive" onClick={onConfirm} disabled={deleting}>
            {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            {deleting ? "Excluindo..." : "Excluir"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
