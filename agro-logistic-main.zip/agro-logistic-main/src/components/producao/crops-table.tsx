"use client";

import {
  ArrowDownUp,
  ChevronLeft,
  ChevronRight,
  ClipboardCheck,
  Eye,
  Pencil,
  Trash2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { EmptyProductionState } from "@/components/producao/empty-production-state";
import { cropStatusLabels, type SerializedCrop } from "@/lib/production-calculations";
import { formatDateBR, formatNumber } from "@/lib/formatters";
import { cn } from "@/lib/utils";

export type CropSortKey = "plantingDate" | "expectedHarvestDate" | "expectedProduction" | "plantedArea";
export type CropSortDirection = "asc" | "desc";

function statusBadgeClass(status: SerializedCrop["status"]) {
  if (status === "PLANTADO") {
    return "border-blue-500/20 bg-blue-500/10 text-blue-300";
  }

  if (status === "EM_CRESCIMENTO") {
    return "border-emerald-500/20 bg-emerald-500/10 text-emerald-300";
  }

  if (status === "COLHIDO") {
    return "border-amber-500/25 bg-amber-500/10 text-amber-300";
  }

  return "border-red-500/20 bg-red-500/10 text-red-300";
}

function sortLabel(key: CropSortKey) {
  const labels: Record<CropSortKey, string> = {
    plantingDate: "plantio",
    expectedHarvestDate: "colheita prevista",
    expectedProduction: "producao",
    plantedArea: "area",
  };

  return labels[key];
}

export function CropsTable({
  crops,
  totalResults,
  page,
  totalPages,
  sortKey,
  sortDirection,
  onSort,
  onPageChange,
  onCreate,
  onView,
  onEdit,
  onHarvest,
  onDelete,
}: {
  crops: SerializedCrop[];
  totalResults: number;
  page: number;
  totalPages: number;
  sortKey: CropSortKey;
  sortDirection: CropSortDirection;
  onSort: (key: CropSortKey) => void;
  onPageChange: (page: number) => void;
  onCreate: () => void;
  onView: (crop: SerializedCrop) => void;
  onEdit: (crop: SerializedCrop) => void;
  onHarvest: (crop: SerializedCrop) => void;
  onDelete: (crop: SerializedCrop) => void;
}) {
  if (totalResults === 0) {
    return (
      <EmptyProductionState
        title="Sem resultados"
        description="Nenhum cultivo corresponde aos filtros aplicados."
        onCreate={onCreate}
      />
    );
  }

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Cultivos</CardTitle>
        <p className="text-sm text-muted-foreground">{totalResults} registro(s) encontrados</p>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead>Cultivo</TableHead>
              <TableHead>Variedade</TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" size="sm" className="-mr-2" onClick={() => onSort("plantedArea")}>
                  Area
                  <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "plantedArea" && "text-emerald-300")} />
                </Button>
              </TableHead>
              <TableHead>
                <Button variant="ghost" size="sm" className="-ml-2" onClick={() => onSort("plantingDate")}>
                  Plantio
                  <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "plantingDate" && "text-emerald-300")} />
                </Button>
              </TableHead>
              <TableHead>
                <Button variant="ghost" size="sm" className="-ml-2" onClick={() => onSort("expectedHarvestDate")}>
                  Colheita Prevista
                  <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "expectedHarvestDate" && "text-emerald-300")} />
                </Button>
              </TableHead>
              <TableHead className="text-right">
                <Button variant="ghost" size="sm" className="-mr-2" onClick={() => onSort("expectedProduction")}>
                  Producao Esperada
                  <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "expectedProduction" && "text-emerald-300")} />
                </Button>
              </TableHead>
              <TableHead className="text-right">Producao Colhida</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Acoes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {crops.map((crop) => (
              <TableRow key={crop.id} className="border-foreground/10">
                <TableCell className="font-medium">{crop.name}</TableCell>
                <TableCell className="text-muted-foreground">{crop.variety || "Sem variedade"}</TableCell>
                <TableCell className="text-right font-mono text-xs">{formatNumber(crop.plantedArea, " ha")}</TableCell>
                <TableCell className="font-mono text-xs text-muted-foreground">{formatDateBR(crop.plantingDate)}</TableCell>
                <TableCell className="font-mono text-xs text-muted-foreground">{formatDateBR(crop.expectedHarvestDate)}</TableCell>
                <TableCell className="text-right font-mono">{formatNumber(crop.expectedProduction, " sacas")}</TableCell>
                <TableCell className="text-right font-mono text-emerald-300">
                  {formatNumber(crop.harvestedProduction, " sacas")}
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={statusBadgeClass(crop.status)}>
                    {cropStatusLabels[crop.status]}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex justify-end gap-1">
                    <Button variant="ghost" size="icon-sm" title="Visualizar" onClick={() => onView(crop)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon-sm" title="Registrar producao" onClick={() => onHarvest(crop)}>
                      <ClipboardCheck className="h-4 w-4 text-emerald-300" />
                    </Button>
                    <Button variant="ghost" size="icon-sm" title="Editar" onClick={() => onEdit(crop)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon-sm" title="Excluir" onClick={() => onDelete(crop)}>
                      <Trash2 className="h-4 w-4 text-red-300" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        <div className="mt-4 flex flex-col gap-3 border-t border-foreground/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-muted-foreground">
            Pagina {page} de {totalPages} - ordenado por {sortLabel(sortKey)} (
            {sortDirection === "desc" ? "desc" : "asc"})
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => onPageChange(page - 1)} disabled={page <= 1}>
              <ChevronLeft className="h-4 w-4" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" onClick={() => onPageChange(page + 1)} disabled={page >= totalPages}>
              Proxima
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
