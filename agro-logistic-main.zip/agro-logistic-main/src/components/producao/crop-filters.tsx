"use client";

import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cropStatusLabels } from "@/lib/production-calculations";
import type { CropStatusValue } from "@/lib/validations";

export type CropFiltersState = {
  search: string;
  status: CropStatusValue | "ALL";
};

export function CropFilters({
  filters,
  onChange,
}: {
  filters: CropFiltersState;
  onChange: (filters: CropFiltersState) => void;
}) {
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-foreground/10 bg-card/75 p-4 sm:flex-row">
      <div className="relative flex-1">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={filters.search}
          onChange={(event) => onChange({ ...filters, search: event.target.value })}
          placeholder="Pesquisar por cultivo ou variedade"
          className="bg-background/70 pl-9"
        />
      </div>
      <Select
        value={filters.status}
        onValueChange={(value) => onChange({ ...filters, status: value as CropFiltersState["status"] })}
      >
        <SelectTrigger className="w-full bg-background/70 sm:w-56">
          <SelectValue placeholder="Status" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="ALL">Todos os status</SelectItem>
          {Object.entries(cropStatusLabels).map(([value, label]) => (
            <SelectItem key={value} value={value}>
              {label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
