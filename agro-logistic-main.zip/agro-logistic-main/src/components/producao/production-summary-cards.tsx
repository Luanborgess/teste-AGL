"use client";

import { AreaChart, BarChart3, CheckCircle2, Sprout, TrendingUp } from "lucide-react";
import { StatCard } from "@/components/dashboard/stat-card";
import { formatInteger, formatNumber, formatPercent } from "@/lib/formatters";

export type ProductionSummary = {
  activeCrops: number;
  plantedArea: number;
  expectedProduction: number;
  harvestedProduction: number;
  seasonProgress: number;
};

export function ProductionSummaryCards({ summary }: { summary: ProductionSummary }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
      <StatCard
        label="Cultivos ativos"
        value={formatInteger(summary.activeCrops)}
        helper="Status plantado ou em crescimento."
        icon={Sprout}
        tone="good"
      />
      <StatCard
        label="Area plantada total"
        value={formatNumber(summary.plantedArea, " ha")}
        helper="Soma dos hectares cadastrados."
        icon={AreaChart}
      />
      <StatCard
        label="Producao esperada"
        value={formatNumber(summary.expectedProduction, " sacas")}
        helper="Soma das previsoes salvas."
        icon={BarChart3}
      />
      <StatCard
        label="Producao colhida"
        value={formatNumber(summary.harvestedProduction, " sacas")}
        helper="Total registrado como colhido."
        icon={CheckCircle2}
        tone="good"
      />
      <StatCard
        label="Progresso da safra"
        value={formatPercent(summary.seasonProgress)}
        helper="Producao colhida / esperada."
        icon={TrendingUp}
      />
    </div>
  );
}
