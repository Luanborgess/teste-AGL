"use client";

import { Sprout } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function EmptyProductionState({
  title = "Nenhum cultivo cadastrado",
  description = "Cadastre o primeiro cultivo para acompanhar area plantada, previsao de colheita e producao realizada.",
  onCreate,
}: {
  title?: string;
  description?: string;
  onCreate: () => void;
}) {
  return (
    <Card className="rounded-xl border-emerald-500/15 bg-card/80">
      <CardContent className="flex min-h-72 flex-col items-center justify-center px-6 py-10 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-xl border border-emerald-500/20 bg-emerald-500/10 text-emerald-300">
          <Sprout className="h-7 w-7" />
        </span>
        <h2 className="mt-5 text-lg font-semibold">{title}</h2>
        <p className="mt-2 max-w-md text-sm text-muted-foreground">{description}</p>
        <Button className="mt-6 bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={onCreate}>
          Novo cultivo
        </Button>
      </CardContent>
    </Card>
  );
}
