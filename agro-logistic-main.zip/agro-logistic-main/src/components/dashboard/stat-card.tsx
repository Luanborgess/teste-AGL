import type { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const tones = {
  default: "border-border/70 bg-card/82",
  good: "border-emerald-500/25 bg-emerald-500/10",
  warning: "border-amber-500/25 bg-amber-500/10",
  danger: "border-red-500/25 bg-red-500/10",
};

export function StatCard({
  label,
  value,
  helper,
  icon: Icon,
  tone = "default",
}: {
  label: string;
  value: string;
  helper: string;
  icon: LucideIcon;
  tone?: keyof typeof tones;
}) {
  return (
    <Card className={cn("rounded-md shadow-sm backdrop-blur", tones[tone])}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="mt-2 text-2xl font-semibold tracking-tight">{value}</p>
          </div>
          <span className="flex h-10 w-10 items-center justify-center rounded-md bg-background/70 text-emerald-400">
            <Icon className="h-5 w-5" />
          </span>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">{helper}</p>
      </CardContent>
    </Card>
  );
}
