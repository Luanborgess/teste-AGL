"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatNumber } from "@/lib/formatters";

export function OperationCharts({
  production,
  shipped,
  stock,
  revenue,
  costs,
  expenses,
}: {
  production: number | null;
  shipped: number;
  stock: number | null;
  revenue: number | null;
  costs: number | null;
  expenses: number;
}) {
  const logisticsData = [
    { name: "Produção", value: production ?? 0 },
    { name: "Embarcado", value: shipped },
    { name: "Estoque", value: stock ?? 0 },
  ];

  const financeData = [
    { name: "Receita estimada", value: revenue ?? 0, fill: "#10b981" },
    { name: "Custos estimados", value: costs ?? 0, fill: "#f59e0b" },
    { name: "Despesas reais", value: expenses, fill: "#ef4444" },
  ];

  return (
    <div className="grid gap-4 xl:grid-cols-2">
      <Card className="rounded-md bg-card/82">
        <CardHeader>
          <CardTitle className="text-base">Fluxo físico da safra</CardTitle>
        </CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={logisticsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.12} />
              <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} />
              <YAxis tickLine={false} axisLine={false} fontSize={12} />
              <Tooltip formatter={(value) => formatNumber(Number(value), " sacas")} />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="rounded-md bg-card/82">
        <CardHeader>
          <CardTitle className="text-base">Comparativo financeiro</CardTitle>
        </CardHeader>
        <CardContent className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={financeData}
                dataKey="value"
                nameKey="name"
                innerRadius={60}
                outerRadius={96}
                paddingAngle={4}
              >
                {financeData.map((entry) => (
                  <Cell key={entry.name} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => formatCurrency(Number(value))} />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
