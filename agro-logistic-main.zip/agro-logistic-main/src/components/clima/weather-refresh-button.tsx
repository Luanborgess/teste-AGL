import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export function WeatherRefreshButton({ loading, onRefresh }: { loading: boolean; onRefresh: () => void }) {
  return (
    <Button onClick={onRefresh} disabled={loading} className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400">
      <RefreshCw className={loading ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
      Atualizar clima
    </Button>
  );
}
