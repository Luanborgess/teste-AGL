import { Gauge } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import type { AgroClimateScore } from "@/lib/weather-types";

export function WeatherAgroScore({ agroScore }: { agroScore: AgroClimateScore }) {
  const tone =
    agroScore.score >= 70
      ? "from-emerald-500 to-lime-300 text-emerald-100"
      : agroScore.score >= 40
        ? "from-amber-500 to-yellow-300 text-amber-100"
        : "from-red-500 to-orange-400 text-red-100";

  return (
    <Card className="overflow-hidden rounded-xl border-emerald-500/15 bg-card/80">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Índice AgroClimático</p>
            <p className="mt-1 text-3xl font-semibold tracking-tight">{agroScore.score}/100</p>
            <p className={`mt-2 text-sm font-medium ${tone.split(" ").slice(2).join(" ")}`}>{agroScore.label}</p>
          </div>
          <span className="flex h-11 w-11 items-center justify-center rounded-lg border border-emerald-400/25 bg-emerald-500/10 text-emerald-300">
            <Gauge className="h-5 w-5" />
          </span>
        </div>
        <div className="mt-5 h-2 rounded-full bg-background/70">
          <div className={`h-full rounded-full bg-gradient-to-r ${tone}`} style={{ width: `${agroScore.score}%` }} />
        </div>
        <p className="mt-3 text-sm text-muted-foreground">{agroScore.description}</p>
      </CardContent>
    </Card>
  );
}
