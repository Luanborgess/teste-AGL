import { CloudRain, Droplets, MapPinned, Sun, Thermometer, Wind } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { formatDateTimeBR, formatHumidity, formatRain, formatTemperature, formatWind } from "@/lib/formatters";
import type { NormalizedWeather } from "@/lib/weather-types";

export function WeatherCurrentCard({ weather }: { weather: NormalizedWeather }) {
  const current = weather.current;

  return (
    <Card className="overflow-hidden rounded-xl border-emerald-500/15 bg-card/80">
      <CardContent className="p-0">
        <div className="grid gap-0 xl:grid-cols-[1.1fr_1.5fr]">
          <div className="border-b border-foreground/10 bg-emerald-500/10 p-5 xl:border-b-0 xl:border-r">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm text-muted-foreground">{weather.farm.name}</p>
                <h2 className="mt-2 text-5xl font-semibold tracking-tight">{formatTemperature(current.temperature)}</h2>
                <p className="mt-2 text-sm text-muted-foreground">Sensação {formatTemperature(current.apparentTemperature)}</p>
              </div>
              <span className="flex h-14 w-14 items-center justify-center rounded-lg border border-emerald-400/25 bg-background/40 text-emerald-300">
                <Sun className="h-7 w-7" />
              </span>
            </div>
            <div className="mt-6 flex flex-wrap gap-2">
              <Badge className="border-emerald-400/20 bg-emerald-500/15 text-emerald-200">{current.condition}</Badge>
              <Badge variant="outline" className="border-foreground/15">
                {weather.fromCache ? "Cache" : "API em tempo real"}
              </Badge>
            </div>
            <p className="mt-5 flex items-center gap-2 text-sm text-muted-foreground">
              <MapPinned className="h-4 w-4 text-emerald-300" />
              {weather.location.label}
            </p>
          </div>

          <div className="grid gap-3 p-5 sm:grid-cols-2 xl:grid-cols-3">
            <Metric icon={Droplets} label="Umidade" value={formatHumidity(current.humidity)} />
            <Metric icon={Wind} label="Vento" value={formatWind(current.windSpeed)} />
            <Metric icon={CloudRain} label="Precipitação atual" value={formatRain(current.precipitation)} />
            <Metric icon={Thermometer} label="Índice UV" value={current.uvIndex === null ? "Indisponível" : current.uvIndex.toLocaleString("pt-BR")} />
            <Metric icon={Wind} label="Rajadas" value={formatWind(current.windGusts)} />
            <Metric icon={Sun} label="Atualizado" value={formatDateTimeBR(current.updatedAt)} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-background/45 p-3 transition hover:border-emerald-400/30 hover:bg-emerald-500/10">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Icon className="h-4 w-4 text-emerald-300" />
        {label}
      </div>
      <p className="mt-2 font-mono text-sm font-semibold">{value}</p>
    </div>
  );
}
