import { CloudRain, Gauge, Leaf, Sprout, Thermometer, Wind } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { formatHumidity, formatRain, formatRiskLevel, formatTemperature, formatWind } from "@/lib/formatters";
import type { NormalizedWeather } from "@/lib/weather-types";

export function WeatherSummaryCards({ weather }: { weather: NormalizedWeather }) {
  const nextThree = weather.forecast.slice(0, 3);
  const rain = nextThree.reduce((total, day) => total + (day.precipitationSum ?? 0), 0);
  const maxWind = Math.max(0, ...nextThree.map((day) => day.windSpeedMax ?? 0));
  const avgHumidity =
    nextThree.length > 0 ? nextThree.reduce((total, day) => total + (day.humidityMean ?? 0), 0) / nextThree.length : weather.current.humidity;

  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
      <SummaryCard icon={Thermometer} label="Temperatura" value={formatTemperature(weather.current.temperature)} helper={weather.current.condition} />
      <SummaryCard icon={CloudRain} label="Chuva prevista" value={formatRain(rain)} helper="próximos 3 dias" />
      <SummaryCard icon={Leaf} label="Umidade" value={formatHumidity(avgHumidity)} helper="média prevista" />
      <SummaryCard icon={Wind} label="Vento" value={formatWind(maxWind)} helper="máximo previsto" />
      <SummaryCard icon={Gauge} label="Risco agrícola" value={formatRiskLevel(weather.riskLevel)} helper={`${weather.agroScore.score}/100`} />
      <SummaryCard
        icon={Sprout}
        label="Melhor janela"
        value={weather.bestOperationalWindow.label}
        helper={weather.bestOperationalWindow.favorable ? "favorável" : "com restrições"}
      />
    </div>
  );
}

function SummaryCard({
  icon: Icon,
  label,
  value,
  helper,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  helper: string;
}) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80 transition hover:border-emerald-400/25 hover:bg-card">
      <CardContent className="p-4">
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">{label}</p>
          <Icon className="h-4 w-4 text-emerald-300" />
        </div>
        <p className="mt-3 min-h-7 text-lg font-semibold leading-tight">{value}</p>
        <p className="mt-1 text-xs text-muted-foreground">{helper}</p>
      </CardContent>
    </Card>
  );
}
