import Link from "next/link";
import { CloudSun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function WeatherEmptyState() {
  return (
    <Card className="rounded-xl border-dashed border-foreground/15 bg-card/70">
      <CardContent className="flex min-h-72 flex-col items-center justify-center gap-4 p-6 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-lg border border-emerald-400/25 bg-emerald-500/10 text-emerald-300">
          <CloudSun className="h-6 w-6" />
        </span>
        <div className="space-y-1">
          <p className="text-base font-medium">Cadastre sua fazenda para ver o clima da operação.</p>
          <p className="max-w-md text-sm text-muted-foreground">A previsão agrícola usa a localização real da fazenda cadastrada em Fazenda.</p>
        </div>
        <Button asChild className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400">
          <Link href="/fazenda">Cadastrar fazenda</Link>
        </Button>
      </CardContent>
    </Card>
  );
}
