"use client";

import dynamic from "next/dynamic";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { WeatherDailyForecast } from "@/lib/weather-types";

const WeatherChartsCanvas = dynamic(() => import("@/components/clima/weather-charts-canvas").then((mod) => mod.WeatherChartsCanvas), {
  ssr: false,
  loading: () => <WeatherChartsSkeleton />,
});

export function WeatherCharts({ forecast }: { forecast: WeatherDailyForecast[] }) {
  return <WeatherChartsCanvas forecast={forecast} />;
}

function WeatherChartsSkeleton() {
  return (
    <div className="grid gap-4 xl:grid-cols-2">
      {["Temperatura por dia", "Chuva prevista por dia", "Umidade por dia", "Vento por dia"].map((title) => (
        <Card key={title} className="rounded-xl border-foreground/10 bg-card/80">
          <CardHeader>
            <CardTitle className="text-base">{title}</CardTitle>
          </CardHeader>
          <CardContent className="h-72">
            <div className="h-full animate-pulse rounded-lg bg-background/45" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
