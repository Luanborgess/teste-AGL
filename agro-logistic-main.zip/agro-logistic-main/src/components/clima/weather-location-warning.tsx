import Link from "next/link";
import { MapPinned } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function WeatherLocationWarning() {
  return (
    <Card className="rounded-xl border-amber-500/20 bg-amber-500/10">
      <CardContent className="flex min-h-64 flex-col items-center justify-center gap-4 p-6 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-lg border border-amber-400/25 bg-amber-500/10 text-amber-200">
          <MapPinned className="h-6 w-6" />
        </span>
        <div className="space-y-1">
          <p className="text-base font-medium text-amber-100">Completar localização da fazenda</p>
          <p className="max-w-md text-sm text-amber-100/75">Informe cidade, estado ou coordenadas para buscar a previsão real.</p>
        </div>
        <Button asChild variant="outline" className="border-amber-400/30 bg-amber-500/10 text-amber-100 hover:bg-amber-500/20">
          <Link href="/fazenda">Completar localização da fazenda</Link>
        </Button>
      </CardContent>
    </Card>
  );
}
