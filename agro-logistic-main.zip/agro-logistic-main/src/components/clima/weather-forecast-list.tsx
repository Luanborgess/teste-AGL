import { CloudRain, Droplets, Thermometer, Wind } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatHumidity, formatRain, formatTemperature, formatWind } from "@/lib/formatters";
import type { WeatherDailyForecast } from "@/lib/weather-types";

export function WeatherForecastList({ forecast }: { forecast: WeatherDailyForecast[] }) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Previsão dos próximos dias</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-7">
        {forecast.map((day) => (
          <div key={day.date} className="rounded-lg border border-foreground/10 bg-background/45 p-3 transition hover:border-emerald-400/30">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-medium">
                  {new Date(`${day.date}T12:00:00`).toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "2-digit" })}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">{day.condition}</p>
              </div>
              <Badge variant="outline" className="border-emerald-400/20 text-emerald-200">
                {day.precipitationProbability ?? 0}%
              </Badge>
            </div>
            <div className="mt-4 space-y-2 text-xs text-muted-foreground">
              <ForecastMetric icon={Thermometer} label="Min/Max" value={`${formatTemperature(day.temperatureMin)} / ${formatTemperature(day.temperatureMax)}`} />
              <ForecastMetric icon={CloudRain} label="Chuva" value={formatRain(day.precipitationSum)} />
              <ForecastMetric icon={Wind} label="Vento" value={formatWind(day.windSpeedMax)} />
              <ForecastMetric icon={Droplets} label="Umidade" value={formatHumidity(day.humidityMean)} />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function ForecastMetric({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="flex items-center gap-1.5">
        <Icon className="h-3.5 w-3.5 text-emerald-300" />
        {label}
      </span>
      <span className="font-mono text-foreground">{value}</span>
    </div>
  );
}
