import { Brain, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatRiskLevel } from "@/lib/formatters";
import type { WeatherAiRecommendations } from "@/lib/weather-types";

export function WeatherAiRecommendations({
  analysis,
  loading,
  warning,
}: {
  analysis: WeatherAiRecommendations | null;
  loading: boolean;
  warning: string | null;
}) {
  return (
    <Card className="rounded-xl border-emerald-500/15 bg-card/80">
      <CardHeader className="flex flex-row items-start justify-between gap-4">
        <div>
          <CardTitle className="text-base">Recomendações Inteligentes</CardTitle>
          <p className="mt-1 text-sm text-muted-foreground">
            Análise baseada somente nos dados climáticos reais retornados pela API.
          </p>
        </div>
        <Badge className="border-emerald-400/20 bg-emerald-500/15 text-emerald-200">
          {analysis?.advancedAiActive ? "IA ativa" : "Regras locais"}
        </Badge>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="grid gap-3 md:grid-cols-2">
            {["resumo", "produção", "estoque", "logística"].map((item) => (
              <div key={item} className="h-28 animate-pulse rounded-lg border border-foreground/10 bg-background/45" />
            ))}
          </div>
        ) : analysis ? (
          <div className="space-y-4">
            <div className="rounded-lg border border-emerald-500/15 bg-emerald-500/10 p-4">
              <div className="flex items-start gap-3">
                <Brain className="mt-0.5 h-4 w-4 text-emerald-300" />
                <div>
                  <p className="text-sm font-medium">Risco {formatRiskLevel(analysis.nivelRisco)}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{analysis.resumo}</p>
                </div>
              </div>
            </div>

            {warning ? <p className="rounded-lg border border-amber-500/20 bg-amber-500/10 p-3 text-sm text-amber-100">{warning}</p> : null}

            <div className="grid gap-3 lg:grid-cols-2">
              <RecommendationGroup title="Produção" items={analysis.recomendacoesProducao} />
              <RecommendationGroup title="Estoque" items={analysis.recomendacoesEstoque} />
              <RecommendationGroup title="Logística" items={analysis.recomendacoesLogistica} />
              <RecommendationGroup title="Maquinário" items={analysis.recomendacoesMaquinario} />
              <RecommendationGroup title="Equipe" items={analysis.recomendacoesEquipe} />
              <RecommendationGroup title="Alertas críticos" items={analysis.alertasCriticos.length ? analysis.alertasCriticos : ["Nenhum alerta crítico no momento."]} />
            </div>

            <div className="rounded-lg border border-foreground/10 bg-background/45 p-4">
              <p className="text-sm font-medium">Melhor janela operacional</p>
              <p className="mt-1 text-sm text-muted-foreground">{analysis.melhorJanelaOperacional}</p>
            </div>
          </div>
        ) : (
          <div className="flex min-h-32 items-center justify-center rounded-lg border border-dashed border-foreground/10 bg-background/45 text-sm text-muted-foreground">
            Recomendações indisponíveis no momento.
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function RecommendationGroup({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-background/45 p-4">
      <p className="text-sm font-medium">{title}</p>
      <div className="mt-3 space-y-2">
        {items.map((item) => (
          <div key={item} className="flex gap-2 text-sm text-muted-foreground">
            <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-300" />
            <span>{item}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
