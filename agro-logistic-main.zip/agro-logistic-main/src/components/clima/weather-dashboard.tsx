"use client";

import Link from "next/link";
import { ExternalLink, MapPinned } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { WeatherAgroScore } from "@/components/clima/weather-agro-score";
import { WeatherAiRecommendations } from "@/components/clima/weather-ai-recommendations";
import { WeatherAlerts } from "@/components/clima/weather-alerts";
import { WeatherCharts } from "@/components/clima/weather-charts";
import { WeatherCurrentCard } from "@/components/clima/weather-current-card";
import { WeatherEmptyState } from "@/components/clima/weather-empty-state";
import { WeatherForecastList } from "@/components/clima/weather-forecast-list";
import { WeatherLocationWarning } from "@/components/clima/weather-location-warning";
import { WeatherRefreshButton } from "@/components/clima/weather-refresh-button";
import { WeatherSummaryCards } from "@/components/clima/weather-summary-cards";
import type { NormalizedWeather, WeatherAiRecommendations as Recommendations, WeatherApiResponse } from "@/lib/weather-types";

type AnalysisResult = {
  recommendations: Recommendations;
  source: "openai" | "fallback";
  warning: string | null;
};

function getApiError(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string") {
    return payload.error;
  }

  if (payload && typeof payload === "object" && "message" in payload && typeof payload.message === "string") {
    return payload.message;
  }

  return fallback;
}

export function WeatherDashboard({
  initialResult,
  initialAnalysis,
}: {
  initialResult: WeatherApiResponse;
  initialAnalysis: AnalysisResult | null;
}) {
  const [weather, setWeather] = useState<NormalizedWeather | null>(initialResult.weather ?? null);
  const [status, setStatus] = useState(initialResult.status);
  const [analysis, setAnalysis] = useState<Recommendations | null>(initialAnalysis?.recommendations ?? null);
  const [analysisWarning, setAnalysisWarning] = useState<string | null>(initialAnalysis?.warning ?? null);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(initialResult.status === "READY" ? null : initialResult.message ?? null);

  async function analyze() {
    setAnalyzing(true);
    const response = await fetch("/api/clima/analyze", { method: "POST" });
    const payload = await response.json().catch(() => null);
    setAnalyzing(false);

    if (!response.ok) {
      const message = getApiError(payload, "Recomendações inteligentes indisponíveis.");
      setAnalysisWarning(message);
      toast.warning(message);
      return;
    }

    setAnalysis(payload.analysis as Recommendations);
    setAnalysisWarning((payload.warning as string | null) ?? null);
  }

  async function refreshWeather() {
    setLoading(true);
    setError(null);

    const response = await fetch("/api/clima/refresh", { method: "POST" });
    const payload = await response.json().catch(() => null);
    setLoading(false);

    if (!response.ok) {
      const message = getApiError(payload, "Não foi possível atualizar o clima.");
      setError(message);
      toast.error(message);
      return;
    }

    const result = payload as WeatherApiResponse;
    setStatus(result.status);

    if (result.status !== "READY" || !result.weather) {
      setWeather(null);
      setError(result.message ?? "Complete a localização para buscar o clima.");
      return;
    }

    setWeather(result.weather);
    toast.success("Clima atualizado com sucesso.");
    await analyze();
  }

  if (status === "NO_FARM") {
    return <WeatherEmptyState />;
  }

  if (status === "MISSING_LOCATION") {
    return <WeatherLocationWarning />;
  }

  if (!weather) {
    return (
      <Card className="rounded-xl border-red-500/20 bg-red-500/10">
        <CardContent className="p-4 text-sm text-red-100">{error ?? "Não foi possível carregar o clima real."}</CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 rounded-xl border border-emerald-500/15 bg-card/70 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium">Clima agrícola da operação</p>
          <p className="text-sm text-muted-foreground">
            Dados reais da Open-Meteo para {weather.location.label}. {weather.fromCache ? `Cache de ${weather.cacheAgeMinutes} min.` : "Busca recém-executada."}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <WeatherRefreshButton loading={loading} onRefresh={refreshWeather} />
          <Button asChild variant="outline">
            <Link href="/fazenda">
              <MapPinned className="h-4 w-4" />
              Editar localização
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/fazenda">
              <ExternalLink className="h-4 w-4" />
              Ver fazenda
            </Link>
          </Button>
        </div>
      </div>

      {error ? (
        <Card className="rounded-xl border-red-500/20 bg-red-500/10">
          <CardContent className="p-4 text-sm text-red-100">{error}</CardContent>
        </Card>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[1fr_24rem]">
        <WeatherCurrentCard weather={weather} />
        <WeatherAgroScore agroScore={weather.agroScore} />
      </div>

      <WeatherSummaryCards weather={weather} />
      <WeatherForecastList forecast={weather.forecast} />
      <WeatherCharts forecast={weather.forecast} />
      <WeatherAlerts alerts={weather.alerts} />
      <WeatherAiRecommendations analysis={analysis} loading={analyzing} warning={analysisWarning} />

      <p className="rounded-lg border border-foreground/10 bg-card/60 p-3 text-xs text-muted-foreground">
        As recomendações são estimativas baseadas em dados climáticos e devem apoiar, não substituir, a decisão técnica no campo.
      </p>
    </div>
  );
}
