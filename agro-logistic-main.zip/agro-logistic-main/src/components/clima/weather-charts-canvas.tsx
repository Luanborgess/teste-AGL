"use client";

import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { WeatherDailyForecast } from "@/lib/weather-types";

type ChartRow = {
  date: string;
  tempMin: number;
  tempMax: number;
  chuva: number;
  umidade: number;
  vento: number;
};

const tooltipStyle = {
  background: "hsl(var(--card))",
  border: "1px solid hsl(var(--border))",
  borderRadius: "8px",
  color: "hsl(var(--foreground))",
};

export function WeatherChartsCanvas({ forecast }: { forecast: WeatherDailyForecast[] }) {
  const data: ChartRow[] = forecast.map((day) => ({
    date: new Date(`${day.date}T12:00:00`).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }),
    tempMin: day.temperatureMin ?? 0,
    tempMax: day.temperatureMax ?? 0,
    chuva: day.precipitationSum ?? 0,
    umidade: day.humidityMean ?? 0,
    vento: day.windSpeedMax ?? 0,
  }));

  return (
    <div className="grid gap-4 xl:grid-cols-2">
      <ChartCard title="Temperatura por dia">
        <LineChart data={data}>
          <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" />
          <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" tickLine={false} axisLine={false} />
          <YAxis stroke="hsl(var(--muted-foreground))" tickLine={false} axisLine={false} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend />
          <Line type="monotone" dataKey="tempMin" name="Mínima °C" stroke="#38bdf8" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="tempMax" name="Máxima °C" stroke="#f59e0b" strokeWidth={2} dot={false} />
        </LineChart>
      </ChartCard>

      <ChartCard title="Chuva prevista por dia">
        <BarChart data={data}>
          <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" />
          <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" tickLine={false} axisLine={false} />
          <YAxis stroke="hsl(var(--muted-foreground))" tickLine={false} axisLine={false} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend />
          <Bar dataKey="chuva" name="Chuva mm" fill="#10b981" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ChartCard>

      <ChartCard title="Umidade por dia">
        <LineChart data={data}>
          <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" />
          <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" tickLine={false} axisLine={false} />
          <YAxis stroke="hsl(var(--muted-foreground))" tickLine={false} axisLine={false} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend />
          <Line type="monotone" dataKey="umidade" name="Umidade %" stroke="#22c55e" strokeWidth={2} dot={false} />
        </LineChart>
      </ChartCard>

      <ChartCard title="Vento por dia">
        <LineChart data={data}>
          <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" />
          <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" tickLine={false} axisLine={false} />
          <YAxis stroke="hsl(var(--muted-foreground))" tickLine={false} axisLine={false} />
          <Tooltip contentStyle={tooltipStyle} />
          <Legend />
          <Line type="monotone" dataKey="vento" name="Vento km/h" stroke="#a78bfa" strokeWidth={2} dot={false} />
        </LineChart>
      </ChartCard>
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactElement }) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
      </CardHeader>
      <CardContent className="h-72 min-w-0">
        <ResponsiveContainer width="100%" height="100%" minWidth={0}>
          {children}
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
