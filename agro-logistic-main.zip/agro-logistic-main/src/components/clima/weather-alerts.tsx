import { AlertTriangle, CheckCircle2, Info, ShieldAlert } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { WeatherAlert } from "@/lib/weather-types";

const severityMap = {
  critical: { icon: ShieldAlert, className: "border-red-500/25 bg-red-500/10 text-red-100", label: "Crítico" },
  warning: { icon: AlertTriangle, className: "border-amber-500/25 bg-amber-500/10 text-amber-100", label: "Atenção" },
  info: { icon: Info, className: "border-sky-500/25 bg-sky-500/10 text-sky-100", label: "Info" },
  success: { icon: CheckCircle2, className: "border-emerald-500/25 bg-emerald-500/10 text-emerald-100", label: "Favorável" },
};

export function WeatherAlerts({ alerts }: { alerts: WeatherAlert[] }) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Alertas climáticos</CardTitle>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <div className="flex min-h-28 items-center justify-center rounded-lg border border-dashed border-foreground/10 bg-background/45 text-sm text-muted-foreground">
            Nenhum alerta climático foi calculado com os dados atuais.
          </div>
        ) : (
          <div className="grid gap-3 lg:grid-cols-2">
            {alerts.map((alert) => {
              const config = severityMap[alert.severity];
              const Icon = config.icon;

              return (
                <div key={alert.id} className={`rounded-lg border p-4 ${config.className}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex gap-3">
                      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
                      <div>
                        <p className="text-sm font-medium">{alert.title}</p>
                        <p className="mt-1 text-sm opacity-80">{alert.description}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="shrink-0 border-current/25 text-current">
                      {config.label}
                    </Badge>
                  </div>
                  <p className="mt-3 text-xs opacity-70">Base: {alert.evidence}</p>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
