import Link from "next/link";
import { Leaf } from "lucide-react";

const footerLinks = [
  { href: "#funcionalidades", label: "Funcionalidades" },
  { href: "#como-funciona", label: "Como funciona" },
  { href: "#planos", label: "Planos" },
  { href: "#faq", label: "FAQ" },
  { href: "/login", label: "Login" },
];

export function LandingFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-white/10 px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 lg:flex-row lg:items-start lg:justify-between">
        <div className="max-w-sm">
          <Link href="/" className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-md border border-emerald-400/25 bg-emerald-400/10 text-emerald-300">
              <Leaf className="h-5 w-5" />
            </span>
            <span className="font-semibold text-white">AgroLogistic</span>
          </Link>
          <p className="mt-4 text-sm leading-6 text-zinc-400">
            ERP agrícola SaaS para transformar dados da fazenda em decisões de produção, estoque, logística,
            financeiro, maquinário e equipe.
          </p>
          <p className="mt-4 text-xs text-zinc-500">MVP em desenvolvimento.</p>
        </div>
        <div className="flex flex-wrap gap-x-5 gap-y-3 text-sm text-zinc-400">
          {footerLinks.map((link) => (
            <Link key={link.href} href={link.href} className="transition hover:text-emerald-300">
              {link.label}
            </Link>
          ))}
        </div>
      </div>
      <div className="mx-auto mt-8 max-w-7xl border-t border-white/10 pt-6 text-xs text-zinc-500">
        © {year} AgroLogistic. Todos os direitos reservados.
      </div>
    </footer>
  );
}
