import type { LucideIcon } from "lucide-react";
import {
  BarChart3,
  Boxes,
  FileText,
  MapPinned,
  Route,
  Sprout,
  Tractor,
  UsersRound,
  WalletCards,
} from "lucide-react";
import { LandingSectionHeading } from "@/components/landing/landing-section-heading";

type Feature = {
  title: string;
  description: string;
  icon: LucideIcon;
};

const features: Feature[] = [
  {
    title: "Fazenda e talhões",
    description: "Gerencie a propriedade, áreas, culturas e talhões.",
    icon: MapPinned,
  },
  {
    title: "Produção agrícola",
    description: "Acompanhe plantio, colheita, produtividade e previsão de produção.",
    icon: Sprout,
  },
  {
    title: "Estoque geral",
    description: "Controle sementes, fertilizantes, defensivos, combustíveis, peças e produção colhida.",
    icon: Boxes,
  },
  {
    title: "Financeiro",
    description: "Veja receitas, despesas, lucro, custos por hectare e fluxo de caixa.",
    icon: WalletCards,
  },
  {
    title: "Logística",
    description: "Organize cargas, embarques, rotas, transportadoras e status de entrega.",
    icon: Route,
  },
  {
    title: "Maquinário",
    description: "Controle tratores, colheitadeiras, manutenções, horímetro e custos operacionais.",
    icon: Tractor,
  },
  {
    title: "Funcionários",
    description: "Gerencie equipe, escala, presença e alocação em atividades.",
    icon: UsersRound,
  },
  {
    title: "Relatórios",
    description: "Gere relatórios para tomada de decisão.",
    icon: FileText,
  },
];

export function LandingFeatureGrid() {
  return (
    <section id="funcionalidades" className="scroll-mt-24 px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <LandingSectionHeading
          eyebrow="Funcionalidades"
          title="Tudo que a operação precisa em um só lugar."
          description="O AgroLogistic conecta a rotina da fazenda com indicadores práticos para produção, estoque, logística e caixa."
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <article
              key={feature.title}
              className="group rounded-xl border border-white/10 bg-white/[0.035] p-5 transition duration-300 hover:-translate-y-1 hover:border-emerald-300/30 hover:bg-emerald-300/[0.055]"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-md border border-emerald-300/20 bg-emerald-300/10 text-emerald-300">
                <feature.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-5 text-base font-semibold text-white">{feature.title}</h3>
              <p className="mt-2 leading-6 text-zinc-400">{feature.description}</p>
              <BarChart3 className="mt-6 h-4 w-4 text-emerald-300/0 transition group-hover:text-emerald-300/80" />
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
