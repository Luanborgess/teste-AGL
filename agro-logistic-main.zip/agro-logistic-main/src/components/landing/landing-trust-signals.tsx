import { Factory, Leaf, PackageCheck, Route, UsersRound } from "lucide-react";

const segments = [
  { label: "Produtores rurais", icon: Leaf },
  { label: "Fazendas de soja", icon: Factory },
  { label: "Fazendas de café", icon: PackageCheck },
  { label: "Grãos", icon: PackageCheck },
  { label: "Operações logísticas", icon: Route },
  { label: "Gestão familiar rural", icon: UsersRound },
];

export function LandingTrustSignals() {
  return (
    <section className="border-y border-white/10 bg-white/[0.025]">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <p className="text-center text-sm font-medium text-zinc-400">
          Feito para operações agrícolas que precisam de clareza.
        </p>
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          {segments.map((segment) => (
            <div
              key={segment.label}
              className="flex items-center justify-center gap-2 rounded-md border border-white/10 bg-[#0a110d] px-3 py-3 text-sm text-zinc-300"
            >
              <segment.icon className="h-4 w-4 text-emerald-300" />
              <span className="text-center">{segment.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
