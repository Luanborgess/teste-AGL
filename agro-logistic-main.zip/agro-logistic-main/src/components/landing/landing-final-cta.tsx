import Link from "next/link";
import { ArrowRight, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";

type LandingFinalCTAProps = {
  primaryCtaHref: string;
};

export function LandingFinalCTA({ primaryCtaHref }: LandingFinalCTAProps) {
  return (
    <section className="px-4 pb-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl overflow-hidden rounded-2xl border border-emerald-300/20 bg-[radial-gradient(circle_at_top_left,rgba(52,211,153,0.18),transparent_25rem),#08100c] px-6 py-14 text-center shadow-2xl shadow-emerald-950/30 sm:px-10">
        <h2 className="mx-auto max-w-3xl text-3xl font-semibold tracking-tight text-white sm:text-5xl">
          Comece organizando sua fazenda com dados reais.
        </h2>
        <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-zinc-300">
          Preencha o perfil operacional e veja seu primeiro dashboard agrícola em poucos minutos.
        </p>
        <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <Button asChild className="h-11 bg-emerald-400 px-5 text-emerald-950 hover:bg-emerald-300">
            <Link href={primaryCtaHref}>
              Começar agora
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" className="h-11 border-white/10 bg-white/5 px-5 text-white hover:bg-white/10">
            <Link href="/login">
              Entrar
              <LogIn className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
