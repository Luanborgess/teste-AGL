import { Database, LockKeyhole, ShieldCheck, SlidersHorizontal } from "lucide-react";
import { LandingSectionHeading } from "@/components/landing/landing-section-heading";

const items = [
  {
    title: "Dados por usuário",
    description: "Cada conta acessa apenas seus próprios dados.",
    icon: LockKeyhole,
  },
  {
    title: "Banco de dados real",
    description: "As informações são persistidas e não desaparecem ao atualizar a página.",
    icon: Database,
  },
  {
    title: "Controle operacional",
    description: "Nada é movimentado automaticamente; o sistema organiza e calcula.",
    icon: SlidersHorizontal,
  },
  {
    title: "Pronto para evoluir",
    description: "Estrutura preparada para autenticação, permissões e multi-tenant.",
    icon: ShieldCheck,
  },
];

export function LandingSecurity() {
  return (
    <section id="seguranca" className="scroll-mt-24 px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <LandingSectionHeading
          eyebrow="Segurança"
          title="Segurança para dados críticos da fazenda."
          description="Sem promessas infladas: o foco atual é separar dados por usuário, persistir informações reais e manter controle explícito sobre cada registro."
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((item) => (
            <article key={item.title} className="rounded-xl border border-white/10 bg-white/[0.035] p-5">
              <item.icon className="h-5 w-5 text-emerald-300" />
              <h3 className="mt-5 font-semibold text-white">{item.title}</h3>
              <p className="mt-2 leading-6 text-zinc-400">{item.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
