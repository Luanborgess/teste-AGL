import { ArrowRight, Boxes, Gauge, Leaf, Route, Tractor, UsersRound, WalletCards } from "lucide-react";
import { LandingSectionHeading } from "@/components/landing/landing-section-heading";

const connections = [
  { title: "Talhão", detail: "cultivo, custo e produtividade", icon: Leaf },
  { title: "Estoque", detail: "saídas afetam custo de produção", icon: Boxes },
  { title: "Máquina", detail: "gera custo operacional", icon: Tractor },
  { title: "Equipe", detail: "alocada em atividades", icon: UsersRound },
  { title: "Carga", detail: "vai da produção à logística", icon: Route },
  { title: "Financeiro", detail: "consolida receitas e despesas", icon: WalletCards },
];

export function LandingOperationalIntelligence() {
  return (
    <section className="px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
        <LandingSectionHeading
          align="left"
          eyebrow="Inteligência operacional"
          title="Da produção ao caixa, tudo conectado."
          description="Uma decisão no campo impacta estoque, custo, logística, equipe e resultado. A landing mostra a promessa; o app mantém essa conexão usando dados registrados pelo usuário."
        />

        <div className="relative">
          <div className="absolute inset-8 rounded-full bg-emerald-400/10 blur-3xl" />
          <div className="relative grid gap-3 sm:grid-cols-2">
            {connections.map((item) => (
              <div key={item.title} className="rounded-xl border border-white/10 bg-white/[0.035] p-4">
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-md bg-emerald-300/10 text-emerald-300">
                    <item.icon className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="font-semibold text-white">{item.title}</h3>
                    <p className="mt-1 text-sm leading-6 text-zinc-400">{item.detail}</p>
                  </div>
                </div>
              </div>
            ))}
            <div className="rounded-xl border border-emerald-300/25 bg-emerald-300/10 p-4 sm:col-span-2">
              <div className="flex items-center gap-3">
                <Gauge className="h-5 w-5 text-emerald-200" />
                <p className="font-semibold text-white">Dashboard consolida tudo</p>
                <ArrowRight className="ml-auto h-4 w-4 text-emerald-200" />
              </div>
              <p className="mt-2 text-sm text-emerald-50/70">
                Indicadores, alertas, relatórios e previsões partem do perfil operacional e dos módulos persistidos no banco.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
