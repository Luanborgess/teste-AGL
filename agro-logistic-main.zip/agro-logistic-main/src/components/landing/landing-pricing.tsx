import Link from "next/link";
import { Check, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LandingSectionHeading } from "@/components/landing/landing-section-heading";

type LandingPricingProps = {
  primaryCtaHref: string;
};

const plans = [
  {
    name: "Starter",
    subtitle: "Para testar a gestão da fazenda.",
    tag: "Em breve",
    items: ["1 fazenda", "Talhões", "Dashboard", "Produção", "Estoque básico", "Financeiro básico"],
    href: "/login",
    action: "Começar agora",
    featured: false,
  },
  {
    name: "Pro",
    subtitle: "Para operação agrícola completa.",
    tag: "MVP",
    items: ["Tudo do Starter", "Logística", "Maquinário", "Funcionários", "Relatórios", "Alertas"],
    href: "primary",
    action: "Começar agora",
    featured: true,
  },
  {
    name: "Enterprise",
    subtitle: "Para operações maiores.",
    tag: "Fale conosco",
    items: ["Multiusuário", "Permissões", "Integrações", "Suporte personalizado"],
    href: "/login",
    action: "Solicitar acesso",
    featured: false,
  },
];

export function LandingPricing({ primaryCtaHref }: LandingPricingProps) {
  return (
    <section id="planos" className="scroll-mt-24 border-y border-white/10 bg-white/[0.025] px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <LandingSectionHeading
          eyebrow="Planos"
          title="Escolha o plano ideal para sua operação."
          description="Planos simples para o MVP, sem preço fixo enquanto a oferta comercial ainda está em desenvolvimento."
        />
        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {plans.map((plan) => {
            const href = plan.href === "primary" ? primaryCtaHref : plan.href;

            return (
              <article
                key={plan.name}
                className={
                  plan.featured
                    ? "rounded-xl border border-emerald-300/35 bg-emerald-300/[0.075] p-6 shadow-2xl shadow-emerald-950/30"
                    : "rounded-xl border border-white/10 bg-[#08100c] p-6"
                }
              >
                <div className="flex items-center justify-between gap-4">
                  <h3 className="text-2xl font-semibold text-white">{plan.name}</h3>
                  <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-emerald-200">
                    {plan.tag}
                  </span>
                </div>
                <p className="mt-3 text-zinc-400">{plan.subtitle}</p>
                <p className="mt-8 text-3xl font-semibold text-white">Sob consulta</p>
                <ul className="mt-7 space-y-3">
                  {plan.items.map((item) => (
                    <li key={item} className="flex gap-3 text-sm text-zinc-300">
                      <Check className="mt-0.5 h-4 w-4 text-emerald-300" />
                      {item}
                    </li>
                  ))}
                </ul>
                <Button
                  asChild
                  className={
                    plan.featured
                      ? "mt-8 h-10 w-full bg-emerald-400 text-emerald-950 hover:bg-emerald-300"
                      : "mt-8 h-10 w-full border-white/10 bg-white/5 text-white hover:bg-white/10"
                  }
                  variant={plan.featured ? "default" : "outline"}
                >
                  <Link href={href}>
                    {plan.action}
                    <Send className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
