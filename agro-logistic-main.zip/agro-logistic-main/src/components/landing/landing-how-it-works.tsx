import { LandingSectionHeading } from "@/components/landing/landing-section-heading";

const steps = [
  {
    number: "01",
    title: "Cadastre sua fazenda",
    description: "Preencha área, cultura principal, produtividade, custos e estrutura operacional.",
  },
  {
    number: "02",
    title: "Registre a operação",
    description: "Adicione produção, estoque, financeiro, máquinas, equipe e logística conforme a rotina da fazenda.",
  },
  {
    number: "03",
    title: "Tome decisões com dados reais",
    description: "Veja indicadores, alertas, relatórios e previsões para agir antes do problema aparecer.",
  },
];

export function LandingHowItWorks() {
  return (
    <section
      id="como-funciona"
      className="scroll-mt-24 border-y border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.035),rgba(255,255,255,0.015))] px-4 py-24 sm:px-6 lg:px-8"
    >
      <div className="mx-auto max-w-7xl">
        <LandingSectionHeading
          eyebrow="Como funciona"
          title="Configure em minutos. Decida com clareza todos os dias."
          description="O MVP foi pensado para começar simples: primeiro o perfil operacional, depois os registros reais da rotina."
        />
        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {steps.map((step) => (
            <article key={step.number} className="rounded-xl border border-white/10 bg-[#08100c] p-6">
              <span className="font-mono text-sm text-emerald-300">{step.number}</span>
              <h3 className="mt-8 text-xl font-semibold text-white">{step.title}</h3>
              <p className="mt-3 leading-7 text-zinc-400">{step.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
