import { Calculator, CheckCircle2 } from "lucide-react";
import { LandingSectionHeading } from "@/components/landing/landing-section-heading";

const inputs = [
  ["Área produtiva", "850 ha"],
  ["Produtividade", "60 sacas/ha"],
  ["Preço da saca", "R$ 125"],
  ["Custos estimados", "R$ 4.800.000"],
];

const results = [
  ["Produção estimada", "51.000 sacas"],
  ["Receita prevista", "R$ 6.375.000"],
  ["Lucro estimado", "R$ 1.575.000"],
  ["Cargas necessárias", "102"],
  ["Meses para escoar", "5,1"],
];

export function LandingExampleCalculation() {
  return (
    <section className="border-y border-white/10 bg-white/[0.025] px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <LandingSectionHeading
          eyebrow="Exemplo de resultado"
          title="Transforme dados simples em decisões claras."
          description="Exemplo de cálculo com cenário fixo de operação. No app, os números vêm do perfil e dos registros do usuário."
        />
        <div className="mt-12 grid gap-5 lg:grid-cols-[0.86fr_1.14fr]">
          <div className="rounded-xl border border-white/10 bg-[#08100c] p-6">
            <div className="flex items-center gap-3">
              <Calculator className="h-5 w-5 text-emerald-300" />
              <h3 className="text-lg font-semibold text-white">Dados informados</h3>
            </div>
            <div className="mt-6 space-y-3">
              {inputs.map(([label, value]) => (
                <div key={label} className="flex items-center justify-between gap-4 border-b border-white/10 pb-3 last:border-0">
                  <span className="text-zinc-400">{label}</span>
                  <span className="font-medium text-white">{value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            {results.map(([label, value]) => (
              <div key={label} className="rounded-xl border border-emerald-300/15 bg-emerald-300/[0.055] p-5">
                <CheckCircle2 className="h-4 w-4 text-emerald-300" />
                <p className="mt-5 text-sm text-emerald-50/65">{label}</p>
                <p className="mt-1 text-2xl font-semibold tracking-tight text-white">{value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
