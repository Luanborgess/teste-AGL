import { ChevronDown } from "lucide-react";
import { LandingSectionHeading } from "@/components/landing/landing-section-heading";

const faqs = [
  {
    question: "O AgroLogistic é para qual tipo de fazenda?",
    answer:
      "Ele foi pensado para produtores e operações agrícolas que precisam organizar produção, estoque, logística, financeiro, equipe e maquinário em um fluxo simples.",
  },
  {
    question: "Preciso cadastrar várias fazendas?",
    answer:
      "No MVP, o foco é uma fazenda por conta. A estrutura foi preparada para evoluir para operações maiores conforme o produto amadurece.",
  },
  {
    question: "O sistema funciona para soja, café e outras culturas?",
    answer:
      "Sim. O perfil operacional permite informar a cultura principal e os módulos podem registrar cultivos diferentes conforme a rotina da fazenda.",
  },
  {
    question: "Os dados do dashboard são reais?",
    answer:
      "Sim. O dashboard usa o questionário operacional e os registros criados pelo usuário. Quando um dado falta, o sistema evita inventar números.",
  },
  {
    question: "Posso controlar estoque geral, não só sacas?",
    answer:
      "Sim. O módulo de estoque controla itens como sementes, fertilizantes, defensivos, combustíveis, peças e produção colhida.",
  },
  {
    question: "O sistema já substitui um ERP completo?",
    answer:
      "Ainda não. O AgroLogistic é um MVP testável, com módulos reais e persistência, mas ainda precisa evoluir em permissões, multiempresa, auditoria e integrações.",
  },
  {
    question: "Posso usar no celular?",
    answer:
      "Sim. A interface é responsiva e pode ser usada no navegador do celular, embora algumas rotinas operacionais fiquem mais confortáveis em telas maiores.",
  },
  {
    question: "Como começo?",
    answer:
      "Entre pelo login, preencha o perfil operacional da fazenda e abra o dashboard para ver os primeiros indicadores com base nos seus dados.",
  },
];

export function LandingFAQ() {
  return (
    <section id="faq" className="scroll-mt-24 px-4 py-24 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        <LandingSectionHeading eyebrow="FAQ" title="Tudo que você precisa saber para começar." />
        <div className="mt-10 divide-y divide-white/10 rounded-xl border border-white/10 bg-white/[0.035]">
          {faqs.map((faq) => (
            <details key={faq.question} className="group p-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-left font-medium text-white">
                {faq.question}
                <ChevronDown className="h-4 w-4 text-emerald-300 transition group-open:rotate-180" />
              </summary>
              <p className="mt-4 leading-7 text-zinc-400">{faq.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
