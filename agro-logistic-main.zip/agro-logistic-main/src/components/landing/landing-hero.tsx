import Link from "next/link";
import { ArrowRight, BarChart3, CheckCircle2, CircleDollarSign, Database, Route, Sprout } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type LandingHeroProps = {
  primaryCtaHref: string;
  demoHref: string;
};

const heroMetrics = [
  { label: "Produção prevista", value: "51.000 sacas", icon: Sprout },
  { label: "Receita estimada", value: "R$ 6,3M", icon: CircleDollarSign },
  { label: "Cargas necessárias", value: "102", icon: Route },
  { label: "Estoque atual", value: "5.000 sacas", icon: Database },
];

const chartBars = [
  { label: "Produção", height: "78%" },
  { label: "Receita", height: "92%" },
  { label: "Estoque", height: "42%" },
  { label: "Cargas", height: "64%" },
];

export function LandingHero({ primaryCtaHref, demoHref }: LandingHeroProps) {
  return (
    <section className="relative">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_18%_14%,rgba(52,211,153,0.22),transparent_28rem),radial-gradient(circle_at_82%_26%,rgba(132,204,22,0.11),transparent_24rem),linear-gradient(180deg,#050806_0%,#08110b_58%,#050806_100%)]" />
      <div className="absolute inset-x-0 top-0 -z-10 h-px bg-gradient-to-r from-transparent via-emerald-300/40 to-transparent" />

      <div className="mx-auto grid max-w-7xl gap-12 px-4 pb-20 pt-14 sm:px-6 sm:pt-20 lg:grid-cols-[0.94fr_1.06fr] lg:items-center lg:px-8 lg:pb-28">
        <div className="space-y-8">
          <Badge className="h-7 border border-emerald-300/20 bg-emerald-300/10 px-3 text-emerald-200 hover:bg-emerald-300/10">
            ERP agrícola inteligente
          </Badge>

          <div className="space-y-5">
            <h1 className="max-w-4xl text-5xl font-semibold leading-[1.02] tracking-tight text-white sm:text-6xl lg:text-7xl">
              Veja o futuro da sua fazenda, não apenas o passado.
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-zinc-300 sm:text-xl">
              Controle produção, estoque, logística, financeiro, equipe e maquinário com dados reais da sua operação agrícola.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button asChild className="h-11 bg-emerald-400 px-5 text-emerald-950 hover:bg-emerald-300">
                <Link href={primaryCtaHref}>
                  Começar agora
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                className="h-11 border-white/12 bg-white/5 px-5 text-white hover:bg-white/10"
              >
                <Link href={demoHref}>Ver demonstração</Link>
              </Button>
            </div>
            <p className="text-sm text-zinc-500">Sem planilhas confusas. Sem dados soltos. Tudo conectado em um só painel.</p>
          </div>
        </div>

        <div className="relative">
          <div className="absolute -inset-4 rounded-[2rem] bg-emerald-400/10 blur-3xl" />
          <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.055] shadow-2xl shadow-emerald-950/50 backdrop-blur">
            <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-amber-300/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-300/80" />
              </div>
              <Badge variant="outline" className="border-emerald-300/30 text-emerald-200">
                Dados reais da fazenda
              </Badge>
            </div>

            <div className="space-y-4 p-4 sm:p-5">
              <div className="flex flex-col gap-3 rounded-xl border border-white/10 bg-[#09130d]/80 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.18em] text-emerald-300/70">Exemplo de operação</p>
                  <p className="mt-2 text-xl font-semibold text-white">Fazenda Mais Soja</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-zinc-300">
                  <CheckCircle2 className="h-4 w-4 text-emerald-300" />
                  Perfil operacional preenchido
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                {heroMetrics.map((metric) => (
                  <div
                    key={metric.label}
                    className="rounded-xl border border-white/10 bg-white/[0.035] p-4 transition hover:border-emerald-300/25 hover:bg-emerald-300/[0.055]"
                  >
                    <metric.icon className="h-4 w-4 text-emerald-300" />
                    <p className="mt-4 text-sm text-zinc-400">{metric.label}</p>
                    <p className="mt-1 text-2xl font-semibold tracking-tight text-white">{metric.value}</p>
                  </div>
                ))}
              </div>

              <div className="rounded-xl border border-white/10 bg-[#08100c] p-4">
                <div className="mb-5 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-white">Painel consolidado</p>
                    <p className="text-sm text-zinc-500">Produção, caixa, estoque e logística</p>
                  </div>
                  <BarChart3 className="h-5 w-5 text-emerald-300" />
                </div>
                <div className="flex h-40 items-end gap-3 rounded-lg border border-white/5 bg-white/[0.025] p-4">
                  {chartBars.map((bar) => (
                    <div key={bar.label} className="flex h-full flex-1 flex-col justify-end gap-2">
                      <div
                        className="rounded-t-md bg-gradient-to-t from-emerald-500 to-lime-300 shadow-[0_0_24px_rgba(52,211,153,0.22)]"
                        style={{ height: bar.height }}
                      />
                      <span className="truncate text-center text-[11px] text-zinc-500">{bar.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
