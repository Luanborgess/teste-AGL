"use client";

import Link from "next/link";
import { ArrowRight, Leaf, Menu } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "#funcionalidades", label: "Funcionalidades" },
  { href: "#como-funciona", label: "Como funciona" },
  { href: "#seguranca", label: "Segurança" },
  { href: "#planos", label: "Planos" },
  { href: "#faq", label: "FAQ" },
];

type LandingNavbarProps = {
  primaryCtaHref: string;
};

export function LandingNavbar({ primaryCtaHref }: LandingNavbarProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#050806]/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-3" aria-label="AgroLogistic">
          <span className="flex h-10 w-10 items-center justify-center rounded-md border border-emerald-400/25 bg-emerald-400/10 text-emerald-300 shadow-[0_0_30px_rgba(52,211,153,0.16)]">
            <Leaf className="h-5 w-5" />
          </span>
          <span className="text-base font-semibold tracking-tight text-white">AgroLogistic</span>
        </Link>

        <nav className="hidden items-center gap-7 text-sm text-zinc-300 lg:flex" aria-label="Navegação principal">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className="transition hover:text-emerald-300">
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <Button asChild variant="ghost" className="text-zinc-200 hover:bg-white/5 hover:text-white">
            <Link href="/login">Entrar</Link>
          </Button>
          <Button asChild className="bg-emerald-400 text-emerald-950 hover:bg-emerald-300">
            <Link href={primaryCtaHref}>
              Começar agora
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="outline"
              size="icon"
              className="border-white/10 bg-white/5 text-white hover:bg-white/10 lg:hidden"
              aria-label="Abrir menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent className="border-white/10 bg-[#07100b] text-white">
            <SheetHeader>
              <SheetTitle className="text-white">AgroLogistic</SheetTitle>
              <SheetDescription className="text-zinc-400">
                ERP agrícola inteligente para operação, caixa e logística.
              </SheetDescription>
            </SheetHeader>
            <nav className="grid gap-2 px-4" aria-label="Navegação mobile">
              {navItems.map((item) => (
                <SheetClose key={item.href} asChild>
                  <Link
                    href={item.href}
                    className="rounded-md border border-white/10 bg-white/[0.03] px-4 py-3 text-sm font-medium text-zinc-200 transition hover:border-emerald-400/30 hover:bg-emerald-400/10 hover:text-emerald-200"
                  >
                    {item.label}
                  </Link>
                </SheetClose>
              ))}
            </nav>
            <div className="mt-auto grid gap-2 p-4">
              <SheetClose asChild>
                <Link
                  href="/login"
                  className={cn(
                    buttonVariants({ variant: "outline" }),
                    "border-white/10 bg-white/5 text-white hover:bg-white/10"
                  )}
                >
                  Entrar
                </Link>
              </SheetClose>
              <SheetClose asChild>
                <Link
                  href={primaryCtaHref}
                  className={cn(buttonVariants(), "bg-emerald-400 text-emerald-950 hover:bg-emerald-300")}
                >
                  Começar agora
                </Link>
              </SheetClose>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
