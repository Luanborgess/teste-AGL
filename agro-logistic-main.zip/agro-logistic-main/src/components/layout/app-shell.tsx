import Link from "next/link";
import {
  Boxes,
  ClipboardList,
  CloudSun,
  FileText,
  LayoutDashboard,
  Leaf,
  LogOut,
  MapPinned,
  Route,
  Sprout,
  Tractor,
  UsersRound,
  WalletCards,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/layout/theme-toggle";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/fazenda", label: "Fazenda", icon: MapPinned },
  { href: "/clima", label: "Clima", icon: CloudSun },
  { href: "/producao", label: "Produção", icon: Sprout },
  { href: "/maquinario", label: "Maquinario", icon: Tractor },
  { href: "/funcionarios", label: "Funcionarios", icon: UsersRound },
  { href: "/financeiro", label: "Financeiro", icon: WalletCards },
  { href: "/estoque", label: "Estoque", icon: Boxes },
  { href: "/logistica", label: "Logística", icon: Route },
  { href: "/relatorios", label: "Relatórios", icon: FileText },
  { href: "/onboarding", label: "Perfil operacional", icon: ClipboardList },
];

export function AppShell({
  children,
  title,
  subtitle,
}: {
  children: React.ReactNode;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,0.16),transparent_28rem),linear-gradient(135deg,hsl(var(--background)),hsl(var(--muted)))]">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-72 border-r border-emerald-500/15 bg-sidebar/95 px-4 py-5 backdrop-blur lg:block">
        <Link href="/dashboard" className="flex items-center gap-3 px-2">
          <span className="flex h-11 w-11 items-center justify-center rounded-md border border-emerald-400/30 bg-emerald-500/15 text-emerald-300">
            <Leaf className="h-5 w-5" />
          </span>
          <span>
            <span className="block text-lg font-semibold tracking-tight">AgroLogistic</span>
            <span className="text-xs text-muted-foreground">Gestão Rural</span>
          </span>
        </Link>

        <nav className="mt-10 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium text-sidebar-foreground/75 transition hover:bg-emerald-500/10 hover:text-emerald-300"
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="absolute bottom-5 left-4 right-4 rounded-md border border-emerald-500/15 bg-emerald-500/10 p-4">
          <p className="text-sm font-medium">Operação conectada</p>
          <p className="mt-1 text-xs text-muted-foreground">
            MVP local com dados reais do seu perfil e módulos.
          </p>
        </div>
      </aside>

      <div className="lg:pl-72">
        <header className="sticky top-0 z-10 border-b border-emerald-500/10 bg-background/80 backdrop-blur">
          <div className="flex min-h-16 items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
            <div>
              <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">{title}</h1>
              <p className="text-sm text-muted-foreground">{subtitle}</p>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button asChild variant="ghost" size="icon" title="Sair">
                <Link href="/login">
                  <LogOut className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </header>
        <main className="px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
