"use client";

import { AlertTriangle, Boxes, CalendarClock, CircleDollarSign, Repeat2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrencyBRL, formatInteger } from "@/lib/formatters";

type InventorySummary = {
  totalItems: number;
  stockAlerts: number;
  totalValue: number;
  expiringItems: number;
  monthlyMovements: number;
};

const cards = [
  {
    key: "totalItems",
    label: "Total de Itens",
    helper: "Produtos cadastrados",
    icon: Boxes,
    tone: "text-emerald-300 bg-emerald-500/10 border-emerald-500/20",
  },
  {
    key: "stockAlerts",
    label: "Alertas de Estoque",
    helper: "Baixo estoque ou critico",
    icon: AlertTriangle,
    tone: "text-amber-300 bg-amber-500/10 border-amber-500/20",
  },
  {
    key: "totalValue",
    label: "Valor Total em Estoque",
    helper: "Quantidade atual x custo",
    icon: CircleDollarSign,
    tone: "text-sky-300 bg-sky-500/10 border-sky-500/20",
  },
  {
    key: "expiringItems",
    label: "Itens Vencendo",
    helper: "Validade nos proximos 30 dias",
    icon: CalendarClock,
    tone: "text-orange-300 bg-orange-500/10 border-orange-500/20",
  },
  {
    key: "monthlyMovements",
    label: "Movimentacoes do Mes",
    helper: "Entradas, saidas, consumo e perdas",
    icon: Repeat2,
    tone: "text-violet-300 bg-violet-500/10 border-violet-500/20",
  },
] as const;

export function InventorySummaryCards({ summary }: { summary: InventorySummary }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
      {cards.map((card) => {
        const Icon = card.icon;
        const value = card.key === "totalValue" ? formatCurrencyBRL(summary[card.key]) : formatInteger(summary[card.key]);

        return (
          <Card
            key={card.key}
            className="rounded-xl border-foreground/10 bg-card/80 transition duration-200 hover:-translate-y-0.5 hover:border-emerald-500/20"
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm text-muted-foreground">{card.label}</p>
                  <p className="mt-2 text-2xl font-semibold tracking-tight">{value}</p>
                </div>
                <span className={`flex h-10 w-10 items-center justify-center rounded-lg border ${card.tone}`}>
                  <Icon className="h-5 w-5" />
                </span>
              </div>
              <p className="mt-4 text-xs text-muted-foreground">{card.helper}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
