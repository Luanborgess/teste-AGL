"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import {
  inventoryCategoryLabels,
  inventoryUnitLabels,
  type SerializedInventoryItem,
} from "@/lib/inventory-calculations";
import {
  inventoryItemSchema,
  type InventoryCategoryValue,
  type InventoryItemInput,
  type InventoryItemValues,
  type InventoryUnitValue,
} from "@/lib/validations";

const emptyValues: InventoryItemInput = {
  name: "",
  category: "FERTILIZANTES",
  unit: "kg",
  quantity: 0,
  minimumStock: 0,
  unitCost: 0,
  supplier: "",
  expirationDate: "",
  location: "",
  sku: "",
  notes: "",
};

function valuesFromItem(item: SerializedInventoryItem | null): InventoryItemInput {
  if (!item) {
    return emptyValues;
  }

  return {
    name: item.name,
    category: item.category,
    unit: item.unit,
    quantity: item.quantity,
    minimumStock: item.minimumStock,
    unitCost: item.unitCost,
    supplier: item.supplier ?? "",
    expirationDate: item.expirationDate ? new Date(item.expirationDate).toISOString().slice(0, 10) : "",
    location: item.location ?? "",
    sku: item.sku ?? "",
    notes: item.notes ?? "",
  };
}

export function InventoryFormModal({
  open,
  item,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  item: SerializedInventoryItem | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: InventoryItemValues) => Promise<void>;
}) {
  const form = useForm<InventoryItemInput, unknown, InventoryItemValues>({
    resolver: zodResolver(inventoryItemSchema),
    defaultValues: valuesFromItem(item),
  });
  const category = useWatch({ control: form.control, name: "category" });
  const unit = useWatch({ control: form.control, name: "unit" });

  useEffect(() => {
    if (open) {
      form.reset(valuesFromItem(item));
    }
  }, [form, item, open]);

  async function submit(values: InventoryItemValues) {
    await onSubmit(values);

    if (!item) {
      form.reset(emptyValues);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>{item ? "Editar item" : "Novo item"}</DialogTitle>
          <DialogDescription>
            Cadastre apenas dados reais da fazenda. Os indicadores e alertas serao recalculados ao salvar.
          </DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Nome do produto" error={form.formState.errors.name?.message}>
            <TextInput disabled={saving} placeholder="Fertilizante NPK 20-05-20" {...form.register("name")} />
          </Field>

          <Field label="Categoria" error={form.formState.errors.category?.message}>
            <Select
              disabled={saving}
              value={category}
              onValueChange={(value) => form.setValue("category", value as InventoryCategoryValue, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(inventoryCategoryLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Unidade de medida" error={form.formState.errors.unit?.message}>
            <Select
              disabled={saving}
              value={unit}
              onValueChange={(value) => form.setValue("unit", value as InventoryUnitValue, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(inventoryUnitLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Quantidade atual" error={form.formState.errors.quantity?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("quantity")} />
          </Field>

          <Field label="Estoque minimo" error={form.formState.errors.minimumStock?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("minimumStock")} />
          </Field>

          <Field label="Custo unitario" error={form.formState.errors.unitCost?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" placeholder="4.50" {...form.register("unitCost")} />
          </Field>

          <Field label="Fornecedor" error={form.formState.errors.supplier?.message}>
            <TextInput disabled={saving} placeholder="AgroFornecedora" {...form.register("supplier")} />
          </Field>

          <Field label="Data de validade" error={form.formState.errors.expirationDate?.message}>
            <TextInput disabled={saving} type="date" {...form.register("expirationDate")} />
          </Field>

          <Field label="Localizacao no estoque" error={form.formState.errors.location?.message}>
            <TextInput disabled={saving} placeholder="Galpao 1" {...form.register("location")} />
          </Field>

          <Field label="Codigo interno ou SKU" error={form.formState.errors.sku?.message}>
            <TextInput disabled={saving} placeholder="NPK-20-05-20" {...form.register("sku")} />
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Lote, cuidados, armazenamento ou detalhes importantes." {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
