"use client";

import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  calculateInventorySituation,
  calculateInventoryValue,
  inventoryCategoryLabels,
  inventoryMovementTypeLabels,
  inventorySituationLabels,
  type SerializedInventoryItem,
} from "@/lib/inventory-calculations";
import { formatCurrencyBRL, formatDateBR } from "@/lib/formatters";

function field(label: string, value: React.ReactNode) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-background/45 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <div className="mt-1 text-sm font-medium">{value}</div>
    </div>
  );
}

export function InventoryDetailsModal({
  item,
  onOpenChange,
}: {
  item: SerializedInventoryItem | null;
  onOpenChange: (open: boolean) => void;
}) {
  const situation = item ? calculateInventorySituation(item) : null;

  return (
    <Dialog open={Boolean(item)} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{item?.name ?? "Detalhes do item"}</DialogTitle>
          <DialogDescription>Dados cadastrais, saldo atual e ultimas movimentacoes.</DialogDescription>
        </DialogHeader>

        {item && situation ? (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="border-emerald-500/20 bg-emerald-500/10 text-emerald-300">
                {inventoryCategoryLabels[item.category]}
              </Badge>
              <Badge variant="outline">{inventorySituationLabels[situation]}</Badge>
              {item.sku ? <Badge variant="secondary">{item.sku}</Badge> : null}
            </div>

            <div className="grid gap-3 md:grid-cols-3">
              {field("Quantidade atual", `${item.quantity} ${item.unit}`)}
              {field("Estoque minimo", `${item.minimumStock} ${item.unit}`)}
              {field("Valor total", formatCurrencyBRL(calculateInventoryValue(item)))}
              {field("Custo unitario", formatCurrencyBRL(item.unitCost))}
              {field("Fornecedor", item.supplier || "Nao informado")}
              {field("Validade", item.expirationDate ? formatDateBR(item.expirationDate) : "Sem validade")}
              {field("Localizacao", item.location || "Nao informada")}
              {field("Criado em", formatDateBR(item.createdAt))}
              {field("Atualizado em", formatDateBR(item.updatedAt))}
            </div>

            {item.notes ? (
              <div className="rounded-lg border border-foreground/10 bg-background/45 p-3">
                <p className="text-xs text-muted-foreground">Observacoes</p>
                <p className="mt-1 text-sm">{item.notes}</p>
              </div>
            ) : null}

            <div className="rounded-xl border border-foreground/10 bg-background/45 p-4">
              <p className="font-medium">Ultimas movimentacoes</p>
              <div className="mt-3 space-y-2">
                {item.movements.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nenhuma movimentacao registrada para este item.</p>
                ) : (
                  item.movements.slice(0, 5).map((movement) => (
                    <div key={movement.id} className="flex flex-col gap-1 rounded-lg border border-foreground/10 p-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="text-sm font-medium">{inventoryMovementTypeLabels[movement.type]}</p>
                        <p className="text-xs text-muted-foreground">{movement.notes || movement.reason || movement.originOrDestination || "Sem observacoes"}</p>
                      </div>
                      <p className="font-mono text-sm">
                        {movement.quantity} {item.unit} - {formatDateBR(movement.occurredAt)}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
