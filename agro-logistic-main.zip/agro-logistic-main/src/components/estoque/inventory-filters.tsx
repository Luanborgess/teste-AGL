"use client";

import { Filter, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  inventoryCategoryLabels,
  inventorySituationLabels,
  type InventorySituation,
} from "@/lib/inventory-calculations";
import type { InventoryCategoryValue } from "@/lib/validations";

export type InventoryFiltersState = {
  search: string;
  category: InventoryCategoryValue | "ALL";
  situation: InventorySituation | "ALL";
};

export function InventoryFilters({
  filters,
  onChange,
}: {
  filters: InventoryFiltersState;
  onChange: (filters: InventoryFiltersState) => void;
}) {
  return (
    <div className="grid gap-3 rounded-xl border border-foreground/10 bg-card/80 p-4 lg:grid-cols-[1fr_14rem_14rem]">
      <label className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={filters.search}
          onChange={(event) => onChange({ ...filters, search: event.target.value })}
          className="bg-background/70 pl-9"
          placeholder="Pesquisar produto, fornecedor ou localizacao"
        />
      </label>

      <Select
        value={filters.category}
        onValueChange={(value) => onChange({ ...filters, category: value as InventoryFiltersState["category"] })}
      >
        <SelectTrigger className="w-full bg-background/70">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <SelectValue placeholder="Categoria" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="ALL">Todas as categorias</SelectItem>
          {Object.entries(inventoryCategoryLabels).map(([value, label]) => (
            <SelectItem key={value} value={value}>
              {label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={filters.situation}
        onValueChange={(value) => onChange({ ...filters, situation: value as InventoryFiltersState["situation"] })}
      >
        <SelectTrigger className="w-full bg-background/70">
          <SelectValue placeholder="Situacao" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="ALL">Todas as situacoes</SelectItem>
          {Object.entries(inventorySituationLabels).map(([value, label]) => (
            <SelectItem key={value} value={value}>
              {label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
