"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { AlertTriangle, Loader2, Repeat2 } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import {
  inventoryMovementTypeLabels,
  type SerializedInventoryItem,
} from "@/lib/inventory-calculations";
import {
  inventoryMovementSchema,
  type InventoryMovementInput,
  type InventoryMovementTypeValue,
  type InventoryMovementValues,
} from "@/lib/validations";

function defaultValues(item: SerializedInventoryItem | null): InventoryMovementInput {
  return {
    itemId: item?.id ?? "",
    type: "ENTRADA",
    quantity: 0,
    responsible: "",
    date: new Date().toISOString().slice(0, 10),
    notes: "",
    originOrDestination: "",
    unitCost: undefined,
    reason: "",
  };
}

export function InventoryMovementModal({
  open,
  items,
  item,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  items: SerializedInventoryItem[];
  item: SerializedInventoryItem | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: InventoryMovementValues) => Promise<void>;
}) {
  const form = useForm<InventoryMovementInput, unknown, InventoryMovementValues>({
    resolver: zodResolver(inventoryMovementSchema),
    defaultValues: defaultValues(item),
  });
  const selectedType = useWatch({ control: form.control, name: "type" });
  const selectedItemId = useWatch({ control: form.control, name: "itemId" });
  const selectedItem = items.find((currentItem) => currentItem.id === selectedItemId) ?? item;
  const requiresReason = selectedType === "PERDA" || selectedType === "AJUSTE";
  const showsUnitCost = selectedType === "ENTRADA";

  useEffect(() => {
    if (open) {
      form.reset(defaultValues(item));
    }
  }, [form, item, open]);

  async function submit(values: InventoryMovementValues) {
    await onSubmit(values);
    form.reset(defaultValues(item));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>Registrar movimentacao</DialogTitle>
          <DialogDescription>
            Entradas aumentam o saldo. Saidas, consumo e perdas diminuem. Ajuste define a nova quantidade.
          </DialogDescription>
        </DialogHeader>

        {selectedItem ? (
          <Alert className="rounded-xl border-emerald-500/20 bg-emerald-500/10">
            <Repeat2 className="h-4 w-4" />
            <AlertTitle>{selectedItem.name}</AlertTitle>
            <AlertDescription>
              Saldo atual: {selectedItem.quantity} {selectedItem.unit}
            </AlertDescription>
          </Alert>
        ) : null}

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Item" error={form.formState.errors.itemId?.message}>
            <Select
              disabled={saving || Boolean(item)}
              value={selectedItemId}
              onValueChange={(value) => form.setValue("itemId", value, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o item" />
              </SelectTrigger>
              <SelectContent>
                {items.map((currentItem) => (
                  <SelectItem key={currentItem.id} value={currentItem.id}>
                    {currentItem.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Tipo" error={form.formState.errors.type?.message}>
            <Select
              disabled={saving}
              value={selectedType}
              onValueChange={(value) => form.setValue("type", value as InventoryMovementTypeValue, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(inventoryMovementTypeLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label={selectedType === "AJUSTE" ? "Nova quantidade" : "Quantidade"} error={form.formState.errors.quantity?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("quantity")} />
          </Field>

          <Field label="Responsavel" error={form.formState.errors.responsible?.message}>
            <TextInput disabled={saving} placeholder="Icaro" {...form.register("responsible")} />
          </Field>

          <Field label="Data" error={form.formState.errors.date?.message}>
            <TextInput disabled={saving} type="date" {...form.register("date")} />
          </Field>

          <Field label="Origem ou destino" error={form.formState.errors.originOrDestination?.message}>
            <TextInput disabled={saving} placeholder="Talhao 1, fornecedor, oficina..." {...form.register("originOrDestination")} />
          </Field>

          {showsUnitCost ? (
            <Field label="Custo unitario da entrada" error={form.formState.errors.unitCost?.message}>
              <TextInput disabled={saving} type="number" min="0" step="0.01" placeholder="4.80" {...form.register("unitCost")} />
            </Field>
          ) : null}

          {requiresReason ? (
            <Field label="Motivo" error={form.formState.errors.reason?.message}>
              <TextInput disabled={saving} placeholder="Avaria, inventario fisico, vencimento..." {...form.register("reason")} />
            </Field>
          ) : null}

          {selectedType === "SAIDA" || selectedType === "CONSUMO" || selectedType === "PERDA" ? (
            <Alert className="rounded-xl border-amber-500/25 bg-amber-500/10 md:col-span-2">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Validacao de saldo</AlertTitle>
              <AlertDescription>
                O sistema bloqueia movimentacao maior que o saldo disponivel e mostra erro claro.
              </AlertDescription>
            </Alert>
          ) : null}

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Aplicacao no talhao 1, requisicao interna, perda operacional..." {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Repeat2 className="h-4 w-4" />}
              {saving ? "Registrando..." : "Registrar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
