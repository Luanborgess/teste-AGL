"use client";

import { Download, Plus, RefreshCw, Repeat2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { InventoryAlerts } from "@/components/estoque/inventory-alerts";
import { InventoryDeleteDialog } from "@/components/estoque/inventory-delete-dialog";
import { InventoryDetailsModal } from "@/components/estoque/inventory-details-modal";
import { InventoryEmptyState } from "@/components/estoque/inventory-empty-state";
import { InventoryFilters, type InventoryFiltersState } from "@/components/estoque/inventory-filters";
import { InventoryFormModal } from "@/components/estoque/inventory-form-modal";
import { InventoryMovementModal } from "@/components/estoque/inventory-movement-modal";
import { InventoryMovementsTable } from "@/components/estoque/inventory-movements-table";
import { InventoryQrCodeModal } from "@/components/estoque/inventory-qr-code-modal";
import { InventorySummaryCards } from "@/components/estoque/inventory-summary-cards";
import { InventoryTable } from "@/components/estoque/inventory-table";
import {
  buildInventoryAlerts,
  buildInventorySummary,
  calculateInventorySituation,
  calculateInventoryValue,
  formatCategoryLabel,
  inventorySituationLabels,
  type SerializedInventoryItem,
  type SerializedInventoryMovement,
} from "@/lib/inventory-calculations";
import { formatCurrencyBRL, formatDateBR } from "@/lib/formatters";
import type { InventoryItemValues, InventoryMovementValues } from "@/lib/validations";

type RawInventoryMovement = Omit<SerializedInventoryMovement, "itemName" | "itemUnit"> & {
  itemName?: string;
  itemUnit?: string;
  item?: { name: string; unit: string };
};

type RawInventoryItem = Omit<SerializedInventoryItem, "movements"> & {
  movements?: RawInventoryMovement[];
};

function normalizeMovement(movement: RawInventoryMovement): SerializedInventoryMovement {
  return {
    id: movement.id,
    itemId: movement.itemId,
    itemName: movement.itemName ?? movement.item?.name ?? "Item removido",
    itemUnit: movement.itemUnit ?? movement.item?.unit ?? "unidades",
    type: movement.type,
    quantity: movement.quantity,
    unitCost: movement.unitCost,
    responsible: movement.responsible,
    originOrDestination: movement.originOrDestination,
    reason: movement.reason,
    notes: movement.notes,
    balanceAfter: movement.balanceAfter,
    occurredAt: new Date(movement.occurredAt).toISOString(),
    createdAt: new Date(movement.createdAt).toISOString(),
  };
}

function normalizeItem(item: RawInventoryItem): SerializedInventoryItem {
  return {
    id: item.id,
    name: item.name,
    category: item.category,
    unit: item.unit,
    quantity: item.quantity,
    minimumStock: item.minimumStock,
    unitCost: item.unitCost,
    supplier: item.supplier,
    expirationDate: item.expirationDate ? new Date(item.expirationDate).toISOString() : null,
    location: item.location,
    sku: item.sku,
    notes: item.notes,
    createdAt: new Date(item.createdAt).toISOString(),
    updatedAt: new Date(item.updatedAt).toISOString(),
    movements: (item.movements ?? []).map(normalizeMovement),
  };
}

function getApiError(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string") {
    return payload.error;
  }

  return fallback;
}

function toCsvValue(value: string | number) {
  const text = String(value).replace(/"/g, '""');
  return `"${text}"`;
}

export function InventoryDashboard({
  initialItems,
  initialMovements,
}: {
  initialItems: SerializedInventoryItem[];
  initialMovements: SerializedInventoryMovement[];
}) {
  const [items, setItems] = useState(() => initialItems.map(normalizeItem));
  const [movements, setMovements] = useState(() => initialMovements.map(normalizeMovement));
  const [filters, setFilters] = useState<InventoryFiltersState>({ search: "", category: "ALL", situation: "ALL" });
  const [loading, setLoading] = useState(false);
  const [savingItem, setSavingItem] = useState(false);
  const [savingMovement, setSavingMovement] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [itemModalOpen, setItemModalOpen] = useState(false);
  const [movementModalOpen, setMovementModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<SerializedInventoryItem | null>(null);
  const [movementItem, setMovementItem] = useState<SerializedInventoryItem | null>(null);
  const [detailsItem, setDetailsItem] = useState<SerializedInventoryItem | null>(null);
  const [itemToDelete, setItemToDelete] = useState<SerializedInventoryItem | null>(null);
  const [qrCodeItem, setQrCodeItem] = useState<SerializedInventoryItem | null>(null);

  const summary = useMemo(() => buildInventorySummary(items, movements), [items, movements]);
  const alerts = useMemo(() => buildInventoryAlerts(items, movements), [items, movements]);

  const filteredItems = useMemo(() => {
    const search = filters.search.trim().toLocaleLowerCase("pt-BR");

    return items.filter((item) => {
      const situation = calculateInventorySituation(item);
      const matchesSearch =
        !search ||
        item.name.toLocaleLowerCase("pt-BR").includes(search) ||
        (item.supplier ?? "").toLocaleLowerCase("pt-BR").includes(search) ||
        (item.location ?? "").toLocaleLowerCase("pt-BR").includes(search);
      const matchesCategory = filters.category === "ALL" || item.category === filters.category;
      const matchesSituation = filters.situation === "ALL" || situation === filters.situation;

      return matchesSearch && matchesCategory && matchesSituation;
    });
  }, [filters, items]);

  async function loadInventory() {
    setLoading(true);
    setError(null);

    const [itemsResponse, movementsResponse] = await Promise.all([
      fetch("/api/estoque/items", { cache: "no-store" }),
      fetch("/api/estoque/movements", { cache: "no-store" }),
    ]);
    const [itemsPayload, movementsPayload] = await Promise.all([
      itemsResponse.json().catch(() => null),
      movementsResponse.json().catch(() => null),
    ]);
    setLoading(false);

    if (!itemsResponse.ok) {
      const message = getApiError(itemsPayload, "Nao foi possivel carregar os itens.");
      setError(message);
      toast.error(message);
      return;
    }

    if (!movementsResponse.ok) {
      const message = getApiError(movementsPayload, "Nao foi possivel carregar as movimentacoes.");
      setError(message);
      toast.error(message);
      return;
    }

    setItems((itemsPayload.items as RawInventoryItem[]).map(normalizeItem));
    setMovements((movementsPayload.movements as RawInventoryMovement[]).map(normalizeMovement));
  }

  function openCreateItem() {
    setSelectedItem(null);
    setItemModalOpen(true);
  }

  function openEditItem(item: SerializedInventoryItem) {
    setSelectedItem(item);
    setItemModalOpen(true);
  }

  function openMovement(item: SerializedInventoryItem | null = null) {
    setMovementItem(item);
    setMovementModalOpen(true);
  }

  async function saveItem(values: InventoryItemValues) {
    setSavingItem(true);
    const isEdit = Boolean(selectedItem);
    const response = await fetch(isEdit ? `/api/estoque/items/${selectedItem?.id}` : "/api/estoque/items", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingItem(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel salvar o item."));
      return;
    }

    toast.success(isEdit ? "Item atualizado." : "Item criado.");
    setItemModalOpen(false);
    setSelectedItem(null);
    await loadInventory();
  }

  async function saveMovement(values: InventoryMovementValues) {
    setSavingMovement(true);
    const response = await fetch("/api/estoque/movements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingMovement(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel registrar a movimentacao."));
      return;
    }

    toast.success("Movimentacao registrada.");
    setMovementModalOpen(false);
    setMovementItem(null);
    await loadInventory();
  }

  async function deleteItem() {
    if (!itemToDelete) {
      return;
    }

    setDeleting(true);
    const response = await fetch(`/api/estoque/items/${itemToDelete.id}`, { method: "DELETE" });
    const payload = await response.json().catch(() => null);
    setDeleting(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel excluir o item."));
      return;
    }

    toast.success("Item excluido.");
    setItemToDelete(null);
    await loadInventory();
  }

  function exportCsv() {
    const rows = [
      ["Produto", "Categoria", "Unidade", "Quantidade Atual", "Estoque Minimo", "Custo Unitario", "Valor Total", "Validade", "Localizacao", "Situacao"],
      ...filteredItems.map((item) => {
        const situation = calculateInventorySituation(item);
        return [
          item.name,
          formatCategoryLabel(item.category),
          item.unit,
          item.quantity,
          item.minimumStock,
          formatCurrencyBRL(item.unitCost),
          formatCurrencyBRL(calculateInventoryValue(item)),
          item.expirationDate ? formatDateBR(item.expirationDate) : "",
          item.location ?? "",
          inventorySituationLabels[situation],
        ];
      }),
    ];

    const csv = rows.map((row) => row.map(toCsvValue).join(";")).join("\n");
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "agrologistic-estoque.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  if (loading && items.length === 0) {
    return <InventorySkeleton />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 rounded-xl border border-emerald-500/15 bg-card/70 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium">Inventario geral da fazenda</p>
          <p className="text-sm text-muted-foreground">
            Insumos, materiais, equipamentos e produtos colhidos com saldo persistido no banco.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={openCreateItem}>
            <Plus className="h-4 w-4" />
            Novo item
          </Button>
          <Button variant="outline" onClick={() => openMovement(null)} disabled={items.length === 0}>
            <Repeat2 className="h-4 w-4" />
            Registrar movimentacao
          </Button>
          <Button variant="outline" onClick={exportCsv} disabled={filteredItems.length === 0}>
            <Download className="h-4 w-4" />
            Exportar CSV
          </Button>
          <Button variant="outline" onClick={loadInventory} disabled={loading}>
            <RefreshCw className={loading ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
            Atualizar
          </Button>
        </div>
      </div>

      {error ? (
        <Card className="rounded-xl border-red-500/20 bg-red-500/10">
          <CardContent className="p-4 text-sm text-red-200">{error}</CardContent>
        </Card>
      ) : null}

      <InventorySummaryCards summary={summary} />

      {items.length === 0 ? (
        <InventoryEmptyState onCreate={openCreateItem} />
      ) : (
        <Tabs defaultValue="inventario" className="space-y-4">
          <TabsList className="bg-card/80">
            <TabsTrigger value="inventario">Inventario</TabsTrigger>
            <TabsTrigger value="historico">Historico</TabsTrigger>
            <TabsTrigger value="alertas">Alertas</TabsTrigger>
          </TabsList>

          <TabsContent value="inventario" className="space-y-4">
            <InventoryFilters
              filters={filters}
              onChange={(nextFilters) => {
                setFilters(nextFilters);
              }}
            />
            <InventoryTable
              items={filteredItems}
              onCreate={openCreateItem}
              onView={setDetailsItem}
              onEdit={openEditItem}
              onMove={openMovement}
              onDelete={setItemToDelete}
              onQrCode={setQrCodeItem}
            />
          </TabsContent>

          <TabsContent value="historico">
            <InventoryMovementsTable movements={movements} />
          </TabsContent>

          <TabsContent value="alertas">
            <InventoryAlerts alerts={alerts} />
          </TabsContent>
        </Tabs>
      )}

      <InventoryFormModal
        open={itemModalOpen}
        item={selectedItem}
        saving={savingItem}
        onOpenChange={setItemModalOpen}
        onSubmit={saveItem}
      />
      <InventoryMovementModal
        open={movementModalOpen}
        items={items}
        item={movementItem}
        saving={savingMovement}
        onOpenChange={setMovementModalOpen}
        onSubmit={saveMovement}
      />
      <InventoryDetailsModal
        item={detailsItem}
        onOpenChange={(open) => {
          if (!open) {
            setDetailsItem(null);
          }
        }}
      />
      <InventoryDeleteDialog
        item={itemToDelete}
        deleting={deleting}
        onOpenChange={(open) => {
          if (!open) {
            setItemToDelete(null);
          }
        }}
        onConfirm={deleteItem}
      />
      <InventoryQrCodeModal
        item={qrCodeItem}
        onOpenChange={(open) => {
          if (!open) {
            setQrCodeItem(null);
          }
        }}
      />
    </div>
  );
}

function InventorySkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {["items", "alerts", "value", "expiring", "movements"].map((item) => (
          <div key={item} className="h-32 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
        ))}
      </div>
      <div className="h-20 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
      <div className="h-96 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
    </div>
  );
}
