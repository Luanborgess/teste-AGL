"use client";

import {
  type ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  type SortingState,
  useReactTable,
} from "@tanstack/react-table";
import {
  ArrowDownUp,
  ChevronLeft,
  ChevronRight,
  Eye,
  MoreHorizontal,
  Pencil,
  QrCode,
  Repeat2,
  Trash2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { InventoryEmptyState } from "@/components/estoque/inventory-empty-state";
import {
  calculateInventorySituation,
  calculateInventoryValue,
  inventoryCategoryLabels,
  inventorySituationLabels,
  type InventorySituation,
  type SerializedInventoryItem,
} from "@/lib/inventory-calculations";
import { formatCurrencyBRL, formatDateBR } from "@/lib/formatters";
import { cn } from "@/lib/utils";

function situationBadgeClass(situation: InventorySituation) {
  const classes: Record<InventorySituation, string> = {
    OK: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
    BAIXO_ESTOQUE: "border-yellow-500/25 bg-yellow-500/10 text-yellow-300",
    CRITICO: "border-red-500/25 bg-red-500/10 text-red-300",
    VENCENDO: "border-orange-500/25 bg-orange-500/10 text-orange-300",
    VENCIDO: "border-zinc-500/30 bg-zinc-500/15 text-zinc-300",
  };

  return classes[situation];
}

function sortButton(label: string) {
  return (
    <span className="inline-flex items-center gap-1">
      {label}
      <ArrowDownUp className="h-3.5 w-3.5 text-muted-foreground" />
    </span>
  );
}

export function InventoryTable({
  items,
  onCreate,
  onView,
  onEdit,
  onMove,
  onDelete,
  onQrCode,
}: {
  items: SerializedInventoryItem[];
  onCreate: () => void;
  onView: (item: SerializedInventoryItem) => void;
  onEdit: (item: SerializedInventoryItem) => void;
  onMove: (item: SerializedInventoryItem) => void;
  onDelete: (item: SerializedInventoryItem) => void;
  onQrCode: (item: SerializedInventoryItem) => void;
}) {
  const [sorting, setSorting] = useState<SortingState>([{ id: "name", desc: false }]);

  const columns = useMemo<ColumnDef<SerializedInventoryItem>[]>(
    () => [
      {
        accessorKey: "name",
        header: ({ column }) => (
          <Button variant="ghost" size="sm" className="-ml-2" onClick={() => column.toggleSorting()}>
            {sortButton("Produto")}
          </Button>
        ),
        cell: ({ row }) => (
          <div>
            <p className="font-medium">{row.original.name}</p>
            <p className="text-xs text-muted-foreground">{row.original.sku || row.original.supplier || "Sem codigo"}</p>
          </div>
        ),
      },
      {
        accessorKey: "category",
        header: "Categoria",
        cell: ({ row }) => inventoryCategoryLabels[row.original.category],
      },
      {
        accessorKey: "unit",
        header: "Unidade",
      },
      {
        accessorKey: "quantity",
        header: ({ column }) => (
          <Button variant="ghost" size="sm" className="-mr-2" onClick={() => column.toggleSorting()}>
            {sortButton("Quantidade Atual")}
          </Button>
        ),
        cell: ({ row }) => (
          <span className="font-mono text-sm">
            {new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(row.original.quantity)}
          </span>
        ),
      },
      {
        accessorKey: "minimumStock",
        header: "Estoque Minimo",
        cell: ({ row }) => (
          <span className="font-mono text-xs text-muted-foreground">
            {new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(row.original.minimumStock)}
          </span>
        ),
      },
      {
        accessorKey: "unitCost",
        header: "Custo Unitario",
        cell: ({ row }) => formatCurrencyBRL(row.original.unitCost),
      },
      {
        id: "totalValue",
        accessorFn: (item) => calculateInventoryValue(item),
        header: ({ column }) => (
          <Button variant="ghost" size="sm" className="-mr-2" onClick={() => column.toggleSorting()}>
            {sortButton("Valor Total")}
          </Button>
        ),
        cell: ({ row }) => <span className="font-medium text-emerald-300">{formatCurrencyBRL(calculateInventoryValue(row.original))}</span>,
      },
      {
        accessorKey: "expirationDate",
        header: ({ column }) => (
          <Button variant="ghost" size="sm" className="-ml-2" onClick={() => column.toggleSorting()}>
            {sortButton("Validade")}
          </Button>
        ),
        cell: ({ row }) => (row.original.expirationDate ? formatDateBR(row.original.expirationDate) : "Sem validade"),
      },
      {
        accessorKey: "location",
        header: "Localizacao",
        cell: ({ row }) => row.original.location || "Nao informada",
      },
      {
        id: "situation",
        accessorFn: (item) => inventorySituationLabels[calculateInventorySituation(item)],
        header: "Situacao",
        cell: ({ row }) => {
          const situation = calculateInventorySituation(row.original);
          return (
            <Badge variant="outline" className={situationBadgeClass(situation)}>
              {inventorySituationLabels[situation]}
            </Badge>
          );
        },
      },
      {
        id: "actions",
        header: () => <span className="sr-only">Acoes</span>,
        cell: ({ row }) => (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon-sm" title="Acoes">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => onView(row.original)}>
                <Eye className="h-4 w-4" />
                Ver detalhes
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onMove(row.original)}>
                <Repeat2 className="h-4 w-4" />
                Movimentar
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onEdit(row.original)}>
                <Pencil className="h-4 w-4" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onQrCode(row.original)}>
                <QrCode className="h-4 w-4" />
                Gerar QR Code
              </DropdownMenuItem>
              <DropdownMenuItem variant="destructive" onClick={() => onDelete(row.original)}>
                <Trash2 className="h-4 w-4" />
                Excluir
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ),
      },
    ],
    [onDelete, onEdit, onMove, onQrCode, onView],
  );

  // TanStack Table intentionally returns table helpers from this hook.
  // eslint-disable-next-line react-hooks/incompatible-library
  const table = useReactTable({
    data: items,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize: 8 } },
  });

  if (items.length === 0) {
    return (
      <InventoryEmptyState
        title="Sem resultados"
        description="Nenhum item corresponde aos filtros aplicados."
        onCreate={onCreate}
      />
    );
  }

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Inventario da fazenda</CardTitle>
        <p className="text-sm text-muted-foreground">{items.length} item(ns) encontrados</p>
      </CardHeader>
      <CardContent>
        <div className="hidden overflow-x-auto lg:block">
          <Table>
            <TableHeader>
              {table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id} className="hover:bg-transparent">
                  {headerGroup.headers.map((header) => (
                    <TableHead key={header.id} className={cn(header.column.id === "actions" && "text-right")}>
                      {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                    </TableHead>
                  ))}
                </TableRow>
              ))}
            </TableHeader>
            <TableBody>
              {table.getRowModel().rows.map((row) => (
                <TableRow key={row.id} className="border-foreground/10">
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id} className={cn(cell.column.id === "actions" && "text-right")}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="grid gap-3 lg:hidden">
          {table.getRowModel().rows.map((row) => {
            const item = row.original;
            const situation = calculateInventorySituation(item);
            return (
              <div key={item.id} className="rounded-xl border border-foreground/10 bg-background/45 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-xs text-muted-foreground">{inventoryCategoryLabels[item.category]}</p>
                  </div>
                  <Badge variant="outline" className={situationBadgeClass(situation)}>
                    {inventorySituationLabels[situation]}
                  </Badge>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                  <span className="text-muted-foreground">Quantidade</span>
                  <span className="text-right font-mono">{item.quantity} {item.unit}</span>
                  <span className="text-muted-foreground">Valor</span>
                  <span className="text-right font-medium text-emerald-300">{formatCurrencyBRL(calculateInventoryValue(item))}</span>
                  <span className="text-muted-foreground">Localizacao</span>
                  <span className="text-right">{item.location || "Nao informada"}</span>
                </div>
                <div className="mt-4 flex flex-wrap justify-end gap-2">
                  <Button variant="outline" size="sm" onClick={() => onView(item)}>Detalhes</Button>
                  <Button variant="outline" size="sm" onClick={() => onMove(item)}>Movimentar</Button>
                  <Button variant="ghost" size="icon-sm" title="Editar" onClick={() => onEdit(item)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon-sm" title="QR Code" onClick={() => onQrCode(item)}>
                    <QrCode className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 flex flex-col gap-3 border-t border-foreground/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-muted-foreground">
            Pagina {table.getState().pagination.pageIndex + 1} de {table.getPageCount()}
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>
              <ChevronLeft className="h-4 w-4" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
              Proxima
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
