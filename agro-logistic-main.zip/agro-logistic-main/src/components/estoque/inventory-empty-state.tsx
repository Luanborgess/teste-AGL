"use client";

import { Boxes, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function InventoryEmptyState({
  title = "Nenhum item cadastrado",
  description = "Cadastre insumos, materiais, equipamentos ou produtos colhidos para iniciar o controle real do estoque.",
  onCreate,
}: {
  title?: string;
  description?: string;
  onCreate: () => void;
}) {
  return (
    <Card className="rounded-xl border-emerald-500/15 bg-card/80">
      <CardContent className="flex flex-col items-center justify-center px-6 py-14 text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-lg border border-emerald-400/25 bg-emerald-500/10 text-emerald-300">
          <Boxes className="h-5 w-5" />
        </span>
        <h2 className="mt-4 text-lg font-semibold">{title}</h2>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">{description}</p>
        <Button className="mt-5 bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={onCreate}>
          <Plus className="h-4 w-4" />
          Novo item
        </Button>
      </CardContent>
    </Card>
  );
}
