"use client";

import { ExternalLink, Loader2, QrCode } from "lucide-react";
import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { SerializedInventoryItem } from "@/lib/inventory-calculations";

export function InventoryQrCodeModal({
  item,
  onOpenChange,
}: {
  item: SerializedInventoryItem | null;
  onOpenChange: (open: boolean) => void;
}) {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const path = item ? `/estoque/${item.id}` : "";
  const absoluteUrl = typeof window !== "undefined" && path ? `${window.location.origin}${path}` : path;

  useEffect(() => {
    let active = true;

    async function generateQrCode() {
      if (!item || !absoluteUrl) {
        setQrCodeUrl("");
        return;
      }

      setLoading(true);
      const dataUrl = await QRCode.toDataURL(absoluteUrl, {
        margin: 2,
        scale: 8,
        color: {
          dark: "#052e1a",
          light: "#f7fee7",
        },
      });

      if (active) {
        setQrCodeUrl(dataUrl);
        setLoading(false);
      }
    }

    generateQrCode().catch(() => {
      if (active) {
        setLoading(false);
        setQrCodeUrl("");
      }
    });

    return () => {
      active = false;
    };
  }, [absoluteUrl, item]);

  return (
    <Dialog open={Boolean(item)} onOpenChange={onOpenChange}>
      <DialogContent className="border-emerald-500/15 bg-popover/95 sm:max-w-md">
        <DialogHeader>
          <DialogTitle>QR Code do item</DialogTitle>
          <DialogDescription>
            O codigo aponta para a pagina de detalhes do produto no estoque.
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center rounded-xl border border-foreground/10 bg-background/45 p-6 text-center">
          {loading ? (
            <div className="flex h-56 w-56 items-center justify-center rounded-xl bg-muted/30">
              <Loader2 className="h-6 w-6 animate-spin text-emerald-300" />
            </div>
          ) : qrCodeUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={qrCodeUrl} alt={`QR Code de ${item?.name}`} className="h-56 w-56 rounded-xl" />
          ) : (
            <div className="flex h-56 w-56 items-center justify-center rounded-xl bg-muted/30">
              <QrCode className="h-8 w-8 text-muted-foreground" />
            </div>
          )}

          <p className="mt-4 font-medium">{item?.name}</p>
          <p className="mt-1 break-all text-xs text-muted-foreground">{absoluteUrl}</p>
          {path ? (
            <Button asChild variant="outline" className="mt-4">
              <a href={path}>
                <ExternalLink className="h-4 w-4" />
                Abrir detalhes
              </a>
            </Button>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  );
}
