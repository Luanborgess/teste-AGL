"use client";

import {
  type ColumnDef,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  type SortingState,
  useReactTable,
} from "@tanstack/react-table";
import { ArrowDownUp, ChevronLeft, ChevronRight } from "lucide-react";
import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  inventoryMovementTypeLabels,
  type SerializedInventoryMovement,
} from "@/lib/inventory-calculations";
import { formatDateBR } from "@/lib/formatters";
import type { InventoryMovementTypeValue } from "@/lib/validations";

function movementBadgeClass(type: InventoryMovementTypeValue) {
  const classes: Record<InventoryMovementTypeValue, string> = {
    ENTRADA: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
    SAIDA: "border-sky-500/20 bg-sky-500/10 text-sky-300",
    CONSUMO: "border-yellow-500/25 bg-yellow-500/10 text-yellow-300",
    PERDA: "border-red-500/25 bg-red-500/10 text-red-300",
    AJUSTE: "border-violet-500/25 bg-violet-500/10 text-violet-300",
  };

  return classes[type];
}

export function InventoryMovementsTable({
  movements,
}: {
  movements: SerializedInventoryMovement[];
}) {
  const [sorting, setSorting] = useState<SortingState>([{ id: "occurredAt", desc: true }]);
  const [typeFilter, setTypeFilter] = useState<InventoryMovementTypeValue | "ALL">("ALL");
  const [itemFilter, setItemFilter] = useState<string>("ALL");
  const [periodFilter, setPeriodFilter] = useState<"ALL" | "30" | "90">("ALL");

  const itemOptions = useMemo(
    () => Array.from(new Map(movements.map((movement) => [movement.itemId, movement.itemName])).entries()),
    [movements],
  );

  const filteredMovements = useMemo(() => {
    const now = new Date();

    return movements.filter((movement) => {
      const matchesType = typeFilter === "ALL" || movement.type === typeFilter;
      const matchesItem = itemFilter === "ALL" || movement.itemId === itemFilter;
      const date = new Date(movement.occurredAt);
      const matchesPeriod =
        periodFilter === "ALL" ||
        date >= new Date(now.getFullYear(), now.getMonth(), now.getDate() - Number(periodFilter));

      return matchesType && matchesItem && matchesPeriod;
    });
  }, [itemFilter, movements, periodFilter, typeFilter]);

  const columns = useMemo<ColumnDef<SerializedInventoryMovement>[]>(
    () => [
      {
        accessorKey: "occurredAt",
        header: ({ column }) => (
          <Button variant="ghost" size="sm" className="-ml-2" onClick={() => column.toggleSorting()}>
            Data
            <ArrowDownUp className="h-3.5 w-3.5 text-muted-foreground" />
          </Button>
        ),
        cell: ({ row }) => <span className="font-mono text-xs">{formatDateBR(row.original.occurredAt)}</span>,
      },
      {
        accessorKey: "itemName",
        header: "Produto",
      },
      {
        accessorKey: "type",
        header: "Tipo",
        cell: ({ row }) => (
          <Badge variant="outline" className={movementBadgeClass(row.original.type)}>
            {inventoryMovementTypeLabels[row.original.type]}
          </Badge>
        ),
      },
      {
        accessorKey: "quantity",
        header: "Quantidade",
        cell: ({ row }) => (
          <span className="font-mono">
            {new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(row.original.quantity)} {row.original.itemUnit}
          </span>
        ),
      },
      {
        accessorKey: "responsible",
        header: "Responsavel",
        cell: ({ row }) => row.original.responsible || "Nao informado",
      },
      {
        accessorKey: "notes",
        header: "Observacoes",
        cell: ({ row }) => row.original.notes || row.original.reason || row.original.originOrDestination || "Sem observacoes",
      },
      {
        accessorKey: "balanceAfter",
        header: "Saldo apos",
        cell: ({ row }) =>
          typeof row.original.balanceAfter === "number"
            ? `${new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(row.original.balanceAfter)} ${row.original.itemUnit}`
            : "Nao calculado",
      },
    ],
    [],
  );

  // TanStack Table intentionally returns table helpers from this hook.
  // eslint-disable-next-line react-hooks/incompatible-library
  const table = useReactTable({
    data: filteredMovements,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize: 8 } },
  });

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader className="gap-4">
        <div>
          <CardTitle className="text-base">Historico de movimentacoes</CardTitle>
          <p className="text-sm text-muted-foreground">{filteredMovements.length} registro(s) encontrados</p>
        </div>
        <div className="grid gap-2 md:grid-cols-3">
          <Select value={itemFilter} onValueChange={setItemFilter}>
            <SelectTrigger className="w-full bg-background/70">
              <SelectValue placeholder="Produto" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todos os produtos</SelectItem>
              {itemOptions.map(([id, name]) => (
                <SelectItem key={id} value={id}>
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={typeFilter} onValueChange={(value) => setTypeFilter(value as InventoryMovementTypeValue | "ALL")}>
            <SelectTrigger className="w-full bg-background/70">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todos os tipos</SelectItem>
              {Object.entries(inventoryMovementTypeLabels).map(([value, label]) => (
                <SelectItem key={value} value={value}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={periodFilter} onValueChange={(value) => setPeriodFilter(value as "ALL" | "30" | "90")}>
            <SelectTrigger className="w-full bg-background/70">
              <SelectValue placeholder="Periodo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todo o periodo</SelectItem>
              <SelectItem value="30">Ultimos 30 dias</SelectItem>
              <SelectItem value="90">Ultimos 90 dias</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {filteredMovements.length === 0 ? (
          <div className="rounded-xl border border-dashed border-foreground/15 p-8 text-center text-sm text-muted-foreground">
            Nenhuma movimentacao encontrada para os filtros atuais.
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  {table.getHeaderGroups().map((headerGroup) => (
                    <TableRow key={headerGroup.id} className="hover:bg-transparent">
                      {headerGroup.headers.map((header) => (
                        <TableHead key={header.id}>
                          {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                        </TableHead>
                      ))}
                    </TableRow>
                  ))}
                </TableHeader>
                <TableBody>
                  {table.getRowModel().rows.map((row) => (
                    <TableRow key={row.id} className="border-foreground/10">
                      {row.getVisibleCells().map((cell) => (
                        <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="mt-4 flex flex-col gap-3 border-t border-foreground/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm text-muted-foreground">
                Pagina {table.getState().pagination.pageIndex + 1} de {table.getPageCount()}
              </p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>
                  <ChevronLeft className="h-4 w-4" />
                  Anterior
                </Button>
                <Button variant="outline" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
                  Proxima
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
