"use client";

import { AlertCircle, AlertTriangle, Clock, TrendingDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { InventoryAlert } from "@/lib/inventory-calculations";

function alertTone(type: InventoryAlert["type"]) {
  if (type === "critical" || type === "expired") {
    return {
      icon: AlertTriangle,
      className: "border-red-500/20 bg-red-500/10 text-red-300",
    };
  }

  if (type === "consumption") {
    return {
      icon: TrendingDown,
      className: "border-yellow-500/25 bg-yellow-500/10 text-yellow-300",
    };
  }

  if (type === "idle") {
    return {
      icon: Clock,
      className: "border-zinc-500/30 bg-zinc-500/15 text-zinc-300",
    };
  }

  return {
    icon: AlertCircle,
    className: "border-orange-500/25 bg-orange-500/10 text-orange-300",
  };
}

export function InventoryAlerts({ alerts }: { alerts: InventoryAlert[] }) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Alertas inteligentes</CardTitle>
        <p className="text-sm text-muted-foreground">Calculados somente a partir dos itens e movimentacoes cadastrados.</p>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <div className="rounded-xl border border-dashed border-foreground/15 p-6 text-sm text-muted-foreground">
            Nenhum alerta ativo com os dados atuais.
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {alerts.map((alert) => {
              const tone = alertTone(alert.type);
              const Icon = tone.icon;

              return (
                <div key={alert.id} className="rounded-xl border border-foreground/10 bg-background/45 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className={`flex h-8 w-8 items-center justify-center rounded-lg border ${tone.className}`}>
                        <Icon className="h-4 w-4" />
                      </span>
                      <p className="font-medium">{alert.title}</p>
                    </div>
                    <Badge variant="outline" className={tone.className}>
                      Ativo
                    </Badge>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">{alert.description}</p>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
