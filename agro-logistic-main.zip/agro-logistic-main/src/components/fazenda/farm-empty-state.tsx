"use client";

import { MapPinned } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function FarmEmptyState({ onCreate }: { onCreate: () => void }) {
  return (
    <Card className="overflow-hidden rounded-xl border-emerald-500/15 bg-card/80">
      <CardContent className="relative p-8">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.16),transparent_22rem)]" />
        <div className="relative max-w-2xl space-y-4">
          <span className="flex h-12 w-12 items-center justify-center rounded-lg border border-emerald-400/25 bg-emerald-500/10 text-emerald-300">
            <MapPinned className="h-5 w-5" />
          </span>
          <div>
            <h2 className="text-xl font-semibold tracking-tight">Cadastre a fazenda principal</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Para manter os calculos consistentes, esta conta possui uma unica fazenda principal. Depois do cadastro,
              voce podera editar os dados e criar quantos talhoes forem necessarios dentro dela.
            </p>
          </div>
          <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={onCreate}>
            Cadastrar Fazenda
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
