"use client";

import { AreaChart, Gauge, Layers3, Leaf, MapPinned, Sprout } from "lucide-react";
import { StatCard } from "@/components/dashboard/stat-card";
import { formatHectares, formatInteger, formatProductivity } from "@/lib/formatters";

export type FarmSummary = {
  totalArea: number;
  cultivatedArea: number;
  availableArea: number;
  fieldCount: number;
  activeCropCount: number;
  averageProductivity: number | null;
  isAreaExceeded: boolean;
};

export function FarmSummaryCards({ summary }: { summary: FarmSummary }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
      <StatCard label="Area Total" value={formatHectares(summary.totalArea)} helper="Area informada na fazenda." icon={MapPinned} />
      <StatCard
        label="Area Cultivada"
        value={formatHectares(summary.cultivatedArea)}
        helper="Talhoes ativos ou em preparo."
        icon={AreaChart}
        tone="good"
      />
      <StatCard
        label="Area Disponivel"
        value={formatHectares(summary.availableArea)}
        helper="Area total menos talhoes."
        icon={Leaf}
        tone={summary.isAreaExceeded ? "danger" : "default"}
      />
      <StatCard label="Talhoes" value={formatInteger(summary.fieldCount)} helper="Total cadastrado na fazenda." icon={Layers3} />
      <StatCard label="Culturas Ativas" value={formatInteger(summary.activeCropCount)} helper="Culturas em talhoes ativos." icon={Sprout} />
      <StatCard
        label="Produtividade Media"
        value={formatProductivity(summary.averageProductivity)}
        helper="Media das produtividades preenchidas."
        icon={Gauge}
      />
    </div>
  );
}
