"use client";

import { Edit3, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export function FarmHeader({
  hasFarm,
  loading,
  onCreate,
  onEdit,
  onRefresh,
}: {
  hasFarm: boolean;
  loading: boolean;
  onCreate: () => void;
  onEdit: () => void;
  onRefresh: () => void;
}) {
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-emerald-500/15 bg-card/70 p-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="text-sm font-medium">Propriedade principal</p>
        <p className="text-sm text-muted-foreground">
          O AgroLogistic trabalha com uma fazenda principal por conta, conectando talhoes aos demais modulos.
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={hasFarm ? onEdit : onCreate}>
          <Edit3 className="h-4 w-4" />
          {hasFarm ? "Editar Fazenda" : "Cadastrar Fazenda"}
        </Button>
        <Button variant="outline" onClick={onRefresh} disabled={loading}>
          <RefreshCw className={loading ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
          Atualizar
        </Button>
      </div>
    </div>
  );
}
