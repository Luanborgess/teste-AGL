"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import type { SerializedFarm } from "@/lib/farm-calculations";
import { farmSchema, type FarmInput, type FarmValues } from "@/lib/validations";

const emptyValues: FarmInput = {
  name: "",
  owner: "",
  city: "",
  state: "",
  totalArea: 0,
  productionType: "",
  coordinates: "",
  notes: "",
};

function valuesFromFarm(farm: SerializedFarm | null): FarmInput {
  if (!farm) {
    return emptyValues;
  }

  return {
    name: farm.name,
    owner: farm.owner,
    city: farm.city,
    state: farm.state,
    totalArea: farm.totalArea,
    productionType: farm.productionType ?? "",
    coordinates: farm.coordinates ?? "",
    notes: farm.notes ?? "",
  };
}

export function FarmFormModal({
  open,
  farm,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  farm: SerializedFarm | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: FarmValues) => Promise<boolean>;
}) {
  const form = useForm<FarmInput, unknown, FarmValues>({
    resolver: zodResolver(farmSchema),
    defaultValues: valuesFromFarm(farm),
  });
  const isInitial = !farm;

  useEffect(() => {
    if (open) {
      form.reset(valuesFromFarm(farm));
    }
  }, [farm, form, open]);

  async function submit(values: FarmValues) {
    const saved = await onSubmit(values);

    if (saved && isInitial) {
      form.reset(emptyValues);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(nextOpen) => {
        if (isInitial && !nextOpen) {
          return;
        }

        onOpenChange(nextOpen);
      }}
    >
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{isInitial ? "Cadastrar Fazenda" : "Editar Fazenda"}</DialogTitle>
          <DialogDescription>
            A conta usa uma fazenda principal. Depois de criada, a propriedade pode ser editada, mas nao duplicada.
          </DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Nome da fazenda" error={form.formState.errors.name?.message}>
            <TextInput disabled={saving} placeholder="Mais Soja" {...form.register("name")} />
          </Field>
          <Field label="Proprietario/responsavel" error={form.formState.errors.owner?.message}>
            <TextInput disabled={saving} placeholder="Icaro Almeida dos Santos Machado" {...form.register("owner")} />
          </Field>
          <Field label="Cidade" error={form.formState.errors.city?.message}>
            <TextInput disabled={saving} placeholder="Luis Eduardo Magalhaes" {...form.register("city")} />
          </Field>
          <Field label="Estado" error={form.formState.errors.state?.message}>
            <TextInput disabled={saving} placeholder="BA" maxLength={2} {...form.register("state")} />
          </Field>
          <Field label="Area total em hectares" error={form.formState.errors.totalArea?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" placeholder="1000" {...form.register("totalArea")} />
          </Field>
          <Field label="Tipo principal de producao" error={form.formState.errors.productionType?.message}>
            <TextInput disabled={saving} placeholder="Soja" {...form.register("productionType")} />
          </Field>
          <Field label="Coordenadas ou localizacao aproximada" error={form.formState.errors.coordinates?.message} className="md:col-span-2">
            <TextInput disabled={saving} placeholder='-12.09,-45.78 ou {"lat":-12.09,"lng":-45.78}' {...form.register("coordinates")} />
          </Field>
          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Fazenda teste do AgroLogistic" {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            {!isInitial ? (
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
                Cancelar
              </Button>
            ) : null}
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar Fazenda"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
