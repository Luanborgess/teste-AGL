"use client";

import { CalendarDays, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { fieldStatusLabels, type SerializedField } from "@/lib/farm-calculations";
import { formatCoordinates, formatDateBR, formatHectares, formatProductivity } from "@/lib/formatters";

function statusBadgeClass(status: SerializedField["status"]) {
  const classes: Record<SerializedField["status"], string> = {
    ATIVO: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
    EM_PREPARO: "border-amber-500/25 bg-amber-500/10 text-amber-300",
    INATIVO: "border-zinc-500/20 bg-zinc-500/10 text-zinc-300",
    EM_DESCANSO: "border-sky-500/20 bg-sky-500/10 text-sky-300",
    PROBLEMA: "border-red-500/20 bg-red-500/10 text-red-300",
  };

  return classes[status];
}

export function FieldDetailsModal({
  field,
  onOpenChange,
}: {
  field: SerializedField | null;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={Boolean(field)} onOpenChange={onOpenChange}>
      <DialogContent className="border-emerald-500/15 bg-popover/95 sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{field?.name ?? "Talhao"}</DialogTitle>
          <DialogDescription>Detalhes operacionais e dados geograficos do talhao.</DialogDescription>
        </DialogHeader>

        {field ? (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className={statusBadgeClass(field.status)}>
                {fieldStatusLabels[field.status]}
              </Badge>
              {field.currentCrop ? (
                <Badge variant="outline" className="border-emerald-500/20 bg-emerald-500/10 text-emerald-300">
                  {field.currentCrop}
                </Badge>
              ) : null}
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Info label="Area" value={formatHectares(field.area)} />
              <Info label="Solo" value={field.soilType || "Nao informado"} />
              <Info label="Produtividade esperada" value={formatProductivity(field.expectedProductivity)} />
              <Info label="Coordenadas/mapa" value={formatCoordinates(field.coordinates)} icon={<MapPin className="h-3.5 w-3.5 text-emerald-300" />} />
              <Info label="Criado em" value={formatDateBR(field.createdAt)} icon={<CalendarDays className="h-3.5 w-3.5 text-emerald-300" />} />
              <Info label="Atualizado em" value={formatDateBR(field.updatedAt)} icon={<CalendarDays className="h-3.5 w-3.5 text-emerald-300" />} />
            </div>
            <div className="rounded-lg border border-foreground/10 bg-background/45 p-4">
              <p className="text-xs text-muted-foreground">Observacoes</p>
              <p className="mt-2 whitespace-pre-wrap text-sm">{field.notes || "Sem observacoes"}</p>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

function Info({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-background/45 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 flex items-center gap-1 text-sm font-medium">
        {icon}
        {value}
      </p>
    </div>
  );
}
