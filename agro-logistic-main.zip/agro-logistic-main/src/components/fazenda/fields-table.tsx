"use client";

import { ArrowDownUp, ChevronLeft, ChevronRight, Eye, MapPin, Pencil, Plus, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { fieldStatusLabels, type SerializedField } from "@/lib/farm-calculations";
import { formatCoordinates, formatHectares, formatProductivity } from "@/lib/formatters";
import { cn } from "@/lib/utils";

export type FieldSortKey = "name" | "area" | "expectedProductivity";
export type FieldSortDirection = "asc" | "desc";

function statusBadgeClass(status: SerializedField["status"]) {
  const classes: Record<SerializedField["status"], string> = {
    ATIVO: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
    EM_PREPARO: "border-amber-500/25 bg-amber-500/10 text-amber-300",
    INATIVO: "border-zinc-500/20 bg-zinc-500/10 text-zinc-300",
    EM_DESCANSO: "border-sky-500/20 bg-sky-500/10 text-sky-300",
    PROBLEMA: "border-red-500/20 bg-red-500/10 text-red-300",
  };

  return classes[status];
}

function sortLabel(key: FieldSortKey) {
  const labels: Record<FieldSortKey, string> = {
    name: "nome",
    area: "area",
    expectedProductivity: "produtividade",
  };

  return labels[key];
}

export function FieldsTable({
  fields,
  totalResults,
  page,
  totalPages,
  sortKey,
  sortDirection,
  onSort,
  onPageChange,
  onCreate,
  onView,
  onEdit,
  onDelete,
}: {
  fields: SerializedField[];
  totalResults: number;
  page: number;
  totalPages: number;
  sortKey: FieldSortKey;
  sortDirection: FieldSortDirection;
  onSort: (key: FieldSortKey) => void;
  onPageChange: (page: number) => void;
  onCreate: () => void;
  onView: (field: SerializedField) => void;
  onEdit: (field: SerializedField) => void;
  onDelete: (field: SerializedField) => void;
}) {
  if (totalResults === 0) {
    return (
      <Card className="rounded-xl border-dashed border-foreground/15 bg-card/70">
        <CardContent className="flex min-h-48 flex-col items-center justify-center gap-3 p-6 text-center">
          <p className="text-sm font-medium">Nenhum talhao encontrado</p>
          <p className="max-w-md text-sm text-muted-foreground">
            Ajuste os filtros ou cadastre um talhao real para iniciar a gestao de areas da fazenda.
          </p>
          <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={onCreate}>
            <Plus className="h-4 w-4" />
            Cadastrar talhao
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle className="text-base">Talhoes</CardTitle>
        <p className="text-sm text-muted-foreground">{totalResults} registro(s) encontrados</p>
      </CardHeader>
      <CardContent>
        <div className="hidden md:block">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>
                  <Button variant="ghost" size="sm" className="-ml-2" onClick={() => onSort("name")}>
                    Nome do Talhao
                    <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "name" && "text-emerald-300")} />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button variant="ghost" size="sm" className="-mr-2" onClick={() => onSort("area")}>
                    Area
                    <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "area" && "text-emerald-300")} />
                  </Button>
                </TableHead>
                <TableHead>Tipo de Solo</TableHead>
                <TableHead>Cultura Atual</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">
                  <Button variant="ghost" size="sm" className="-mr-2" onClick={() => onSort("expectedProductivity")}>
                    Produtividade
                    <ArrowDownUp className={cn("h-3.5 w-3.5", sortKey === "expectedProductivity" && "text-emerald-300")} />
                  </Button>
                </TableHead>
                <TableHead>Mapa</TableHead>
                <TableHead className="text-right">Acoes</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {fields.map((field) => (
                <TableRow key={field.id} className="border-foreground/10">
                  <TableCell className="font-medium">{field.name}</TableCell>
                  <TableCell className="text-right font-mono text-xs">{formatHectares(field.area)}</TableCell>
                  <TableCell className="text-muted-foreground">{field.soilType || "Nao informado"}</TableCell>
                  <TableCell>{field.currentCrop || "Sem cultura"}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={statusBadgeClass(field.status)}>
                      {fieldStatusLabels[field.status]}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-mono text-xs">{formatProductivity(field.expectedProductivity)}</TableCell>
                  <TableCell className="max-w-40 truncate text-xs text-muted-foreground">
                    {field.coordinates ? (
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="h-3.5 w-3.5 text-emerald-300" />
                        {formatCoordinates(field.coordinates)}
                      </span>
                    ) : (
                      "Nao informado"
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon-sm" title="Visualizar" onClick={() => onView(field)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon-sm" title="Editar" onClick={() => onEdit(field)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon-sm" title="Excluir" onClick={() => onDelete(field)}>
                        <Trash2 className="h-4 w-4 text-red-300" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="grid gap-3 md:hidden">
          {fields.map((field) => (
            <div key={field.id} className="rounded-lg border border-foreground/10 bg-background/45 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-medium">{field.name}</p>
                  <p className="text-sm text-muted-foreground">{formatHectares(field.area)} - {field.currentCrop || "Sem cultura"}</p>
                </div>
                <Badge variant="outline" className={statusBadgeClass(field.status)}>
                  {fieldStatusLabels[field.status]}
                </Badge>
              </div>
              <div className="mt-3 grid gap-2 text-sm">
                <span>Solo: {field.soilType || "Nao informado"}</span>
                <span>Produtividade: {formatProductivity(field.expectedProductivity)}</span>
                <span>Mapa: {formatCoordinates(field.coordinates)}</span>
              </div>
              <div className="mt-3 flex justify-end gap-1">
                <Button variant="ghost" size="icon-sm" title="Visualizar" onClick={() => onView(field)}>
                  <Eye className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon-sm" title="Editar" onClick={() => onEdit(field)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon-sm" title="Excluir" onClick={() => onDelete(field)}>
                  <Trash2 className="h-4 w-4 text-red-300" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-col gap-3 border-t border-foreground/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-muted-foreground">
            Pagina {page} de {totalPages} - ordenado por {sortLabel(sortKey)} ({sortDirection === "desc" ? "desc" : "asc"})
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => onPageChange(page - 1)} disabled={page <= 1}>
              <ChevronLeft className="h-4 w-4" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" onClick={() => onPageChange(page + 1)} disabled={page >= totalPages}>
              Proxima
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
