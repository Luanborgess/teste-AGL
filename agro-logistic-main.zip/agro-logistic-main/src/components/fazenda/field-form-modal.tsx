"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { AlertTriangle, Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import { fieldStatusLabels, type SerializedField } from "@/lib/farm-calculations";
import { formatHectares } from "@/lib/formatters";
import { fieldSchema, type FieldInput, type FieldValues } from "@/lib/validations";

const emptyValues: FieldInput = {
  name: "",
  area: 0,
  soilType: "",
  currentCrop: "",
  expectedProductivity: undefined,
  status: "ATIVO",
  coordinates: "",
  notes: "",
};

function valuesFromField(field: SerializedField | null): FieldInput {
  if (!field) {
    return emptyValues;
  }

  return {
    name: field.name,
    area: field.area,
    soilType: field.soilType ?? "",
    currentCrop: field.currentCrop ?? "",
    expectedProductivity: field.expectedProductivity ?? undefined,
    status: field.status,
    coordinates: field.coordinates ?? "",
    notes: field.notes ?? "",
  };
}

export function FieldFormModal({
  open,
  field,
  fields,
  totalArea,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  field: SerializedField | null;
  fields: SerializedField[];
  totalArea: number;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: FieldValues) => Promise<boolean>;
}) {
  const form = useForm<FieldInput, unknown, FieldValues>({
    resolver: zodResolver(fieldSchema),
    defaultValues: valuesFromField(field),
  });
  const selectedStatus = useWatch({ control: form.control, name: "status" });
  const watchedArea = Number(useWatch({ control: form.control, name: "area" }) ?? 0);
  const usedByOtherFields = fields.filter((item) => item.id !== field?.id).reduce((total, item) => total + item.area, 0);
  const remainingArea = totalArea - usedByOtherFields;
  const exceedsArea = watchedArea > remainingArea;

  useEffect(() => {
    if (open) {
      form.reset(valuesFromField(field));
    }
  }, [field, form, open]);

  async function submit(values: FieldValues) {
    if (values.area > remainingArea) {
      form.setError("area", { message: `A area maxima disponivel para este talhao e ${formatHectares(remainingArea)}.` });
      return;
    }

    const saved = await onSubmit(values);

    if (saved && !field) {
      form.reset(emptyValues);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{field ? "Editar talhao" : "Cadastrar talhao"}</DialogTitle>
          <DialogDescription>
            Cada talhao pertence a fazenda principal e usa area, status e cultura para recalcular os indicadores.
          </DialogDescription>
        </DialogHeader>

        {exceedsArea ? (
          <Alert className="rounded-xl border-red-500/25 bg-red-500/10">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Area acima do limite da fazenda</AlertTitle>
            <AlertDescription>
              Com os demais talhoes, este cadastro pode usar no maximo {formatHectares(remainingArea)}.
            </AlertDescription>
          </Alert>
        ) : null}

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Nome do talhao" error={form.formState.errors.name?.message}>
            <TextInput disabled={saving} placeholder="Talhao 1" {...form.register("name")} />
          </Field>
          <Field label="Area em hectares" error={form.formState.errors.area?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" placeholder="350" {...form.register("area")} />
          </Field>
          <Field label="Tipo de solo" error={form.formState.errors.soilType?.message}>
            <TextInput disabled={saving} placeholder="Argiloso" {...form.register("soilType")} />
          </Field>
          <Field label="Cultura atual" error={form.formState.errors.currentCrop?.message}>
            <TextInput disabled={saving} placeholder="Soja" {...form.register("currentCrop")} />
          </Field>
          <Field label="Produtividade esperada" error={form.formState.errors.expectedProductivity?.message}>
            <TextInput
              disabled={saving}
              type="number"
              min="0"
              step="0.01"
              placeholder="60"
              {...form.register("expectedProductivity")}
            />
          </Field>
          <Field label="Status" error={form.formState.errors.status?.message}>
            <Select
              disabled={saving}
              value={selectedStatus}
              onValueChange={(value) => form.setValue("status", value as FieldValues["status"], { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o status" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(fieldStatusLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Coordenadas ou poligono em JSON" error={form.formState.errors.coordinates?.message} className="md:col-span-2">
            <TextAreaInput
              disabled={saving}
              placeholder='{"lat":-12.09,"lng":-45.78} ou [[-12.09,-45.78],[-12.1,-45.79],[-12.08,-45.8]]'
              {...form.register("coordinates")}
            />
          </Field>
          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Manejo, irrigacao, historico do talhao..." {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving || exceedsArea}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar talhao"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
