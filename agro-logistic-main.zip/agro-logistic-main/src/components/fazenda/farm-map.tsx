"use client";

import { Edit3, MapPinned } from "lucide-react";
import { CircleMarker, MapContainer, Polygon, Popup, TileLayer } from "react-leaflet";
import type { LatLngExpression } from "leaflet";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { SerializedFarm, SerializedField } from "@/lib/farm-calculations";

type Point = [number, number];

type ParsedLocation = {
  point: Point | null;
  polygon: Point[] | null;
};

function isFiniteCoordinate(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isPoint(value: unknown): value is Point {
  return (
    Array.isArray(value) &&
    value.length >= 2 &&
    isFiniteCoordinate(value[0]) &&
    isFiniteCoordinate(value[1]) &&
    Math.abs(value[0]) <= 90 &&
    Math.abs(value[1]) <= 180
  );
}

function parseObjectPoint(value: unknown): Point | null {
  if (!value || typeof value !== "object") {
    return null;
  }

  const record = value as Record<string, unknown>;
  const lat = record.lat ?? record.latitude;
  const lng = record.lng ?? record.lon ?? record.longitude;

  if (isFiniteCoordinate(lat) && isFiniteCoordinate(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
    return [lat, lng];
  }

  return null;
}

export function parseLocation(value: string | null | undefined): ParsedLocation {
  if (!value) {
    return { point: null, polygon: null };
  }

  const trimmed = value.trim();

  try {
    const parsed: unknown = JSON.parse(trimmed);
    const objectPoint = parseObjectPoint(parsed);

    if (objectPoint) {
      return { point: objectPoint, polygon: null };
    }

    if (isPoint(parsed)) {
      return { point: parsed, polygon: null };
    }

    if (Array.isArray(parsed) && parsed.every(isPoint)) {
      const polygon = parsed as Point[];
      return { point: polygon[0] ?? null, polygon: polygon.length >= 3 ? polygon : null };
    }
  } catch {
    const parts = trimmed.split(",").map((part) => Number(part.trim()));
    if (parts.length >= 2 && isPoint(parts)) {
      return { point: [parts[0], parts[1]], polygon: null };
    }
  }

  return { point: null, polygon: null };
}

export function FarmMap({
  farm,
  fields,
  onEditFarm,
  onEditField,
}: {
  farm: SerializedFarm;
  fields: SerializedField[];
  onEditFarm: () => void;
  onEditField: (field: SerializedField) => void;
}) {
  const farmLocation = parseLocation(farm.coordinates);
  const fieldLocations = fields.map((field) => ({ field, location: parseLocation(field.coordinates) }));
  const center = farmLocation.point ?? fieldLocations.find((item) => item.location.point)?.location.point ?? null;

  return (
    <Card className="overflow-hidden rounded-xl border-foreground/10 bg-card/80">
      <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <CardTitle className="text-base">Mapa da fazenda</CardTitle>
          <p className="text-sm text-muted-foreground">
            Mapa Leaflet com localizacao cadastrada e talhoes com coordenadas ou poligonos salvos.
          </p>
        </div>
        <Button variant="outline" onClick={onEditFarm}>
          <Edit3 className="h-4 w-4" />
          Editar localizacao
        </Button>
      </CardHeader>
      <CardContent className="grid gap-4 p-4 xl:grid-cols-[2fr_1fr]">
        {center ? (
          <div className="h-[28rem] overflow-hidden rounded-lg border border-foreground/10">
            <MapContainer center={center as LatLngExpression} zoom={13} scrollWheelZoom={false} className="h-full w-full">
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              {farmLocation.point ? (
                <CircleMarker center={farmLocation.point} radius={8} pathOptions={{ color: "#10b981", fillColor: "#10b981", fillOpacity: 0.7 }}>
                  <Popup>
                    <strong>{farm.name}</strong>
                    <br />
                    {farm.city}/{farm.state}
                  </Popup>
                </CircleMarker>
              ) : null}
              {fieldLocations.map(({ field, location }) => {
                if (location.polygon) {
                  return (
                    <Polygon
                      key={field.id}
                      positions={location.polygon}
                      pathOptions={{ color: "#84cc16", fillColor: "#22c55e", fillOpacity: 0.22, weight: 2 }}
                    >
                      <Popup>
                        <strong>{field.name}</strong>
                        <br />
                        {field.currentCrop || "Sem cultura"} - {field.area.toLocaleString("pt-BR")} ha
                      </Popup>
                    </Polygon>
                  );
                }

                if (location.point) {
                  return (
                    <CircleMarker
                      key={field.id}
                      center={location.point}
                      radius={6}
                      pathOptions={{ color: "#eab308", fillColor: "#eab308", fillOpacity: 0.72 }}
                    >
                      <Popup>
                        <strong>{field.name}</strong>
                        <br />
                        {field.currentCrop || "Sem cultura"} - {field.area.toLocaleString("pt-BR")} ha
                      </Popup>
                    </CircleMarker>
                  );
                }

                return null;
              })}
            </MapContainer>
          </div>
        ) : (
          <div className="flex h-[28rem] items-center justify-center rounded-lg border border-dashed border-foreground/15 bg-background/45 p-6 text-center">
            <div className="max-w-md space-y-3">
              <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-lg border border-emerald-400/25 bg-emerald-500/10 text-emerald-300">
                <MapPinned className="h-5 w-5" />
              </span>
              <p className="text-sm font-medium">Sem coordenadas cadastradas</p>
              <p className="text-sm text-muted-foreground">
                Informe coordenadas da fazenda ou dos talhoes para ativar o mapa. Poligonos podem ser salvos como JSON.
              </p>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {fields.length === 0 ? (
            <div className="rounded-lg border border-foreground/10 bg-background/45 p-4 text-sm text-muted-foreground">
              Nenhum talhao cadastrado para exibir no mapa.
            </div>
          ) : (
            fields.map((field) => (
              <div key={field.id} className="flex items-center justify-between gap-3 rounded-lg border border-foreground/10 bg-background/45 p-3">
                <div>
                  <p className="text-sm font-medium">{field.name}</p>
                  <p className="text-xs text-muted-foreground">{field.coordinates ? "Localizacao cadastrada" : "Sem localizacao"}</p>
                </div>
                <Button variant="ghost" size="icon-sm" title="Editar localizacao" onClick={() => onEditField(field)}>
                  <Edit3 className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
