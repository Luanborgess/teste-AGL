"use client";

import { Search } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fieldStatusLabels } from "@/lib/farm-calculations";
import type { FieldStatusValue } from "@/lib/validations";

export type FieldFiltersState = {
  search: string;
  status: FieldStatusValue | "ALL";
  crop: string;
};

export function FieldFilters({
  filters,
  crops,
  onChange,
}: {
  filters: FieldFiltersState;
  crops: string[];
  onChange: (filters: FieldFiltersState) => void;
}) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardContent className="grid gap-4 p-4 md:grid-cols-[1.5fr_1fr_1fr]">
        <div className="space-y-2">
          <Label>Pesquisar</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={filters.search}
              onChange={(event) => onChange({ ...filters, search: event.target.value })}
              placeholder="Nome, cultura ou tipo de solo"
              className="bg-background/70 pl-9"
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label>Status</Label>
          <Select value={filters.status} onValueChange={(value) => onChange({ ...filters, status: value as FieldFiltersState["status"] })}>
            <SelectTrigger className="bg-background/70">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todos</SelectItem>
              {Object.entries(fieldStatusLabels).map(([value, label]) => (
                <SelectItem key={value} value={value}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Cultura</Label>
          <Select value={filters.crop} onValueChange={(value) => onChange({ ...filters, crop: value })}>
            <SelectTrigger className="bg-background/70">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todas</SelectItem>
              {crops.map((crop) => (
                <SelectItem key={crop} value={crop}>
                  {crop}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
}
