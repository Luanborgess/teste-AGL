"use client";

import { AlertTriangle, MapPin, Pencil } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { SerializedFarm } from "@/lib/farm-calculations";
import { formatCoordinates, formatHectares, formatProductivity } from "@/lib/formatters";

export function FarmMainCard({
  farm,
  summary,
  onEdit,
}: {
  farm: SerializedFarm;
  summary: {
    cultivatedArea: number;
    availableArea: number;
    fieldCount: number;
    averageProductivity: number | null;
    activeCrops: string[];
    isAreaExceeded: boolean;
  };
  onEdit: () => void;
}) {
  return (
    <Card className="overflow-hidden rounded-xl border-emerald-500/15 bg-card/80">
      <CardHeader className="flex flex-col gap-4 border-b border-foreground/10 bg-emerald-500/[0.03] sm:flex-row sm:items-start sm:justify-between">
        <div>
          <CardTitle className="text-2xl">{farm.name}</CardTitle>
          <p className="mt-1 text-sm text-muted-foreground">
            {farm.owner} - {farm.city}/{farm.state}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="outline" className="border-emerald-500/20 bg-emerald-500/10 text-emerald-300">
            {farm.productionType || "Sem producao definida"}
          </Badge>
          <Button variant="outline" onClick={onEdit}>
            <Pencil className="h-4 w-4" />
            Editar Fazenda
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-5 p-5">
        {summary.isAreaExceeded ? (
          <Alert className="rounded-xl border-red-500/25 bg-red-500/10">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Area dos talhoes acima da area total</AlertTitle>
            <AlertDescription>
              Revise a area da fazenda ou ajuste os talhoes. Novos cadastros ficam bloqueados enquanto houver excesso.
            </AlertDescription>
          </Alert>
        ) : null}

        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <InfoBlock label="Area total" value={formatHectares(farm.totalArea)} />
          <InfoBlock label="Talhoes" value={`${summary.fieldCount.toLocaleString("pt-BR")} cadastrados`} />
          <InfoBlock label="Area cultivada" value={formatHectares(summary.cultivatedArea)} />
          <InfoBlock label="Area disponivel" value={formatHectares(summary.availableArea)} danger={summary.availableArea < 0} />
          <InfoBlock label="Produtividade media" value={formatProductivity(summary.averageProductivity)} />
          <InfoBlock
            label="Culturas ativas"
            value={summary.activeCrops.length > 0 ? summary.activeCrops.join(", ") : "Nenhuma cultura ativa"}
          />
          <InfoBlock label="Localizacao" value={formatCoordinates(farm.coordinates)} icon />
          <InfoBlock label="Observacoes" value={farm.notes || "Sem observacoes"} />
        </div>
      </CardContent>
    </Card>
  );
}

function InfoBlock({ label, value, danger = false, icon = false }: { label: string; value: string; danger?: boolean; icon?: boolean }) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-background/45 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={danger ? "mt-1 flex items-center gap-1 text-sm font-medium text-red-300" : "mt-1 flex items-center gap-1 text-sm font-medium"}>
        {icon ? <MapPin className="h-3.5 w-3.5 text-emerald-300" /> : null}
        {value}
      </p>
    </div>
  );
}
