"use client";

import { Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { SerializedField } from "@/lib/farm-calculations";
import { formatHectares } from "@/lib/formatters";

export function FieldDeleteDialog({
  field,
  deleting,
  onOpenChange,
  onConfirm,
}: {
  field: SerializedField | null;
  deleting: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => Promise<void>;
}) {
  return (
    <Dialog open={Boolean(field)} onOpenChange={onOpenChange}>
      <DialogContent className="border-red-500/15 bg-popover/95 sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Excluir talhao</DialogTitle>
          <DialogDescription>
            Esta acao remove o talhao da fazenda e recalcula area utilizada, area disponivel, culturas e produtividade.
          </DialogDescription>
        </DialogHeader>

        {field ? (
          <div className="rounded-xl border border-red-500/15 bg-red-500/10 p-4 text-sm">
            <p className="font-medium">{field.name}</p>
            <p className="mt-1 text-muted-foreground">
              {formatHectares(field.area)} - {field.currentCrop || "Sem cultura"}
            </p>
          </div>
        ) : null}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={deleting}>
            Cancelar
          </Button>
          <Button variant="destructive" onClick={onConfirm} disabled={deleting}>
            {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            {deleting ? "Excluindo..." : "Excluir"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
