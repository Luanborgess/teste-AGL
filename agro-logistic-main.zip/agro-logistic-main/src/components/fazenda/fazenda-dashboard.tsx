"use client";

import dynamic from "next/dynamic";
import { AlertTriangle, Layers3, Plus } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FarmEmptyState } from "@/components/fazenda/farm-empty-state";
import { FarmFormModal } from "@/components/fazenda/farm-form-modal";
import { FarmHeader } from "@/components/fazenda/farm-header";
import { FarmMainCard } from "@/components/fazenda/farm-main-card";
import { FarmSummaryCards } from "@/components/fazenda/farm-summary-cards";
import { FieldDeleteDialog } from "@/components/fazenda/field-delete-dialog";
import { FieldDetailsModal } from "@/components/fazenda/field-details-modal";
import { FieldFilters, type FieldFiltersState } from "@/components/fazenda/field-filters";
import { FieldFormModal } from "@/components/fazenda/field-form-modal";
import { FieldsTable, type FieldSortDirection, type FieldSortKey } from "@/components/fazenda/fields-table";
import {
  buildFarmSummary,
  fieldStatusLabels,
  type SerializedFarm,
  type SerializedField,
} from "@/lib/farm-calculations";
import { formatHectares } from "@/lib/formatters";
import type { FarmValues, FieldValues } from "@/lib/validations";

const pageSize = 8;

const FarmMap = dynamic(() => import("@/components/fazenda/farm-map").then((mod) => mod.FarmMap), {
  ssr: false,
  loading: () => <div className="h-[34rem] animate-pulse rounded-xl border border-foreground/10 bg-card/70" />,
});

type FarmPayload = {
  farm: SerializedFarm | null;
};

function getApiError(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string") {
    return payload.error;
  }

  return fallback;
}

function normalizeField(field: SerializedField): SerializedField {
  return {
    ...field,
    createdAt: new Date(field.createdAt).toISOString(),
    updatedAt: new Date(field.updatedAt).toISOString(),
  };
}

function normalizeFarm(farm: SerializedFarm): SerializedFarm {
  return {
    ...farm,
    createdAt: new Date(farm.createdAt).toISOString(),
    updatedAt: new Date(farm.updatedAt).toISOString(),
    fields: farm.fields.map(normalizeField),
  };
}

function sortValue(field: SerializedField, key: FieldSortKey) {
  if (key === "name") {
    return field.name.toLocaleLowerCase("pt-BR");
  }

  return field[key] ?? 0;
}

export function FazendaDashboard({ initialFarm }: { initialFarm: SerializedFarm | null }) {
  const [farm, setFarm] = useState<SerializedFarm | null>(() => (initialFarm ? normalizeFarm(initialFarm) : null));
  const [farmModalOpen, setFarmModalOpen] = useState(!initialFarm);
  const [fieldModalOpen, setFieldModalOpen] = useState(false);
  const [selectedField, setSelectedField] = useState<SerializedField | null>(null);
  const [detailsField, setDetailsField] = useState<SerializedField | null>(null);
  const [fieldToDelete, setFieldToDelete] = useState<SerializedField | null>(null);
  const [filters, setFilters] = useState<FieldFiltersState>({ search: "", status: "ALL", crop: "ALL" });
  const [sortKey, setSortKey] = useState<FieldSortKey>("name");
  const [sortDirection, setSortDirection] = useState<FieldSortDirection>("asc");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [savingFarm, setSavingFarm] = useState(false);
  const [savingField, setSavingField] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const summary = useMemo(() => (farm ? buildFarmSummary(farm) : null), [farm]);
  const fields = useMemo(() => farm?.fields ?? [], [farm]);
  const crops = useMemo(
    () =>
      Array.from(new Set(fields.map((field) => field.currentCrop?.trim()).filter((crop): crop is string => Boolean(crop)))).sort((a, b) =>
        a.localeCompare(b, "pt-BR"),
      ),
    [fields],
  );

  const filteredFields = useMemo(() => {
    const search = filters.search.trim().toLocaleLowerCase("pt-BR");

    return fields
      .filter((field) => {
        const matchesSearch =
          !search ||
          field.name.toLocaleLowerCase("pt-BR").includes(search) ||
          (field.currentCrop ?? "").toLocaleLowerCase("pt-BR").includes(search) ||
          (field.soilType ?? "").toLocaleLowerCase("pt-BR").includes(search);
        const matchesStatus = filters.status === "ALL" || field.status === filters.status;
        const matchesCrop = filters.crop === "ALL" || field.currentCrop === filters.crop;

        return matchesSearch && matchesStatus && matchesCrop;
      })
      .sort((a, b) => {
        const aValue = sortValue(a, sortKey);
        const bValue = sortValue(b, sortKey);

        if (typeof aValue === "string" && typeof bValue === "string") {
          return sortDirection === "desc" ? bValue.localeCompare(aValue, "pt-BR") : aValue.localeCompare(bValue, "pt-BR");
        }

        return sortDirection === "desc" ? Number(bValue) - Number(aValue) : Number(aValue) - Number(bValue);
      });
  }, [fields, filters, sortDirection, sortKey]);

  const totalPages = Math.max(1, Math.ceil(filteredFields.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginatedFields = filteredFields.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  async function loadFarm() {
    setLoading(true);
    setError(null);

    const response = await fetch("/api/fazenda", { cache: "no-store" });
    const payload = await response.json().catch(() => null);
    setLoading(false);

    if (!response.ok) {
      const message = getApiError(payload, "Nao foi possivel carregar a fazenda.");
      setError(message);
      toast.error(message);
      return;
    }

    const nextFarm = (payload as FarmPayload).farm;
    setFarm(nextFarm ? normalizeFarm(nextFarm) : null);
    if (!nextFarm) {
      setFarmModalOpen(true);
    }
  }

  function openCreateField() {
    if (!farm) {
      toast.error("Cadastre a fazenda antes de criar talhoes.");
      return;
    }

    if (summary?.isAreaExceeded) {
      toast.error("A area dos talhoes ja ultrapassa a area total da fazenda.");
      return;
    }

    setSelectedField(null);
    setFieldModalOpen(true);
  }

  function openEditField(field: SerializedField) {
    setSelectedField(field);
    setFieldModalOpen(true);
  }

  function toggleSort(key: FieldSortKey) {
    setPage(1);

    if (key === sortKey) {
      setSortDirection((current) => (current === "desc" ? "asc" : "desc"));
      return;
    }

    setSortKey(key);
    setSortDirection(key === "name" ? "asc" : "desc");
  }

  async function saveFarm(values: FarmValues) {
    setSavingFarm(true);
    const isEdit = Boolean(farm);
    const response = await fetch("/api/fazenda", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingFarm(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel salvar a fazenda."));
      return false;
    }

    toast.success(isEdit ? "Fazenda atualizada." : "Fazenda cadastrada.");
    setFarm(normalizeFarm((payload as FarmPayload).farm as SerializedFarm));
    setFarmModalOpen(false);
    return true;
  }

  async function saveField(values: FieldValues) {
    if (!farm) {
      toast.error("Cadastre a fazenda antes de salvar talhoes.");
      return false;
    }

    setSavingField(true);
    const isEdit = Boolean(selectedField);
    const response = await fetch(isEdit ? `/api/fazenda/fields/${selectedField?.id}` : "/api/fazenda/fields", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingField(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel salvar o talhao."));
      return false;
    }

    toast.success(isEdit ? "Talhao atualizado." : "Talhao cadastrado.");
    setFieldModalOpen(false);
    setSelectedField(null);
    await loadFarm();
    return true;
  }

  async function deleteField() {
    if (!fieldToDelete) {
      return;
    }

    setDeleting(true);
    const response = await fetch(`/api/fazenda/fields/${fieldToDelete.id}`, { method: "DELETE" });
    const payload = await response.json().catch(() => null);
    setDeleting(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel excluir o talhao."));
      return;
    }

    toast.success("Talhao excluido.");
    setFieldToDelete(null);
    await loadFarm();
  }

  if (loading && !farm) {
    return <FarmSkeleton />;
  }

  return (
    <div className="space-y-6">
      <FarmHeader
        hasFarm={Boolean(farm)}
        loading={loading}
        onCreate={() => setFarmModalOpen(true)}
        onEdit={() => setFarmModalOpen(true)}
        onRefresh={loadFarm}
      />

      {error ? (
        <Card className="rounded-xl border-red-500/20 bg-red-500/10">
          <CardContent className="p-4 text-sm text-red-200">{error}</CardContent>
        </Card>
      ) : null}

      {!farm || !summary ? (
        <FarmEmptyState onCreate={() => setFarmModalOpen(true)} />
      ) : (
        <>
          <FarmMainCard farm={farm} summary={summary} onEdit={() => setFarmModalOpen(true)} />
          <FarmSummaryCards summary={summary} />

          {summary.isAreaExceeded ? (
            <Alert className="rounded-xl border-red-500/25 bg-red-500/10">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Limite de area excedido</AlertTitle>
              <AlertDescription>
                A soma dos talhoes e {formatHectares(summary.totalFieldArea)}, maior que a area total da fazenda. Edite ou exclua talhoes
                antes de cadastrar uma nova area.
              </AlertDescription>
            </Alert>
          ) : null}

          <FarmMetricsPanel summary={summary} />

          <div className="flex flex-col gap-3 rounded-xl border border-emerald-500/15 bg-card/70 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm font-medium">Sistema de talhoes</p>
              <p className="text-sm text-muted-foreground">Cadastre areas reais da fazenda para acompanhar cultura, solo, status e produtividade.</p>
            </div>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={openCreateField} disabled={summary.isAreaExceeded}>
              <Plus className="h-4 w-4" />
              Cadastrar talhao
            </Button>
          </div>

          {fields.length === 0 ? (
            <Card className="rounded-xl border-dashed border-foreground/15 bg-card/70">
              <CardContent className="flex min-h-52 flex-col items-center justify-center gap-3 p-6 text-center">
                <span className="flex h-12 w-12 items-center justify-center rounded-lg border border-emerald-400/25 bg-emerald-500/10 text-emerald-300">
                  <Layers3 className="h-5 w-5" />
                </span>
                <p className="text-sm font-medium">Nenhum talhao cadastrado</p>
                <p className="max-w-md text-sm text-muted-foreground">
                  Os indicadores de area cultivada, culturas ativas e produtividade serao recalculados assim que voce salvar o primeiro talhao.
                </p>
                <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={openCreateField}>
                  <Plus className="h-4 w-4" />
                  Cadastrar talhao
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              <FieldFilters
                filters={filters}
                crops={crops}
                onChange={(nextFilters) => {
                  setFilters(nextFilters);
                  setPage(1);
                }}
              />
              <FieldsTable
                fields={paginatedFields}
                totalResults={filteredFields.length}
                page={currentPage}
                totalPages={totalPages}
                sortKey={sortKey}
                sortDirection={sortDirection}
                onSort={toggleSort}
                onPageChange={(nextPage) => setPage(Math.min(Math.max(nextPage, 1), totalPages))}
                onCreate={openCreateField}
                onView={setDetailsField}
                onEdit={openEditField}
                onDelete={setFieldToDelete}
              />
            </>
          )}

          <FarmMap farm={farm} fields={fields} onEditFarm={() => setFarmModalOpen(true)} onEditField={openEditField} />
        </>
      )}

      <FarmFormModal open={farmModalOpen} farm={farm} saving={savingFarm} onOpenChange={setFarmModalOpen} onSubmit={saveFarm} />
      {farm ? (
        <FieldFormModal
          open={fieldModalOpen}
          field={selectedField}
          fields={fields}
          totalArea={farm.totalArea}
          saving={savingField}
          onOpenChange={(open) => {
            setFieldModalOpen(open);
            if (!open) {
              setSelectedField(null);
            }
          }}
          onSubmit={saveField}
        />
      ) : null}
      <FieldDetailsModal
        field={detailsField}
        onOpenChange={(open) => {
          if (!open) {
            setDetailsField(null);
          }
        }}
      />
      <FieldDeleteDialog
        field={fieldToDelete}
        deleting={deleting}
        onOpenChange={(open) => {
          if (!open) {
            setFieldToDelete(null);
          }
        }}
        onConfirm={deleteField}
      />
    </div>
  );
}

function FarmMetricsPanel({ summary }: { summary: ReturnType<typeof buildFarmSummary> }) {
  return (
    <div className="grid gap-4 xl:grid-cols-2">
      <Card className="rounded-xl border-foreground/10 bg-card/80">
        <CardHeader>
          <CardTitle className="text-base">Talhoes por status</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-2 sm:grid-cols-2">
          {Object.entries(summary.fieldsByStatus).map(([status, count]) => (
            <div key={status} className="flex items-center justify-between rounded-lg border border-foreground/10 bg-background/45 p-3">
              <span className="text-sm text-muted-foreground">{fieldStatusLabels[status as keyof typeof fieldStatusLabels]}</span>
              <span className="font-mono text-sm font-semibold">{count.toLocaleString("pt-BR")}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="rounded-xl border-foreground/10 bg-card/80">
        <CardHeader>
          <CardTitle className="text-base">Area por cultura</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {summary.areaByCrop.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhuma cultura cadastrada nos talhoes.</p>
          ) : (
            summary.areaByCrop.map((item) => (
              <div key={item.crop} className="flex items-center justify-between rounded-lg border border-foreground/10 bg-background/45 p-3">
                <span className="text-sm text-muted-foreground">{item.crop}</span>
                <span className="font-mono text-sm font-semibold">{formatHectares(item.area)}</span>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function FarmSkeleton() {
  return (
    <div className="space-y-6">
      <div className="h-28 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
        {["total", "cultivada", "livre", "talhoes", "culturas", "produtividade"].map((item) => (
          <div key={item} className="h-28 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
        ))}
      </div>
      <div className="h-96 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
    </div>
  );
}
