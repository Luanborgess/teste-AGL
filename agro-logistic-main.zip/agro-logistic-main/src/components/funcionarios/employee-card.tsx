"use client";

import { CalendarDays, Eye, Pencil, Power, Trash2, UserCheck, UsersRound } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  describeAttendance,
  employeeStatusLabels,
  getCurrentAssignment,
  getLastAttendance,
  type SerializedEmployee,
} from "@/lib/employee-calculations";
import { formatCPF, formatCurrencyBRL, formatDateBR, formatPhoneBR, getInitials } from "@/lib/formatters";
import { cn } from "@/lib/utils";

const statusClass = {
  ATIVO: "border-emerald-500/25 bg-emerald-500/10 text-emerald-300",
  INATIVO: "border-zinc-500/25 bg-zinc-500/10 text-zinc-300",
  AFASTADO: "border-amber-500/25 bg-amber-500/10 text-amber-300",
  DEMITIDO: "border-red-500/25 bg-red-500/10 text-red-300",
};

export function EmployeeCard({
  employee,
  onView,
  onEdit,
  onDelete,
  onToggleStatus,
  onAttendance,
  onAssign,
}: {
  employee: SerializedEmployee;
  onView: (employee: SerializedEmployee) => void;
  onEdit: (employee: SerializedEmployee) => void;
  onDelete: (employee: SerializedEmployee) => void;
  onToggleStatus: (employee: SerializedEmployee) => void;
  onAttendance: (employee: SerializedEmployee) => void;
  onAssign: (employee: SerializedEmployee) => void;
}) {
  const assignment = getCurrentAssignment(employee);
  const lastAttendance = getLastAttendance(employee);

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80 transition duration-200 hover:-translate-y-0.5 hover:border-emerald-500/25 hover:shadow-lg hover:shadow-emerald-950/10">
      <CardContent className="p-4">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-emerald-400/25 bg-emerald-500/10 text-sm font-semibold text-emerald-200">
              {getInitials(employee.fullName)}
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="truncate text-base font-semibold tracking-tight">{employee.fullName}</h3>
                <Badge className={cn("border", statusClass[employee.status])}>{employeeStatusLabels[employee.status]}</Badge>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                {employee.role}
                {employee.department ? ` - ${employee.department}` : ""}
              </p>
              <div className="mt-3 grid gap-2 text-sm text-muted-foreground sm:grid-cols-2 xl:grid-cols-4">
                <span>{formatCurrencyBRL(employee.salary)}</span>
                <span>{formatPhoneBR(employee.phone)}</span>
                <span>CPF {formatCPF(employee.cpf)}</span>
                <span className="inline-flex items-center gap-1">
                  <CalendarDays className="h-3.5 w-3.5" />
                  {formatDateBR(employee.admissionDate)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 lg:justify-end">
            <Button size="icon-sm" variant="outline" title="Visualizar detalhes" onClick={() => onView(employee)}>
              <Eye className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Editar" onClick={() => onEdit(employee)}>
              <Pencil className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Ativar ou desativar" onClick={() => onToggleStatus(employee)}>
              <Power className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Registrar presenca" onClick={() => onAttendance(employee)}>
              <UserCheck className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Alocar em atividade" onClick={() => onAssign(employee)}>
              <UsersRound className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="destructive" title="Excluir" onClick={() => onDelete(employee)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="mt-4 grid gap-3 border-t border-foreground/10 pt-4 md:grid-cols-2">
          <div className="rounded-lg border border-foreground/10 bg-background/40 p-3">
            <p className="text-xs text-muted-foreground">Equipe atual</p>
            <p className="mt-1 text-sm font-medium">
              {assignment ? `${assignment.activity} - ${assignment.location}` : "Sem alocacao hoje"}
            </p>
          </div>
          <div className="rounded-lg border border-foreground/10 bg-background/40 p-3">
            <p className="text-xs text-muted-foreground">Ultima presenca</p>
            <p className="mt-1 text-sm font-medium">{describeAttendance(lastAttendance)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
