"use client";

import { Pencil, Trash2, UsersRound } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { assignmentStatusLabels, type SerializedTeamAssignment } from "@/lib/employee-calculations";
import { formatDateBR } from "@/lib/formatters";

export function TeamAssignmentsList({
  assignments,
  onEdit,
  onDelete,
}: {
  assignments: SerializedTeamAssignment[];
  onEdit: (assignment: SerializedTeamAssignment) => void;
  onDelete: (assignment: SerializedTeamAssignment) => void;
}) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle>Logistica de Equipe</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {assignments.length === 0 ? (
          <p className="rounded-lg border border-dashed border-foreground/10 p-4 text-sm text-muted-foreground">
            Nenhuma escala ou alocacao registrada.
          </p>
        ) : (
          assignments.slice(0, 12).map((assignment) => (
            <div key={assignment.id} className="rounded-xl border border-foreground/10 bg-background/40 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-medium">
                      {assignment.activity} - {assignment.location}
                    </h3>
                    <Badge variant="outline">{assignmentStatusLabels[assignment.status]}</Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {formatDateBR(assignment.date)}
                    {assignment.transport ? ` - ${assignment.transport}` : ""}
                    {assignment.vehicle ? ` - ${assignment.vehicle}` : ""}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button size="icon-sm" variant="outline" title="Editar escala" onClick={() => onEdit(assignment)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="icon-sm" variant="destructive" title="Excluir escala" onClick={() => onDelete(assignment)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1 rounded-full border border-foreground/10 px-2 py-1">
                  <UsersRound className="h-3.5 w-3.5" />
                  {assignment.members.length} funcionario(s)
                </span>
                {assignment.driver ? <span className="rounded-full border border-foreground/10 px-2 py-1">Motorista: {assignment.driver}</span> : null}
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
