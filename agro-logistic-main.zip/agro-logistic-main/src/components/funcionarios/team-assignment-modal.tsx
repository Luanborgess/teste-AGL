"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect, useMemo } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import {
  assignmentActivities,
  assignmentStatusLabels,
  type SerializedEmployee,
  type SerializedTeamAssignment,
} from "@/lib/employee-calculations";
import {
  teamAssignmentSchema,
  type TeamAssignmentInput,
  type TeamAssignmentStatusValue,
  type TeamAssignmentValues,
} from "@/lib/validations";

function todayInput() {
  return new Date().toISOString().slice(0, 10);
}

function timeInput(value: string | null) {
  return value ? new Date(value).toTimeString().slice(0, 5) : "";
}

function valuesFromAssignment(
  assignment: SerializedTeamAssignment | null,
  preselectedEmployee: SerializedEmployee | null,
): TeamAssignmentInput {
  if (!assignment) {
    return {
      activity: "Colheita",
      location: "",
      date: todayInput(),
      startTime: "",
      endTime: "",
      employeeIds: preselectedEmployee ? [preselectedEmployee.id] : [],
      transport: "",
      vehicle: "",
      driver: "",
      notes: "",
      status: "PLANEJADA",
    };
  }

  return {
    activity: assignment.activity,
    location: assignment.location,
    date: new Date(assignment.date).toISOString().slice(0, 10),
    startTime: timeInput(assignment.startTime),
    endTime: timeInput(assignment.endTime),
    employeeIds: assignment.members.map((member) => member.employeeId),
    transport: assignment.transport ?? "",
    vehicle: assignment.vehicle ?? "",
    driver: assignment.driver ?? "",
    notes: assignment.notes ?? "",
    status: assignment.status,
  };
}

export function TeamAssignmentModal({
  open,
  employees,
  assignment,
  preselectedEmployee,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  employees: SerializedEmployee[];
  assignment: SerializedTeamAssignment | null;
  preselectedEmployee: SerializedEmployee | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: TeamAssignmentValues) => Promise<void>;
}) {
  const form = useForm<TeamAssignmentInput, unknown, TeamAssignmentValues>({
    resolver: zodResolver(teamAssignmentSchema),
    defaultValues: valuesFromAssignment(assignment, preselectedEmployee),
  });
  const selectedActivity = useWatch({ control: form.control, name: "activity" });
  const selectedStatus = useWatch({ control: form.control, name: "status" });
  const selectedEmployees = useWatch({ control: form.control, name: "employeeIds" });
  const activeEmployees = useMemo(() => employees.filter((employee) => employee.status === "ATIVO"), [employees]);

  useEffect(() => {
    if (open) {
      form.reset(valuesFromAssignment(assignment, preselectedEmployee));
    }
  }, [assignment, form, open, preselectedEmployee]);

  function toggleEmployee(employeeId: string, checked: boolean) {
    const current = new Set(selectedEmployees ?? []);

    if (checked) {
      current.add(employeeId);
    } else {
      current.delete(employeeId);
    }

    form.setValue("employeeIds", [...current], { shouldValidate: true });
  }

  async function submit(values: TeamAssignmentValues) {
    await onSubmit(values);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-5xl">
        <DialogHeader>
          <DialogTitle>{assignment ? "Editar escala" : "Alocar equipe"}</DialogTitle>
          <DialogDescription>Defina atividade, local, transporte e os funcionarios alocados na operacao.</DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Atividade" error={form.formState.errors.activity?.message}>
            <Select disabled={saving} value={selectedActivity} onValueChange={(value) => form.setValue("activity", value, { shouldValidate: true })}>
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Atividade" />
              </SelectTrigger>
              <SelectContent>
                {assignmentActivities.map((activity) => (
                  <SelectItem key={activity} value={activity}>
                    {activity}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Local / Talhao" error={form.formState.errors.location?.message}>
            <TextInput disabled={saving} placeholder="Talhao 1" {...form.register("location")} />
          </Field>

          <Field label="Data" error={form.formState.errors.date?.message}>
            <TextInput disabled={saving} type="date" {...form.register("date")} />
          </Field>

          <Field label="Status" error={form.formState.errors.status?.message}>
            <Select
              disabled={saving}
              value={selectedStatus}
              onValueChange={(value) => form.setValue("status", value as TeamAssignmentStatusValue, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(assignmentStatusLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Horario de saida" error={form.formState.errors.startTime?.message}>
            <TextInput disabled={saving} type="time" {...form.register("startTime")} />
          </Field>

          <Field label="Horario de retorno" error={form.formState.errors.endTime?.message}>
            <TextInput disabled={saving} type="time" {...form.register("endTime")} />
          </Field>

          <Field label="Transporte" error={form.formState.errors.transport?.message}>
            <TextInput disabled={saving} placeholder="Caminhonete, onibus, trator" {...form.register("transport")} />
          </Field>

          <Field label="Veiculo" error={form.formState.errors.vehicle?.message}>
            <TextInput disabled={saving} placeholder="Placa ou identificacao" {...form.register("vehicle")} />
          </Field>

          <Field label="Motorista" error={form.formState.errors.driver?.message} className="md:col-span-2">
            <TextInput disabled={saving} placeholder="Nome do motorista" {...form.register("driver")} />
          </Field>

          <Field label="Funcionarios selecionados" error={form.formState.errors.employeeIds?.message} className="md:col-span-2">
            <div className="grid max-h-56 gap-2 overflow-y-auto rounded-lg border border-foreground/10 bg-background/50 p-3 sm:grid-cols-2">
              {activeEmployees.length === 0 ? (
                <p className="text-sm text-muted-foreground">Cadastre funcionarios ativos para montar a equipe.</p>
              ) : (
                activeEmployees.map((employee) => (
                  <label
                    key={employee.id}
                    className="flex items-center gap-3 rounded-lg border border-foreground/10 bg-card/60 p-3 text-sm transition hover:border-emerald-500/20"
                  >
                    <input
                      type="checkbox"
                      className="h-4 w-4 accent-emerald-500"
                      checked={(selectedEmployees ?? []).includes(employee.id)}
                      disabled={saving}
                      onChange={(event) => toggleEmployee(employee.id, event.target.checked)}
                    />
                    <span>
                      <span className="block font-medium">{employee.fullName}</span>
                      <span className="text-xs text-muted-foreground">{employee.role}</span>
                    </span>
                  </label>
                ))
              )}
            </div>
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Detalhes da operacao, riscos, instrucoes ou materiais." {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar escala"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
