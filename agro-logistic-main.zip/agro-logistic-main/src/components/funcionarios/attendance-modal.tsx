"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import { attendanceStatusLabels, type SerializedEmployee } from "@/lib/employee-calculations";
import {
  employeeAttendanceSchema,
  type AttendanceStatusValue,
  type EmployeeAttendanceInput,
  type EmployeeAttendanceValues,
} from "@/lib/validations";

function todayInput() {
  return new Date().toISOString().slice(0, 10);
}

function buildValues(employee: SerializedEmployee | null): EmployeeAttendanceInput {
  return {
    employeeId: employee?.id ?? "",
    date: todayInput(),
    status: "PRESENTE",
    checkIn: "",
    checkOut: "",
    notes: "",
  };
}

export function AttendanceModal({
  open,
  employees,
  employee,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  employees: SerializedEmployee[];
  employee: SerializedEmployee | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: EmployeeAttendanceValues) => Promise<void>;
}) {
  const form = useForm<EmployeeAttendanceInput, unknown, EmployeeAttendanceValues>({
    resolver: zodResolver(employeeAttendanceSchema),
    defaultValues: buildValues(employee),
  });
  const selectedEmployeeId = useWatch({ control: form.control, name: "employeeId" });
  const selectedStatus = useWatch({ control: form.control, name: "status" });

  useEffect(() => {
    if (open) {
      form.reset(buildValues(employee));
    }
  }, [employee, form, open]);

  async function submit(values: EmployeeAttendanceValues) {
    await onSubmit(values);
    form.reset(buildValues(employee));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Registrar presenca</DialogTitle>
          <DialogDescription>O registro atualiza ausencias, historico e detalhes do funcionario.</DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Funcionario" error={form.formState.errors.employeeId?.message} className="md:col-span-2">
            <Select
              disabled={saving || Boolean(employee)}
              value={selectedEmployeeId}
              onValueChange={(value) => form.setValue("employeeId", value, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o funcionario" />
              </SelectTrigger>
              <SelectContent>
                {employees.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.fullName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Data" error={form.formState.errors.date?.message}>
            <TextInput disabled={saving} type="date" {...form.register("date")} />
          </Field>

          <Field label="Status" error={form.formState.errors.status?.message}>
            <Select
              disabled={saving}
              value={selectedStatus}
              onValueChange={(value) => form.setValue("status", value as AttendanceStatusValue, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(attendanceStatusLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Horario de entrada" error={form.formState.errors.checkIn?.message}>
            <TextInput disabled={saving} type="time" {...form.register("checkIn")} />
          </Field>

          <Field label="Horario de saida" error={form.formState.errors.checkOut?.message}>
            <TextInput disabled={saving} type="time" {...form.register("checkOut")} />
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Atraso, justificativa ou detalhe do ponto." {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Registrar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
