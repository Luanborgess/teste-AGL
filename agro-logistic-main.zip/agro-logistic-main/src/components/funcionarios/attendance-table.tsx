"use client";

import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { attendanceStatusLabels, type SerializedEmployeeAttendance } from "@/lib/employee-calculations";
import { formatDateBR } from "@/lib/formatters";

export function AttendanceTable({ attendances }: { attendances: SerializedEmployeeAttendance[] }) {
  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardHeader>
        <CardTitle>Presencas recentes</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {attendances.length === 0 ? (
          <p className="rounded-lg border border-dashed border-foreground/10 p-4 text-sm text-muted-foreground">
            Nenhum registro de presenca ainda.
          </p>
        ) : (
          attendances.slice(0, 12).map((attendance) => (
            <div
              key={attendance.id}
              className="flex flex-col gap-2 rounded-lg border border-foreground/10 bg-background/40 p-3 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <p className="font-medium">{attendance.employeeName ?? "Funcionario"}</p>
                <p className="text-xs text-muted-foreground">{formatDateBR(attendance.date)}</p>
              </div>
              <Badge variant="outline">{attendanceStatusLabels[attendance.status]}</Badge>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
