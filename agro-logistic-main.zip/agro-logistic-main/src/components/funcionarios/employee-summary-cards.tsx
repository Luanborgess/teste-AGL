"use client";

import { BriefcaseBusiness, CalendarX2, CircleDollarSign, Truck, UserCheck, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrencyBRL, formatInteger } from "@/lib/formatters";
import type { EmployeeSummary } from "@/lib/employee-calculations";

const cards = [
  {
    key: "totalEmployees",
    label: "Total de Funcionarios",
    helper: "Equipe cadastrada",
    icon: Users,
    tone: "text-emerald-300 bg-emerald-500/10 border-emerald-500/20",
  },
  {
    key: "activeEmployees",
    label: "Funcionarios Ativos",
    helper: "Status ativo",
    icon: UserCheck,
    tone: "text-lime-300 bg-lime-500/10 border-lime-500/20",
  },
  {
    key: "payroll",
    label: "Folha de Pagamento",
    helper: "Salarios ativos",
    icon: CircleDollarSign,
    tone: "text-sky-300 bg-sky-500/10 border-sky-500/20",
  },
  {
    key: "fieldTeamsToday",
    label: "Equipes em Campo",
    helper: "Alocacoes EM_CAMPO hoje",
    icon: BriefcaseBusiness,
    tone: "text-violet-300 bg-violet-500/10 border-violet-500/20",
  },
  {
    key: "estimatedDailyCost",
    label: "Custo Diario Estimado",
    helper: "Salario/30 dos alocados hoje",
    icon: Truck,
    tone: "text-cyan-300 bg-cyan-500/10 border-cyan-500/20",
  },
  {
    key: "absencesToday",
    label: "Ausencias Hoje",
    helper: "Presencas AUSENTE",
    icon: CalendarX2,
    tone: "text-rose-300 bg-rose-500/10 border-rose-500/20",
  },
] as const;

export function EmployeeSummaryCards({ summary }: { summary: EmployeeSummary }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
      {cards.map((card) => {
        const Icon = card.icon;
        const rawValue = summary[card.key];
        const value =
          card.key === "payroll" || card.key === "estimatedDailyCost"
            ? formatCurrencyBRL(rawValue)
            : formatInteger(rawValue);

        return (
          <Card
            key={card.key}
            className="rounded-xl border-foreground/10 bg-card/80 transition duration-200 hover:-translate-y-0.5 hover:border-emerald-500/20"
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm text-muted-foreground">{card.label}</p>
                  <p className="mt-2 text-2xl font-semibold tracking-tight">{value}</p>
                </div>
                <span className={`flex h-10 w-10 items-center justify-center rounded-lg border ${card.tone}`}>
                  <Icon className="h-5 w-5" />
                </span>
              </div>
              <p className="mt-4 text-xs text-muted-foreground">{card.helper}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
