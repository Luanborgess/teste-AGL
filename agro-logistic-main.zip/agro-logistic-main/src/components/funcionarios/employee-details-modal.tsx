"use client";

import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  assignmentStatusLabels,
  attendanceStatusLabels,
  employeeStatusLabels,
  type SerializedEmployee,
} from "@/lib/employee-calculations";
import { formatCPF, formatCurrencyBRL, formatDateBR, formatPhoneBR } from "@/lib/formatters";

export function EmployeeDetailsModal({
  employee,
  onOpenChange,
}: {
  employee: SerializedEmployee | null;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={Boolean(employee)} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-5xl">
        {employee ? (
          <>
            <DialogHeader>
              <DialogTitle>{employee.fullName}</DialogTitle>
              <DialogDescription>Dados pessoais, historico operacional, presencas e salario.</DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
              <section className="space-y-3 rounded-xl border border-foreground/10 bg-background/40 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Cargo e setor</p>
                    <p className="font-medium">
                      {employee.role}
                      {employee.department ? ` - ${employee.department}` : ""}
                    </p>
                  </div>
                  <Badge className="border border-emerald-500/25 bg-emerald-500/10 text-emerald-300">
                    {employeeStatusLabels[employee.status]}
                  </Badge>
                </div>
                <Info label="CPF" value={formatCPF(employee.cpf)} />
                <Info label="Telefone" value={formatPhoneBR(employee.phone)} />
                <Info label="E-mail" value={employee.email ?? "Nao informado"} />
                <Info label="Salario atual" value={formatCurrencyBRL(employee.salary)} />
                <Info label="Admissao" value={formatDateBR(employee.admissionDate)} />
                <Info label="Endereco" value={employee.address ?? "Nao informado"} />
                <Info label="Contato de emergencia" value={employee.emergencyContact ?? "Nao informado"} />
                <Info label="Ultima atualizacao" value={formatDateBR(employee.updatedAt)} />
                <div>
                  <p className="text-xs text-muted-foreground">Observacoes</p>
                  <p className="mt-1 text-sm">{employee.notes || "Sem observacoes"}</p>
                </div>
              </section>

              <section className="space-y-4">
                <HistoryBlock title="Historico de presenca">
                  {employee.attendances.length === 0 ? (
                    <EmptyLine text="Nenhum ponto registrado." />
                  ) : (
                    employee.attendances.slice(0, 6).map((attendance) => (
                      <div key={attendance.id} className="rounded-lg border border-foreground/10 bg-background/40 p-3">
                        <div className="flex items-center justify-between gap-3">
                          <span className="font-medium">{formatDateBR(attendance.date)}</span>
                          <Badge variant="outline">{attendanceStatusLabels[attendance.status]}</Badge>
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">{attendance.notes || "Sem observacoes"}</p>
                      </div>
                    ))
                  )}
                </HistoryBlock>

                <HistoryBlock title="Alocacoes recentes">
                  {employee.assignments.length === 0 ? (
                    <EmptyLine text="Nenhuma alocacao registrada." />
                  ) : (
                    employee.assignments.slice(0, 5).map((member) => (
                      <div key={member.id} className="rounded-lg border border-foreground/10 bg-background/40 p-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-medium">
                            {member.assignment.activity} - {member.assignment.location}
                          </span>
                          <Badge variant="outline">{assignmentStatusLabels[member.assignment.status]}</Badge>
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">{formatDateBR(member.assignment.date)}</p>
                      </div>
                    ))
                  )}
                </HistoryBlock>

                <HistoryBlock title="Historico salarial">
                  {employee.salaryHistory.length === 0 ? (
                    <EmptyLine text="Nenhuma alteracao salarial registrada." />
                  ) : (
                    employee.salaryHistory.slice(0, 5).map((history) => (
                      <div key={history.id} className="rounded-lg border border-foreground/10 bg-background/40 p-3">
                        <p className="font-medium">
                          {formatCurrencyBRL(history.oldSalary)} para {formatCurrencyBRL(history.newSalary)}
                        </p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {formatDateBR(history.changedAt)}
                          {history.reason ? ` - ${history.reason}` : ""}
                        </p>
                      </div>
                    ))
                  )}
                </HistoryBlock>
              </section>
            </div>
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-medium">{value}</p>
    </div>
  );
}

function HistoryBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-foreground/10 bg-card/70 p-4">
      <h3 className="mb-3 font-medium">{title}</h3>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function EmptyLine({ text }: { text: string }) {
  return <p className="rounded-lg border border-dashed border-foreground/10 p-3 text-sm text-muted-foreground">{text}</p>;
}
