"use client";

import { ArrowDownAZ, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { employeeStatusLabels, type SerializedTeamAssignment } from "@/lib/employee-calculations";
import type { EmployeeStatusValue } from "@/lib/validations";

export type EmployeeFiltersState = {
  search: string;
  status: EmployeeStatusValue | "ALL";
  department: string;
  role: string;
  assignment: string;
  sort: "name" | "salary" | "admissionDate" | "status";
};

export function EmployeeFilters({
  filters,
  departments,
  roles,
  assignments,
  onChange,
}: {
  filters: EmployeeFiltersState;
  departments: string[];
  roles: string[];
  assignments: SerializedTeamAssignment[];
  onChange: (filters: EmployeeFiltersState) => void;
}) {
  return (
    <div className="rounded-xl border border-emerald-500/15 bg-card/75 p-4">
      <div className="grid gap-3 lg:grid-cols-[minmax(18rem,1fr)_repeat(5,minmax(9rem,12rem))]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={filters.search}
            onChange={(event) => onChange({ ...filters, search: event.target.value })}
            placeholder="Buscar por nome, CPF, telefone ou cargo"
            className="h-9 bg-background/70 pl-9"
          />
        </div>

        <Select value={filters.status} onValueChange={(status) => onChange({ ...filters, status: status as EmployeeFiltersState["status"] })}>
          <SelectTrigger className="h-9 w-full bg-background/70">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todos os status</SelectItem>
            {Object.entries(employeeStatusLabels).map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.department} onValueChange={(department) => onChange({ ...filters, department })}>
          <SelectTrigger className="h-9 w-full bg-background/70">
            <SelectValue placeholder="Setor" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todos os setores</SelectItem>
            {departments.map((department) => (
              <SelectItem key={department} value={department}>
                {department}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.role} onValueChange={(role) => onChange({ ...filters, role })}>
          <SelectTrigger className="h-9 w-full bg-background/70">
            <SelectValue placeholder="Cargo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todos os cargos</SelectItem>
            {roles.map((role) => (
              <SelectItem key={role} value={role}>
                {role}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.assignment} onValueChange={(assignment) => onChange({ ...filters, assignment })}>
          <SelectTrigger className="h-9 w-full bg-background/70">
            <SelectValue placeholder="Equipe" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todas as equipes</SelectItem>
            {assignments.map((assignment) => (
              <SelectItem key={assignment.id} value={assignment.id}>
                {assignment.activity} - {assignment.location}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.sort} onValueChange={(sort) => onChange({ ...filters, sort: sort as EmployeeFiltersState["sort"] })}>
          <SelectTrigger className="h-9 w-full bg-background/70">
            <ArrowDownAZ className="h-4 w-4 text-muted-foreground" />
            <SelectValue placeholder="Ordenar" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name">Nome</SelectItem>
            <SelectItem value="salary">Salario</SelectItem>
            <SelectItem value="admissionDate">Admissao</SelectItem>
            <SelectItem value="status">Status</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
