"use client";

import { Plus, RefreshCw, UserCheck, UsersRound } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AttendanceModal } from "@/components/funcionarios/attendance-modal";
import { AttendanceTable } from "@/components/funcionarios/attendance-table";
import { EmployeeCard } from "@/components/funcionarios/employee-card";
import { EmployeeDeleteDialog } from "@/components/funcionarios/employee-delete-dialog";
import { EmployeeDetailsModal } from "@/components/funcionarios/employee-details-modal";
import { EmployeeFilters, type EmployeeFiltersState } from "@/components/funcionarios/employee-filters";
import { EmployeeFormModal } from "@/components/funcionarios/employee-form-modal";
import { EmployeeSummaryCards } from "@/components/funcionarios/employee-summary-cards";
import { EmptyEmployeesState } from "@/components/funcionarios/empty-employees-state";
import { TeamAssignmentModal } from "@/components/funcionarios/team-assignment-modal";
import { TeamAssignmentsList } from "@/components/funcionarios/team-assignments-list";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  buildEmployeeSummary,
  getCurrentAssignment,
  type SerializedEmployee,
  type SerializedEmployeeAttendance,
  type SerializedEmployeeSalaryHistory,
  type SerializedTeamAssignment,
  type SerializedTeamAssignmentMember,
} from "@/lib/employee-calculations";
import { onlyDigits } from "@/lib/formatters";
import type { EmployeeAttendanceValues, EmployeeValues, TeamAssignmentValues } from "@/lib/validations";

type RawAttendance = SerializedEmployeeAttendance & {
  employee?: { fullName: string };
};

type RawAssignmentMember = Partial<SerializedTeamAssignmentMember> & {
  id: string;
  employeeId: string;
  roleInActivity: string | null;
  createdAt: string;
  employee?: { fullName: string; role: string; salary: number };
};

type RawAssignment = Omit<SerializedTeamAssignment, "members"> & {
  members: RawAssignmentMember[];
};

type RawEmployeeAssignment = {
  id: string;
  roleInActivity: string | null;
  createdAt: string;
  assignment: RawAssignment;
};

type RawEmployee = Omit<SerializedEmployee, "attendances" | "assignments" | "salaryHistory"> & {
  attendances?: RawAttendance[];
  assignments?: RawEmployeeAssignment[];
  salaryHistory?: SerializedEmployeeSalaryHistory[];
};

const initialFilters: EmployeeFiltersState = {
  search: "",
  status: "ALL",
  department: "ALL",
  role: "ALL",
  assignment: "ALL",
  sort: "name",
};

function normalizeAttendance(attendance: RawAttendance): SerializedEmployeeAttendance {
  return {
    id: attendance.id,
    employeeId: attendance.employeeId,
    employeeName: attendance.employeeName ?? attendance.employee?.fullName,
    date: new Date(attendance.date).toISOString(),
    status: attendance.status,
    checkIn: attendance.checkIn ? new Date(attendance.checkIn).toISOString() : null,
    checkOut: attendance.checkOut ? new Date(attendance.checkOut).toISOString() : null,
    notes: attendance.notes,
    createdAt: new Date(attendance.createdAt).toISOString(),
  };
}

function normalizeAssignmentMember(member: RawAssignmentMember): SerializedTeamAssignmentMember {
  return {
    id: member.id,
    employeeId: member.employeeId,
    employeeName: member.employeeName ?? member.employee?.fullName ?? "Funcionario",
    employeeRole: member.employeeRole ?? member.employee?.role ?? "Equipe",
    employeeSalary: member.employeeSalary ?? member.employee?.salary ?? 0,
    roleInActivity: member.roleInActivity,
    createdAt: new Date(member.createdAt).toISOString(),
  };
}

function normalizeAssignment(assignment: RawAssignment): SerializedTeamAssignment {
  return {
    id: assignment.id,
    activity: assignment.activity,
    location: assignment.location,
    date: new Date(assignment.date).toISOString(),
    startTime: assignment.startTime ? new Date(assignment.startTime).toISOString() : null,
    endTime: assignment.endTime ? new Date(assignment.endTime).toISOString() : null,
    transport: assignment.transport,
    vehicle: assignment.vehicle,
    driver: assignment.driver,
    status: assignment.status,
    notes: assignment.notes,
    createdAt: new Date(assignment.createdAt).toISOString(),
    updatedAt: new Date(assignment.updatedAt).toISOString(),
    members: assignment.members.map(normalizeAssignmentMember),
  };
}

function normalizeEmployee(employee: RawEmployee): SerializedEmployee {
  return {
    id: employee.id,
    fullName: employee.fullName,
    cpf: employee.cpf,
    phone: employee.phone,
    email: employee.email,
    role: employee.role,
    department: employee.department,
    salary: employee.salary,
    status: employee.status,
    admissionDate: new Date(employee.admissionDate).toISOString(),
    address: employee.address,
    emergencyContact: employee.emergencyContact,
    notes: employee.notes,
    createdAt: new Date(employee.createdAt).toISOString(),
    updatedAt: new Date(employee.updatedAt).toISOString(),
    attendances: (employee.attendances ?? []).map(normalizeAttendance),
    assignments: (employee.assignments ?? []).map((member) => ({
      id: member.id,
      roleInActivity: member.roleInActivity,
      createdAt: new Date(member.createdAt).toISOString(),
      assignment: normalizeAssignment(member.assignment),
    })),
    salaryHistory: (employee.salaryHistory ?? []).map((history) => ({
      ...history,
      changedAt: new Date(history.changedAt).toISOString(),
    })),
  };
}

function getApiError(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string") {
    return payload.error;
  }

  return fallback;
}

function valuesFromEmployee(employee: SerializedEmployee, status = employee.status): EmployeeValues {
  return {
    fullName: employee.fullName,
    cpf: employee.cpf,
    phone: employee.phone,
    email: employee.email ?? "",
    role: employee.role,
    department: employee.department ?? "",
    salary: employee.salary,
    admissionDate: new Date(employee.admissionDate).toISOString().slice(0, 10),
    status,
    address: employee.address ?? "",
    emergencyContact: employee.emergencyContact ?? "",
    notes: employee.notes ?? "",
    salaryChangeReason: "",
  };
}

export function FuncionariosDashboard({
  initialEmployees,
  initialAttendances,
  initialAssignments,
}: {
  initialEmployees: SerializedEmployee[];
  initialAttendances: SerializedEmployeeAttendance[];
  initialAssignments: SerializedTeamAssignment[];
}) {
  const [employees, setEmployees] = useState(() => initialEmployees.map((employee) => normalizeEmployee(employee)));
  const [attendances, setAttendances] = useState(() => initialAttendances.map(normalizeAttendance));
  const [assignments, setAssignments] = useState(() => initialAssignments.map(normalizeAssignment));
  const [filters, setFilters] = useState<EmployeeFiltersState>(initialFilters);
  const [loading, setLoading] = useState(false);
  const [savingEmployee, setSavingEmployee] = useState(false);
  const [savingAttendance, setSavingAttendance] = useState(false);
  const [savingAssignment, setSavingAssignment] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [employeeModalOpen, setEmployeeModalOpen] = useState(false);
  const [attendanceModalOpen, setAttendanceModalOpen] = useState(false);
  const [assignmentModalOpen, setAssignmentModalOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<SerializedEmployee | null>(null);
  const [detailsEmployee, setDetailsEmployee] = useState<SerializedEmployee | null>(null);
  const [employeeToDelete, setEmployeeToDelete] = useState<SerializedEmployee | null>(null);
  const [attendanceEmployee, setAttendanceEmployee] = useState<SerializedEmployee | null>(null);
  const [assignmentEmployee, setAssignmentEmployee] = useState<SerializedEmployee | null>(null);
  const [selectedAssignment, setSelectedAssignment] = useState<SerializedTeamAssignment | null>(null);

  const summary = useMemo(() => buildEmployeeSummary(employees, assignments, attendances), [assignments, attendances, employees]);
  const departments = useMemo(
    () => [...new Set(employees.map((employee) => employee.department).filter((department): department is string => Boolean(department)))].sort(),
    [employees],
  );
  const roles = useMemo(() => [...new Set(employees.map((employee) => employee.role))].sort(), [employees]);

  const filteredEmployees = useMemo(() => {
    const search = filters.search.trim().toLocaleLowerCase("pt-BR");
    const digitSearch = onlyDigits(search);

    return employees
      .filter((employee) => {
        const currentAssignment = getCurrentAssignment(employee);
        const matchesSearch =
          !search ||
          employee.fullName.toLocaleLowerCase("pt-BR").includes(search) ||
          (digitSearch.length > 0 && onlyDigits(employee.cpf).includes(digitSearch)) ||
          (digitSearch.length > 0 && onlyDigits(employee.phone).includes(digitSearch)) ||
          employee.role.toLocaleLowerCase("pt-BR").includes(search);
        const matchesStatus = filters.status === "ALL" || employee.status === filters.status;
        const matchesDepartment = filters.department === "ALL" || employee.department === filters.department;
        const matchesRole = filters.role === "ALL" || employee.role === filters.role;
        const matchesAssignment = filters.assignment === "ALL" || currentAssignment?.id === filters.assignment;

        return matchesSearch && matchesStatus && matchesDepartment && matchesRole && matchesAssignment;
      })
      .sort((a, b) => {
        if (filters.sort === "salary") {
          return b.salary - a.salary;
        }

        if (filters.sort === "admissionDate") {
          return new Date(b.admissionDate).getTime() - new Date(a.admissionDate).getTime();
        }

        if (filters.sort === "status") {
          return a.status.localeCompare(b.status, "pt-BR");
        }

        return a.fullName.localeCompare(b.fullName, "pt-BR");
      });
  }, [employees, filters]);

  async function loadAll() {
    setLoading(true);
    setError(null);

    const [employeesResponse, attendanceResponse, assignmentsResponse] = await Promise.all([
      fetch("/api/funcionarios/employees", { cache: "no-store" }),
      fetch("/api/funcionarios/attendance", { cache: "no-store" }),
      fetch("/api/funcionarios/assignments", { cache: "no-store" }),
    ]);
    const [employeesPayload, attendancePayload, assignmentsPayload] = await Promise.all([
      employeesResponse.json().catch(() => null),
      attendanceResponse.json().catch(() => null),
      assignmentsResponse.json().catch(() => null),
    ]);
    setLoading(false);

    if (!employeesResponse.ok || !attendanceResponse.ok || !assignmentsResponse.ok) {
      const message =
        getApiError(employeesPayload, "") ||
        getApiError(attendancePayload, "") ||
        getApiError(assignmentsPayload, "") ||
        "Nao foi possivel carregar os dados de funcionarios.";
      setError(message);
      toast.error(message);
      return;
    }

    setEmployees((employeesPayload.employees as RawEmployee[]).map(normalizeEmployee));
    setAttendances((attendancePayload.attendances as RawAttendance[]).map(normalizeAttendance));
    setAssignments((assignmentsPayload.assignments as RawAssignment[]).map(normalizeAssignment));
  }

  function openCreateEmployee() {
    setSelectedEmployee(null);
    setEmployeeModalOpen(true);
  }

  function openEditEmployee(employee: SerializedEmployee) {
    setSelectedEmployee(employee);
    setEmployeeModalOpen(true);
  }

  function openAttendance(employee: SerializedEmployee | null) {
    setAttendanceEmployee(employee);
    setAttendanceModalOpen(true);
  }

  function openAssignment(employee: SerializedEmployee | null) {
    setAssignmentEmployee(employee);
    setSelectedAssignment(null);
    setAssignmentModalOpen(true);
  }

  async function saveEmployee(values: EmployeeValues) {
    setSavingEmployee(true);
    const isEdit = Boolean(selectedEmployee);
    const response = await fetch(isEdit ? `/api/funcionarios/employees/${selectedEmployee?.id}` : "/api/funcionarios/employees", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingEmployee(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel salvar o funcionario."));
      return;
    }

    toast.success(isEdit ? "Funcionario atualizado." : "Funcionario criado.");
    setEmployeeModalOpen(false);
    setSelectedEmployee(null);
    await loadAll();
  }

  async function toggleEmployeeStatus(employee: SerializedEmployee) {
    const nextStatus = employee.status === "ATIVO" ? "INATIVO" : "ATIVO";
    const response = await fetch(`/api/funcionarios/employees/${employee.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(valuesFromEmployee(employee, nextStatus)),
    });
    const payload = await response.json().catch(() => null);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel alterar o status."));
      return;
    }

    toast.success(nextStatus === "ATIVO" ? "Funcionario ativado." : "Funcionario desativado.");
    await loadAll();
  }

  async function deleteEmployee() {
    if (!employeeToDelete) {
      return;
    }

    setDeleting(true);
    const response = await fetch(`/api/funcionarios/employees/${employeeToDelete.id}`, { method: "DELETE" });
    const payload = await response.json().catch(() => null);
    setDeleting(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel excluir o funcionario."));
      return;
    }

    toast.success("Funcionario excluido.");
    setEmployeeToDelete(null);
    await loadAll();
  }

  async function saveAttendance(values: EmployeeAttendanceValues) {
    setSavingAttendance(true);
    const response = await fetch("/api/funcionarios/attendance", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingAttendance(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel registrar a presenca."));
      return;
    }

    toast.success("Presenca registrada.");
    setAttendanceModalOpen(false);
    setAttendanceEmployee(null);
    await loadAll();
  }

  async function saveAssignment(values: TeamAssignmentValues) {
    setSavingAssignment(true);
    const isEdit = Boolean(selectedAssignment);
    const response = await fetch(isEdit ? `/api/funcionarios/assignments/${selectedAssignment?.id}` : "/api/funcionarios/assignments", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingAssignment(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel salvar a escala."));
      return;
    }

    toast.success(isEdit ? "Escala atualizada." : "Equipe alocada.");
    setAssignmentModalOpen(false);
    setAssignmentEmployee(null);
    setSelectedAssignment(null);
    await loadAll();
  }

  async function deleteAssignment(assignment: SerializedTeamAssignment) {
    if (!window.confirm(`Excluir a escala ${assignment.activity} - ${assignment.location}?`)) {
      return;
    }

    const response = await fetch(`/api/funcionarios/assignments/${assignment.id}`, { method: "DELETE" });
    const payload = await response.json().catch(() => null);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel excluir a escala."));
      return;
    }

    toast.success("Escala excluida.");
    await loadAll();
  }

  if (loading && employees.length === 0) {
    return <EmployeesSkeleton />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 rounded-xl border border-emerald-500/15 bg-card/70 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium">Operacao de equipe da fazenda</p>
          <p className="text-sm text-muted-foreground">
            Funcionarios, folha, ponto, escala, transporte e custo de mao de obra com dados persistidos.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={openCreateEmployee}>
            <Plus className="h-4 w-4" />
            Novo Funcionario
          </Button>
          <Button variant="outline" onClick={() => openAssignment(null)} disabled={employees.length === 0}>
            <UsersRound className="h-4 w-4" />
            Nova escala
          </Button>
          <Button variant="outline" onClick={() => openAttendance(null)} disabled={employees.length === 0}>
            <UserCheck className="h-4 w-4" />
            Registrar presenca
          </Button>
          <Button variant="outline" onClick={() => openAssignment(null)} disabled={employees.length === 0}>
            <UsersRound className="h-4 w-4" />
            Alocar equipe
          </Button>
          <Button variant="outline" onClick={loadAll} disabled={loading}>
            <RefreshCw className={loading ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
            Atualizar
          </Button>
        </div>
      </div>

      {error ? (
        <Card className="rounded-xl border-red-500/20 bg-red-500/10">
          <CardContent className="p-4 text-sm text-red-200">{error}</CardContent>
        </Card>
      ) : null}

      <EmployeeSummaryCards summary={summary} />

      {employees.length === 0 ? (
        <EmptyEmployeesState onCreate={openCreateEmployee} />
      ) : (
        <Tabs defaultValue="funcionarios" className="space-y-4">
          <TabsList className="bg-card/80">
            <TabsTrigger value="funcionarios">Funcionarios</TabsTrigger>
            <TabsTrigger value="logistica">Logistica de Equipe</TabsTrigger>
            <TabsTrigger value="presenca">Presenca</TabsTrigger>
          </TabsList>

          <TabsContent value="funcionarios" className="space-y-4">
            <EmployeeFilters
              filters={filters}
              departments={departments}
              roles={roles}
              assignments={assignments}
              onChange={setFilters}
            />

            {filteredEmployees.length === 0 ? (
              <Card className="rounded-xl border-dashed border-foreground/10 bg-card/70">
                <CardContent className="p-6 text-sm text-muted-foreground">Nenhum funcionario encontrado com os filtros atuais.</CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {filteredEmployees.map((employee) => (
                  <EmployeeCard
                    key={employee.id}
                    employee={employee}
                    onView={setDetailsEmployee}
                    onEdit={openEditEmployee}
                    onDelete={setEmployeeToDelete}
                    onToggleStatus={toggleEmployeeStatus}
                    onAttendance={openAttendance}
                    onAssign={openAssignment}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="logistica">
            <TeamAssignmentsList
              assignments={assignments}
              onEdit={(assignment) => {
                setSelectedAssignment(assignment);
                setAssignmentEmployee(null);
                setAssignmentModalOpen(true);
              }}
              onDelete={deleteAssignment}
            />
          </TabsContent>

          <TabsContent value="presenca">
            <AttendanceTable attendances={attendances} />
          </TabsContent>
        </Tabs>
      )}

      <EmployeeFormModal
        open={employeeModalOpen}
        employee={selectedEmployee}
        saving={savingEmployee}
        onOpenChange={setEmployeeModalOpen}
        onSubmit={saveEmployee}
      />
      <EmployeeDetailsModal
        employee={detailsEmployee}
        onOpenChange={(open) => {
          if (!open) {
            setDetailsEmployee(null);
          }
        }}
      />
      <EmployeeDeleteDialog
        employee={employeeToDelete}
        deleting={deleting}
        onOpenChange={(open) => {
          if (!open) {
            setEmployeeToDelete(null);
          }
        }}
        onConfirm={deleteEmployee}
      />
      <AttendanceModal
        open={attendanceModalOpen}
        employees={employees}
        employee={attendanceEmployee}
        saving={savingAttendance}
        onOpenChange={setAttendanceModalOpen}
        onSubmit={saveAttendance}
      />
      <TeamAssignmentModal
        open={assignmentModalOpen}
        employees={employees}
        assignment={selectedAssignment}
        preselectedEmployee={assignmentEmployee}
        saving={savingAssignment}
        onOpenChange={setAssignmentModalOpen}
        onSubmit={saveAssignment}
      />
    </div>
  );
}

function EmployeesSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
        {["total", "active", "payroll", "teams", "cost", "absence"].map((item) => (
          <div key={item} className="h-32 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
        ))}
      </div>
      <div className="h-20 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
      <div className="h-96 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
    </div>
  );
}
