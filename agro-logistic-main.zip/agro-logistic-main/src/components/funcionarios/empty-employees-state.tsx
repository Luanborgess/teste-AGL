"use client";

import { Plus, UsersRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function EmptyEmployeesState({ onCreate }: { onCreate: () => void }) {
  return (
    <Card className="rounded-xl border-dashed border-emerald-500/20 bg-card/70">
      <CardContent className="flex flex-col items-center gap-4 p-10 text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-lg border border-emerald-500/25 bg-emerald-500/10 text-emerald-300">
          <UsersRound className="h-6 w-6" />
        </span>
        <div>
          <h2 className="text-lg font-semibold">Nenhum funcionario cadastrado</h2>
          <p className="mt-1 max-w-xl text-sm text-muted-foreground">
            Cadastre a equipe real da fazenda para controlar folha, presenca, escala e custo de mao de obra.
          </p>
        </div>
        <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={onCreate}>
          <Plus className="h-4 w-4" />
          Novo Funcionario
        </Button>
      </CardContent>
    </Card>
  );
}
