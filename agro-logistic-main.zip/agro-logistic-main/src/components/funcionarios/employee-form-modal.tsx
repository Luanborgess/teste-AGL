"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import { employeeStatusLabels, type SerializedEmployee } from "@/lib/employee-calculations";
import { formatCPF, formatPhoneBR } from "@/lib/formatters";
import {
  employeeSchema,
  type EmployeeInput,
  type EmployeeStatusValue,
  type EmployeeValues,
} from "@/lib/validations";

const emptyValues: EmployeeInput = {
  fullName: "",
  cpf: "",
  phone: "",
  email: "",
  role: "",
  department: "",
  salary: 0,
  admissionDate: "",
  status: "ATIVO",
  address: "",
  emergencyContact: "",
  notes: "",
  salaryChangeReason: "",
};

function valuesFromEmployee(employee: SerializedEmployee | null): EmployeeInput {
  if (!employee) {
    return emptyValues;
  }

  return {
    fullName: employee.fullName,
    cpf: formatCPF(employee.cpf),
    phone: formatPhoneBR(employee.phone),
    email: employee.email ?? "",
    role: employee.role,
    department: employee.department ?? "",
    salary: employee.salary,
    admissionDate: new Date(employee.admissionDate).toISOString().slice(0, 10),
    status: employee.status,
    address: employee.address ?? "",
    emergencyContact: employee.emergencyContact ?? "",
    notes: employee.notes ?? "",
    salaryChangeReason: "",
  };
}

export function EmployeeFormModal({
  open,
  employee,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  employee: SerializedEmployee | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: EmployeeValues) => Promise<void>;
}) {
  const form = useForm<EmployeeInput, unknown, EmployeeValues>({
    resolver: zodResolver(employeeSchema),
    mode: "onChange",
    defaultValues: valuesFromEmployee(employee),
  });
  const status = useWatch({ control: form.control, name: "status" });

  useEffect(() => {
    if (open) {
      form.reset(valuesFromEmployee(employee));
    }
  }, [employee, form, open]);

  async function submit(values: EmployeeValues) {
    await onSubmit(values);

    if (!employee) {
      form.reset(emptyValues);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-5xl">
        <DialogHeader>
          <DialogTitle>{employee ? "Editar funcionario" : "Novo funcionario"}</DialogTitle>
          <DialogDescription>
            Cadastre dados reais da equipe. Folha, escala e presenca usam essas informacoes automaticamente.
          </DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Nome completo" error={form.formState.errors.fullName?.message}>
            <TextInput disabled={saving} placeholder="Joao Silva" {...form.register("fullName")} />
          </Field>

          <Field label="CPF" error={form.formState.errors.cpf?.message}>
            <TextInput
              disabled={saving}
              placeholder="123.456.789-09"
              {...form.register("cpf")}
              onChange={(event) => form.setValue("cpf", formatCPF(event.target.value), { shouldValidate: true })}
            />
          </Field>

          <Field label="Telefone" error={form.formState.errors.phone?.message}>
            <TextInput
              disabled={saving}
              placeholder="(31) 99999-9999"
              {...form.register("phone")}
              onChange={(event) => form.setValue("phone", formatPhoneBR(event.target.value), { shouldValidate: true })}
            />
          </Field>

          <Field label="E-mail" error={form.formState.errors.email?.message}>
            <TextInput disabled={saving} type="email" placeholder="joao@fazenda.com" {...form.register("email")} />
          </Field>

          <Field label="Cargo" error={form.formState.errors.role?.message}>
            <TextInput disabled={saving} placeholder="Operador de Maquina" {...form.register("role")} />
          </Field>

          <Field label="Setor" error={form.formState.errors.department?.message}>
            <TextInput disabled={saving} placeholder="Campo" {...form.register("department")} />
          </Field>

          <Field label="Salario" error={form.formState.errors.salary?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" placeholder="3500" {...form.register("salary")} />
          </Field>

          <Field label="Data de admissao" error={form.formState.errors.admissionDate?.message}>
            <TextInput disabled={saving} type="date" {...form.register("admissionDate")} />
          </Field>

          <Field label="Status" error={form.formState.errors.status?.message}>
            <Select
              disabled={saving}
              value={status}
              onValueChange={(value) => form.setValue("status", value as EmployeeStatusValue, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(employeeStatusLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Contato de emergencia" error={form.formState.errors.emergencyContact?.message}>
            <TextInput disabled={saving} placeholder="Nome e telefone" {...form.register("emergencyContact")} />
          </Field>

          <Field label="Endereco" error={form.formState.errors.address?.message} className="md:col-span-2">
            <TextInput disabled={saving} placeholder="Endereco opcional" {...form.register("address")} />
          </Field>

          {employee ? (
            <Field label="Motivo da alteracao salarial" error={form.formState.errors.salaryChangeReason?.message} className="md:col-span-2">
              <TextInput disabled={saving} placeholder="Ajuste, promocao, dissidio ou observacao" {...form.register("salaryChangeReason")} />
            </Field>
          ) : null}

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Observacoes operacionais do funcionario." {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
