"use client";

import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { machineStatusLabels, machineTypeLabels } from "@/lib/machine-calculations";
import type { MachineStatusValue, MachineTypeValue } from "@/lib/validations";

export type MachineSortKey = "name" | "year" | "hourMeter" | "maintenanceCost" | "nextMaintenance";
export type MachineFiltersState = {
  search: string;
  status: MachineStatusValue | "ALL";
  type: MachineTypeValue | "ALL";
  brand: string;
  year: string;
  maintenancePending: "ALL" | "PENDING";
  sort: MachineSortKey;
};

export function MachineFilters({
  filters,
  brands,
  years,
  onChange,
}: {
  filters: MachineFiltersState;
  brands: string[];
  years: number[];
  onChange: (filters: MachineFiltersState) => void;
}) {
  return (
    <div className="rounded-xl border border-foreground/10 bg-card/80 p-4">
      <div className="grid gap-3 lg:grid-cols-[1.5fr_repeat(6,minmax(0,1fr))]">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={filters.search}
            onChange={(event) => onChange({ ...filters, search: event.target.value })}
            placeholder="Buscar por nome, tipo, marca ou modelo"
            className="bg-background/70 pl-9"
          />
        </div>

        <Select value={filters.status} onValueChange={(status) => onChange({ ...filters, status: status as MachineFiltersState["status"] })}>
          <SelectTrigger className="w-full bg-background/70">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todos status</SelectItem>
            {Object.entries(machineStatusLabels).map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.type} onValueChange={(type) => onChange({ ...filters, type: type as MachineFiltersState["type"] })}>
          <SelectTrigger className="w-full bg-background/70">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todos tipos</SelectItem>
            {Object.entries(machineTypeLabels).map(([value, label]) => (
              <SelectItem key={value} value={value}>
                {label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.brand} onValueChange={(brand) => onChange({ ...filters, brand })}>
          <SelectTrigger className="w-full bg-background/70">
            <SelectValue placeholder="Marca" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todas marcas</SelectItem>
            {brands.map((brand) => (
              <SelectItem key={brand} value={brand}>
                {brand}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filters.year} onValueChange={(year) => onChange({ ...filters, year })}>
          <SelectTrigger className="w-full bg-background/70">
            <SelectValue placeholder="Ano" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todos anos</SelectItem>
            {years.map((year) => (
              <SelectItem key={year} value={String(year)}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.maintenancePending}
          onValueChange={(maintenancePending) =>
            onChange({ ...filters, maintenancePending: maintenancePending as MachineFiltersState["maintenancePending"] })
          }
        >
          <SelectTrigger className="w-full bg-background/70">
            <SelectValue placeholder="Revisao" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todas revisoes</SelectItem>
            <SelectItem value="PENDING">Pendentes</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filters.sort} onValueChange={(sort) => onChange({ ...filters, sort: sort as MachineSortKey })}>
          <SelectTrigger className="w-full bg-background/70">
            <SelectValue placeholder="Ordenar" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name">Nome</SelectItem>
            <SelectItem value="year">Ano</SelectItem>
            <SelectItem value="hourMeter">Horimetro</SelectItem>
            <SelectItem value="maintenanceCost">Custo</SelectItem>
            <SelectItem value="nextMaintenance">Proxima manutencao</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
