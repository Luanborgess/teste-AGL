"use client";

import { AlertTriangle, Fuel, Gauge, PenTool, Tractor, Wrench } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { formatCurrencyBRL, formatLiters } from "@/lib/formatters";
import type { buildMachineSummary } from "@/lib/machine-calculations";

type MachineSummary = ReturnType<typeof buildMachineSummary>;

const cards = [
  { key: "totalMachines", label: "Total de Maquinas", icon: Tractor, tone: "text-emerald-300" },
  { key: "operational", label: "Operacionais", icon: Gauge, tone: "text-green-300" },
  { key: "inMaintenance", label: "Manutencao/Reparo", icon: Wrench, tone: "text-amber-300" },
  { key: "maintenanceAlerts", label: "Alertas de Revisao", icon: AlertTriangle, tone: "text-red-300" },
  { key: "maintenanceCost", label: "Custo de Manutencao", icon: PenTool, tone: "text-cyan-300" },
  { key: "averageConsumption", label: "Consumo Medio", icon: Fuel, tone: "text-lime-300" },
] as const;

export function MachineSummaryCards({ summary }: { summary: MachineSummary }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
      {cards.map((card) => {
        const Icon = card.icon;
        const rawValue = summary[card.key];
        const value =
          card.key === "maintenanceCost"
            ? formatCurrencyBRL(rawValue)
            : card.key === "averageConsumption"
              ? `${formatLiters(rawValue)}/h`
              : rawValue.toLocaleString("pt-BR");

        return (
          <Card
            key={card.key}
            className="rounded-xl border-foreground/10 bg-card/80 transition duration-200 hover:-translate-y-0.5 hover:border-emerald-500/25"
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{card.label}</p>
                  <p className="text-2xl font-semibold tracking-tight">{value}</p>
                </div>
                <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-foreground/10 bg-background/60">
                  <Icon className={`h-5 w-5 ${card.tone}`} />
                </span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
