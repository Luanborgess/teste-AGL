"use client";

import { CalendarClock, Fuel, Gauge, Wrench } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import {
  calculateMachineFuelCost,
  calculateMachineMaintenanceCost,
  machineStatusLabels,
  machineTypeLabels,
  maintenanceTypeLabels,
  type SerializedMachine,
} from "@/lib/machine-calculations";
import { formatCurrencyBRL, formatDateBR, formatHours, formatLiters } from "@/lib/formatters";

export function MachineDetailsModal({
  machine,
  onOpenChange,
}: {
  machine: SerializedMachine | null;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={Boolean(machine)} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-4xl">
        {machine ? (
          <>
            <DialogHeader>
              <DialogTitle>{machine.name}</DialogTitle>
              <DialogDescription>
                {machineTypeLabels[machine.type]} - {machine.brand} {machine.model ?? ""} - {machine.year}
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <Detail icon={Gauge} label="Horimetro" value={formatHours(machine.hourMeter)} />
              <Detail icon={Fuel} label="Consumo medio" value={`${formatLiters(machine.fuelConsumption)}/h`} />
              <Detail icon={Wrench} label="Manutencoes" value={formatCurrencyBRL(calculateMachineMaintenanceCost(machine))} />
              <Detail icon={CalendarClock} label="Proxima revisao" value={machine.nextMaintenance ? formatDateBR(machine.nextMaintenance) : "Sem data"} />
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-foreground/10 bg-background/45 p-4">
                <p className="text-xs text-muted-foreground">Status operacional</p>
                <Badge className="mt-2 border border-emerald-500/20 bg-emerald-500/10 text-emerald-300">
                  {machineStatusLabels[machine.status]}
                </Badge>
                <p className="mt-4 text-xs text-muted-foreground">Identificacao</p>
                <p className="mt-1 text-sm">{machine.identifier || "Nao informada"}</p>
              </div>
              <div className="rounded-xl border border-foreground/10 bg-background/45 p-4">
                <p className="text-xs text-muted-foreground">Custos</p>
                <p className="mt-2 text-sm">Operacional: {formatCurrencyBRL(machine.operationalCost)}/h</p>
                <p className="mt-1 text-sm">Combustivel registrado: {formatCurrencyBRL(calculateMachineFuelCost(machine))}</p>
                <p className="mt-1 text-sm">Manutencao registrada: {formatCurrencyBRL(calculateMachineMaintenanceCost(machine))}</p>
              </div>
            </div>

            {machine.notes ? (
              <div className="rounded-xl border border-foreground/10 bg-background/45 p-4">
                <p className="text-xs text-muted-foreground">Observacoes</p>
                <p className="mt-2 text-sm">{machine.notes}</p>
              </div>
            ) : null}

            <Separator />

            <HistoryBlock title="Manutencoes recentes">
              {machine.maintenances.slice(0, 5).map((maintenance) => (
                <li key={maintenance.id} className="rounded-lg border border-foreground/10 bg-background/45 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm font-medium">{maintenanceTypeLabels[maintenance.type]}</p>
                    <span className="text-xs text-muted-foreground">{formatDateBR(maintenance.performedAt)}</span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{maintenance.description || "Sem descricao"}</p>
                  <p className="mt-1 text-sm">{formatCurrencyBRL(maintenance.cost)}</p>
                </li>
              ))}
            </HistoryBlock>

            <HistoryBlock title="Consumos recentes">
              {machine.fuelLogs.slice(0, 5).map((fuelLog) => (
                <li key={fuelLog.id} className="rounded-lg border border-foreground/10 bg-background/45 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm font-medium">{formatLiters(fuelLog.liters)}</p>
                    <span className="text-xs text-muted-foreground">{formatDateBR(fuelLog.date)}</span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">Valor por litro: {formatCurrencyBRL(fuelLog.pricePerLiter)}</p>
                  <p className="mt-1 text-sm">{formatCurrencyBRL(fuelLog.totalCost)}</p>
                </li>
              ))}
            </HistoryBlock>
          </>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

function Detail({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-foreground/10 bg-background/45 p-4">
      <Icon className="h-4 w-4 text-emerald-300" />
      <p className="mt-3 text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-medium">{value}</p>
    </div>
  );
}

function HistoryBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-sm font-semibold">{title}</h3>
      <ul className="mt-3 grid gap-2 md:grid-cols-2">{children}</ul>
    </div>
  );
}
