"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import { machineStatusLabels, maintenanceTypeLabels, type SerializedMachine } from "@/lib/machine-calculations";
import { machineMaintenanceSchema, type MachineMaintenanceInput, type MachineMaintenanceValues } from "@/lib/validations";

function emptyValues(machine: SerializedMachine | null): MachineMaintenanceInput {
  return {
    machineId: machine?.id ?? "",
    type: "PREVENTIVA",
    description: "",
    cost: 0,
    performedAt: new Date().toISOString().slice(0, 10),
    nextReview: "",
    partsChanged: "",
    responsible: "",
    hourMeter: machine?.hourMeter ?? undefined,
    statusAfterMaintenance: machine?.status ?? "OPERACIONAL",
    notes: "",
  };
}

export function MaintenanceFormModal({
  open,
  machines,
  machine,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  machines: SerializedMachine[];
  machine: SerializedMachine | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: MachineMaintenanceValues) => Promise<void>;
}) {
  const form = useForm<MachineMaintenanceInput, unknown, MachineMaintenanceValues>({
    resolver: zodResolver(machineMaintenanceSchema),
    defaultValues: emptyValues(machine),
  });
  const selectedMachine = useWatch({ control: form.control, name: "machineId" });
  const selectedType = useWatch({ control: form.control, name: "type" });
  const selectedStatus = useWatch({ control: form.control, name: "statusAfterMaintenance" });

  useEffect(() => {
    if (open) {
      form.reset(emptyValues(machine));
    }
  }, [form, machine, open]);

  async function submit(values: MachineMaintenanceValues) {
    await onSubmit(values);
    form.reset(emptyValues(null));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>Registrar manutencao</DialogTitle>
          <DialogDescription>O custo entra no historico da maquina e a proxima revisao atualiza os alertas.</DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Maquina" error={form.formState.errors.machineId?.message}>
            <Select
              disabled={saving || Boolean(machine)}
              value={selectedMachine}
              onValueChange={(value) => form.setValue("machineId", value, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione a maquina" />
              </SelectTrigger>
              <SelectContent>
                {machines.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Tipo de manutencao" error={form.formState.errors.type?.message}>
            <Select
              disabled={saving}
              value={selectedType}
              onValueChange={(value) => form.setValue("type", value as MachineMaintenanceValues["type"], { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(maintenanceTypeLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Descricao" error={form.formState.errors.description?.message}>
            <TextInput disabled={saving} placeholder="Revisao geral" {...form.register("description")} />
          </Field>

          <Field label="Custo" error={form.formState.errors.cost?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("cost")} />
          </Field>

          <Field label="Data realizada" error={form.formState.errors.performedAt?.message}>
            <TextInput disabled={saving} type="date" {...form.register("performedAt")} />
          </Field>

          <Field label="Proxima revisao" error={form.formState.errors.nextReview?.message}>
            <TextInput disabled={saving} type="date" {...form.register("nextReview")} />
          </Field>

          <Field label="Pecas trocadas" error={form.formState.errors.partsChanged?.message}>
            <TextInput disabled={saving} placeholder="filtros e oleo" {...form.register("partsChanged")} />
          </Field>

          <Field label="Responsavel" error={form.formState.errors.responsible?.message}>
            <TextInput disabled={saving} placeholder="Joao" {...form.register("responsible")} />
          </Field>

          <Field label="Horimetro" error={form.formState.errors.hourMeter?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("hourMeter")} />
          </Field>

          <Field label="Status apos manutencao" error={form.formState.errors.statusAfterMaintenance?.message}>
            <Select
              disabled={saving}
              value={selectedStatus}
              onValueChange={(value) =>
                form.setValue("statusAfterMaintenance", value as MachineMaintenanceValues["statusAfterMaintenance"], {
                  shouldValidate: true,
                })
              }
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o status" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(machineStatusLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
