"use client";

import { ChevronLeft, ChevronRight, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  maintenanceTypeLabels,
  type SerializedMachine,
  type SerializedMachineMaintenance,
} from "@/lib/machine-calculations";
import { formatCurrencyBRL, formatDateBR, formatHours } from "@/lib/formatters";

const pageSize = 8;

export function MaintenanceHistoryTable({
  maintenances,
  machines,
}: {
  maintenances: SerializedMachineMaintenance[];
  machines: SerializedMachine[];
}) {
  const [search, setSearch] = useState("");
  const [machineId, setMachineId] = useState("ALL");
  const [type, setType] = useState("ALL");
  const [period, setPeriod] = useState("ALL");
  const [sort, setSort] = useState<"date" | "cost">("date");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    const normalizedSearch = search.trim().toLocaleLowerCase("pt-BR");
    const now = new Date();
    const periodStart = new Date(now);

    if (period === "30") {
      periodStart.setDate(now.getDate() - 30);
    } else if (period === "90") {
      periodStart.setDate(now.getDate() - 90);
    } else if (period === "365") {
      periodStart.setDate(now.getDate() - 365);
    }

    return maintenances
      .filter((maintenance) => {
        const matchesSearch =
          !normalizedSearch ||
          maintenance.machineName.toLocaleLowerCase("pt-BR").includes(normalizedSearch) ||
          (maintenance.description ?? "").toLocaleLowerCase("pt-BR").includes(normalizedSearch) ||
          (maintenance.responsible ?? "").toLocaleLowerCase("pt-BR").includes(normalizedSearch);
        const matchesMachine = machineId === "ALL" || maintenance.machineId === machineId;
        const matchesType = type === "ALL" || maintenance.type === type;
        const matchesPeriod = period === "ALL" || new Date(maintenance.performedAt) >= periodStart;

        return matchesSearch && matchesMachine && matchesType && matchesPeriod;
      })
      .sort((a, b) => {
        if (sort === "cost") {
          return b.cost - a.cost;
        }

        return new Date(b.performedAt).getTime() - new Date(a.performedAt).getTime();
      });
  }, [machineId, maintenances, period, search, sort, type]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardContent className="space-y-4 p-4">
        <div className="grid gap-3 lg:grid-cols-[1.4fr_repeat(4,minmax(0,1fr))]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} className="bg-background/70 pl-9" placeholder="Buscar no historico" />
          </div>
          <Select value={machineId} onValueChange={(value) => { setMachineId(value); setPage(1); }}>
            <SelectTrigger className="w-full bg-background/70"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todas maquinas</SelectItem>
              {machines.map((machine) => <SelectItem key={machine.id} value={machine.id}>{machine.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={type} onValueChange={(value) => { setType(value); setPage(1); }}>
            <SelectTrigger className="w-full bg-background/70"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todos tipos</SelectItem>
              {Object.entries(maintenanceTypeLabels).map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={period} onValueChange={(value) => { setPeriod(value); setPage(1); }}>
            <SelectTrigger className="w-full bg-background/70"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todo periodo</SelectItem>
              <SelectItem value="30">Ultimos 30 dias</SelectItem>
              <SelectItem value="90">Ultimos 90 dias</SelectItem>
              <SelectItem value="365">Ultimos 12 meses</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={(value) => setSort(value as "date" | "cost")}>
            <SelectTrigger className="w-full bg-background/70"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Mais recentes</SelectItem>
              <SelectItem value="cost">Maior custo</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {paginated.length === 0 ? (
          <div className="flex min-h-40 items-center justify-center rounded-xl border border-dashed border-foreground/10 text-sm text-muted-foreground">
            Nenhuma manutencao encontrada.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-foreground/10">
                <TableHead>Maquina</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Custo</TableHead>
                <TableHead>Pecas</TableHead>
                <TableHead>Responsavel</TableHead>
                <TableHead>Horimetro</TableHead>
                <TableHead>Proxima revisao</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginated.map((maintenance) => (
                <TableRow key={maintenance.id} className="border-foreground/10">
                  <TableCell>{maintenance.machineName}</TableCell>
                  <TableCell>{maintenanceTypeLabels[maintenance.type]}</TableCell>
                  <TableCell>{formatDateBR(maintenance.performedAt)}</TableCell>
                  <TableCell>{formatCurrencyBRL(maintenance.cost)}</TableCell>
                  <TableCell>{maintenance.partsChanged || "-"}</TableCell>
                  <TableCell>{maintenance.responsible || "-"}</TableCell>
                  <TableCell>{maintenance.hourMeter != null ? formatHours(maintenance.hourMeter) : "-"}</TableCell>
                  <TableCell>{maintenance.nextReview ? formatDateBR(maintenance.nextReview) : "-"}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}

        <div className="flex flex-col gap-2 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <span>{filtered.length} registro(s)</span>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" disabled={currentPage <= 1} onClick={() => setPage((value) => Math.max(1, value - 1))}>
              <ChevronLeft className="h-4 w-4" />
              Anterior
            </Button>
            <span>Pagina {currentPage} de {totalPages}</span>
            <Button size="sm" variant="outline" disabled={currentPage >= totalPages} onClick={() => setPage((value) => Math.min(totalPages, value + 1))}>
              Proxima
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
