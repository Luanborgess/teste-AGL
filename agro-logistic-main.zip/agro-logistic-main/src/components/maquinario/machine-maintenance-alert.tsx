"use client";

import { AlertTriangle, CalendarClock, Wrench } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { formatDateBR } from "@/lib/formatters";
import { machineTypeLabels, type MachineMaintenanceAlert } from "@/lib/machine-calculations";
import { cn } from "@/lib/utils";

export function MachineMaintenanceAlertBanner({
  alerts,
  onRegisterMaintenance,
}: {
  alerts: MachineMaintenanceAlert[];
  onRegisterMaintenance: () => void;
}) {
  const overdue = alerts.filter((alert) => alert.status === "VENCIDA");
  const upcoming = alerts.filter((alert) => alert.status === "PROXIMA");
  const nextAlert = alerts[0];

  if (alerts.length === 0) {
    return (
      <Card className="rounded-xl border-emerald-500/15 bg-emerald-500/5">
        <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-emerald-400/20 bg-emerald-500/10 text-emerald-300">
              <Wrench className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-medium">Nenhuma revisao pendente</p>
              <p className="text-sm text-muted-foreground">
                Maquinas sem data, ou com revisao prevista para alem dos proximos 15 dias.
              </p>
            </div>
          </div>
          <Button variant="outline" onClick={onRegisterMaintenance}>
            <Wrench className="h-4 w-4" />
            Registrar manutencao
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="rounded-xl border-amber-500/20 bg-amber-500/10 shadow-lg shadow-amber-950/10">
      <CardContent className="space-y-4 p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-amber-400/25 bg-amber-500/15 text-amber-200">
              <AlertTriangle className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold">
                {alerts.length} {alerts.length === 1 ? "manutencao pendente" : "manutencoes pendentes"}
              </p>
              <p className="text-sm text-muted-foreground">
                {overdue.length} vencida(s), {upcoming.length} proxima(s). Proxima data:{" "}
                {nextAlert?.machine.nextMaintenance ? formatDateBR(nextAlert.machine.nextMaintenance) : "sem data"}.
              </p>
            </div>
          </div>
          <Button className="bg-amber-400 text-amber-950 hover:bg-amber-300" onClick={onRegisterMaintenance}>
            <Wrench className="h-4 w-4" />
            Registrar manutencao
          </Button>
        </div>

        <div className="grid gap-2 lg:grid-cols-2">
          {alerts.slice(0, 4).map((alert) => (
            <div
              key={alert.machine.id}
              className="flex flex-col gap-2 rounded-lg border border-foreground/10 bg-background/45 p-3 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <p className="text-sm font-medium">{alert.machine.name}</p>
                <p className="text-xs text-muted-foreground">
                  {machineTypeLabels[alert.machine.type]} - {alert.machine.brand} {alert.machine.model ?? ""}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <CalendarClock className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs">{formatDateBR(alert.machine.nextMaintenance as string)}</span>
                <Badge
                  className={cn(
                    "border",
                    alert.status === "VENCIDA"
                      ? "border-red-500/25 bg-red-500/10 text-red-300"
                      : "border-amber-500/25 bg-amber-500/10 text-amber-300",
                  )}
                >
                  {alert.status === "VENCIDA" ? "Vencida" : "Proxima"}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
