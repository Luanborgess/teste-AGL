"use client";

import {
  BadgeCheck,
  Combine,
  Eye,
  Fuel,
  Gauge,
  Pencil,
  RefreshCw,
  Sprout,
  Trash2,
  Truck,
  Wrench,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  calculateMachineCostPerHour,
  calculateMachineMaintenanceCost,
  machineStatusLabels,
  machineTypeLabels,
  type SerializedMachine,
} from "@/lib/machine-calculations";
import { formatCurrencyBRL, formatDateBR, formatHours, formatLiters } from "@/lib/formatters";
import { cn } from "@/lib/utils";

const statusClass = {
  OPERACIONAL: "border-emerald-500/25 bg-emerald-500/10 text-emerald-300",
  MANUTENCAO: "border-amber-500/25 bg-amber-500/10 text-amber-300",
  EM_REPARO: "border-red-500/25 bg-red-500/10 text-red-300",
  PARADA: "border-zinc-500/25 bg-zinc-500/10 text-zinc-300",
  VENDIDA: "border-slate-500/25 bg-slate-500/10 text-slate-400",
};

const typeIcons = {
  TRATOR: Sprout,
  COLHEITADEIRA: Combine,
  PULVERIZADOR: Sprout,
  PLANTADEIRA: Sprout,
  CAMINHAO: Truck,
  CARRETA: Truck,
  PA_CARREGADEIRA: TractorIcon,
  IMPLEMENTO: Wrench,
  IRRIGACAO: RefreshCw,
  VEICULO_APOIO: Truck,
  OUTRO: BadgeCheck,
};

function TractorIcon(props: React.ComponentProps<typeof Sprout>) {
  return <Sprout {...props} />;
}

export function MachineCard({
  machine,
  onView,
  onEdit,
  onDelete,
  onMaintenance,
  onFuel,
  onHourMeter,
  onStatus,
}: {
  machine: SerializedMachine;
  onView: (machine: SerializedMachine) => void;
  onEdit: (machine: SerializedMachine) => void;
  onDelete: (machine: SerializedMachine) => void;
  onMaintenance: (machine: SerializedMachine) => void;
  onFuel: (machine: SerializedMachine) => void;
  onHourMeter: (machine: SerializedMachine) => void;
  onStatus: (machine: SerializedMachine) => void;
}) {
  const Icon = typeIcons[machine.type];
  const maintenanceCost = calculateMachineMaintenanceCost(machine);
  const costPerHour = calculateMachineCostPerHour(machine);

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80 transition duration-200 hover:-translate-y-0.5 hover:border-emerald-500/25 hover:shadow-lg hover:shadow-emerald-950/10">
      <CardContent className="p-4">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
          <div className="flex gap-3">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-emerald-400/20 bg-emerald-500/10 text-emerald-300">
              <Icon className="h-6 w-6" />
            </span>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="truncate text-base font-semibold tracking-tight">{machine.name}</h3>
                <Badge className={cn("border", statusClass[machine.status])}>{machineStatusLabels[machine.status]}</Badge>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                {machineTypeLabels[machine.type]} - {machine.brand} {machine.model ?? ""} - {machine.year}
              </p>
              {machine.identifier ? <p className="mt-1 text-xs text-muted-foreground">ID: {machine.identifier}</p> : null}
            </div>
          </div>

          <div className="flex flex-wrap gap-2 xl:justify-end">
            <Button size="icon-sm" variant="outline" title="Visualizar detalhes" onClick={() => onView(machine)}>
              <Eye className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Editar" onClick={() => onEdit(machine)}>
              <Pencil className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Alterar status" onClick={() => onStatus(machine)}>
              <BadgeCheck className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Registrar manutencao" onClick={() => onMaintenance(machine)}>
              <Wrench className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Registrar consumo" onClick={() => onFuel(machine)}>
              <Fuel className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="outline" title="Atualizar horimetro" onClick={() => onHourMeter(machine)}>
              <Gauge className="h-4 w-4" />
            </Button>
            <Button size="icon-sm" variant="destructive" title="Excluir" onClick={() => onDelete(machine)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="mt-4 grid gap-3 border-t border-foreground/10 pt-4 sm:grid-cols-2 xl:grid-cols-6">
          <Metric label="Horimetro" value={formatHours(machine.hourMeter)} />
          <Metric label="Consumo medio" value={`${formatLiters(machine.fuelConsumption)}/h`} />
          <Metric label="Custo operacional" value={`${formatCurrencyBRL(machine.operationalCost)}/h`} />
          <Metric label="Proxima manutencao" value={machine.nextMaintenance ? formatDateBR(machine.nextMaintenance) : "Sem data"} />
          <Metric label="Custo manutencao" value={formatCurrencyBRL(maintenanceCost)} />
          <Metric label="Custo real por hora" value={costPerHour > 0 ? `${formatCurrencyBRL(costPerHour)}/h` : "Sem dados"} />
        </div>
      </CardContent>
    </Card>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-background/45 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-sm font-medium">{value}</p>
    </div>
  );
}
