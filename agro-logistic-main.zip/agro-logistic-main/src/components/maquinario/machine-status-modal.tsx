"use client";

import { Loader2, Save } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { machineStatusLabels, type SerializedMachine } from "@/lib/machine-calculations";
import type { MachineStatusValue } from "@/lib/validations";

export function MachineStatusModal({
  machine,
  saving,
  onOpenChange,
  onSubmit,
}: {
  machine: SerializedMachine | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (status: MachineStatusValue) => Promise<void>;
}) {
  return (
    <Dialog open={Boolean(machine)} onOpenChange={onOpenChange}>
      {machine ? (
        <MachineStatusModalContent
          key={machine.id}
          machine={machine}
          saving={saving}
          onOpenChange={onOpenChange}
          onSubmit={onSubmit}
        />
      ) : null}
    </Dialog>
  );
}

function MachineStatusModalContent({
  machine,
  saving,
  onOpenChange,
  onSubmit,
}: {
  machine: SerializedMachine;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (status: MachineStatusValue) => Promise<void>;
}) {
  const [status, setStatus] = useState<MachineStatusValue>(machine.status);

  return (
    <DialogContent className="border-emerald-500/15 bg-popover/95 sm:max-w-md">
      <DialogHeader>
        <DialogTitle>Alterar status</DialogTitle>
        <DialogDescription>Atualize o status operacional de {machine.name}.</DialogDescription>
      </DialogHeader>

      <Select disabled={saving} value={status} onValueChange={(value) => setStatus(value as MachineStatusValue)}>
        <SelectTrigger className="w-full bg-background/70">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {Object.entries(machineStatusLabels).map(([value, label]) => (
            <SelectItem key={value} value={value}>
              {label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <DialogFooter>
        <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
          Cancelar
        </Button>
        <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={() => onSubmit(status)} disabled={saving}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {saving ? "Salvando..." : "Salvar"}
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}
