"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import type { SerializedMachine } from "@/lib/machine-calculations";
import { formatCurrencyBRL } from "@/lib/formatters";
import { machineFuelLogSchema, type MachineFuelLogInput, type MachineFuelLogValues } from "@/lib/validations";

function emptyValues(machine: SerializedMachine | null): MachineFuelLogInput {
  return {
    machineId: machine?.id ?? "",
    date: new Date().toISOString().slice(0, 10),
    liters: 0,
    pricePerLiter: 0,
    hourMeter: machine?.hourMeter ?? undefined,
    responsible: "",
    notes: "",
  };
}

export function FuelLogModal({
  open,
  machines,
  machine,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  machines: SerializedMachine[];
  machine: SerializedMachine | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: MachineFuelLogValues) => Promise<void>;
}) {
  const form = useForm<MachineFuelLogInput, unknown, MachineFuelLogValues>({
    resolver: zodResolver(machineFuelLogSchema),
    defaultValues: emptyValues(machine),
  });
  const selectedMachine = useWatch({ control: form.control, name: "machineId" });
  const liters = Number(useWatch({ control: form.control, name: "liters" }) ?? 0);
  const pricePerLiter = Number(useWatch({ control: form.control, name: "pricePerLiter" }) ?? 0);
  const totalCost = liters * pricePerLiter;

  useEffect(() => {
    if (open) {
      form.reset(emptyValues(machine));
    }
  }, [form, machine, open]);

  async function submit(values: MachineFuelLogValues) {
    await onSubmit(values);
    form.reset(emptyValues(null));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Registrar consumo</DialogTitle>
          <DialogDescription>O custo total e calculado por litros multiplicado pelo valor por litro.</DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Maquina" error={form.formState.errors.machineId?.message} className="md:col-span-2">
            <Select
              disabled={saving || Boolean(machine)}
              value={selectedMachine}
              onValueChange={(value) => form.setValue("machineId", value, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione a maquina" />
              </SelectTrigger>
              <SelectContent>
                {machines.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Data" error={form.formState.errors.date?.message}>
            <TextInput disabled={saving} type="date" {...form.register("date")} />
          </Field>

          <Field label="Litros" error={form.formState.errors.liters?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("liters")} />
          </Field>

          <Field label="Valor por litro" error={form.formState.errors.pricePerLiter?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("pricePerLiter")} />
          </Field>

          <Field label="Horimetro" error={form.formState.errors.hourMeter?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("hourMeter")} />
          </Field>

          <div className="rounded-lg border border-emerald-500/15 bg-emerald-500/10 p-3">
            <p className="text-xs text-muted-foreground">Custo total esperado</p>
            <p className="mt-1 text-lg font-semibold text-emerald-200">{formatCurrencyBRL(totalCost)}</p>
          </div>

          <Field label="Responsavel" error={form.formState.errors.responsible?.message}>
            <TextInput disabled={saving} {...form.register("responsible")} />
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
