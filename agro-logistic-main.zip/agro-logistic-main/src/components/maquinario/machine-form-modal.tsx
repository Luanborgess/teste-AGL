"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import { machineStatusLabels, machineTypeLabels, type SerializedMachine } from "@/lib/machine-calculations";
import { machineSchema, type MachineInput, type MachineValues } from "@/lib/validations";

const emptyValues: MachineInput = {
  name: "",
  type: "TRATOR",
  brand: "",
  model: "",
  year: new Date().getFullYear(),
  identifier: "",
  hourMeter: 0,
  fuelConsumption: 0,
  operationalCost: 0,
  status: "OPERACIONAL",
  nextMaintenance: "",
  notes: "",
};

function valuesFromMachine(machine: SerializedMachine | null): MachineInput {
  if (!machine) {
    return emptyValues;
  }

  return {
    name: machine.name,
    type: machine.type,
    brand: machine.brand,
    model: machine.model ?? "",
    year: machine.year,
    identifier: machine.identifier ?? "",
    hourMeter: machine.hourMeter,
    fuelConsumption: machine.fuelConsumption,
    operationalCost: machine.operationalCost,
    status: machine.status,
    nextMaintenance: machine.nextMaintenance ? new Date(machine.nextMaintenance).toISOString().slice(0, 10) : "",
    notes: machine.notes ?? "",
  };
}

export function MachineFormModal({
  open,
  machine,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  machine: SerializedMachine | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: MachineValues) => Promise<void>;
}) {
  const form = useForm<MachineInput, unknown, MachineValues>({
    resolver: zodResolver(machineSchema),
    defaultValues: valuesFromMachine(machine),
  });
  const selectedType = useWatch({ control: form.control, name: "type" });
  const selectedStatus = useWatch({ control: form.control, name: "status" });

  useEffect(() => {
    if (open) {
      form.reset(valuesFromMachine(machine));
    }
  }, [form, machine, open]);

  async function submit(values: MachineValues) {
    await onSubmit(values);

    if (!machine) {
      form.reset(emptyValues);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>{machine ? "Editar maquina" : "Nova maquina"}</DialogTitle>
          <DialogDescription>Cadastre os dados operacionais reais do equipamento.</DialogDescription>
        </DialogHeader>

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Nome da maquina" error={form.formState.errors.name?.message}>
            <TextInput disabled={saving} placeholder="Trator John Deere 6110J" {...form.register("name")} />
          </Field>

          <Field label="Tipo" error={form.formState.errors.type?.message}>
            <Select
              disabled={saving}
              value={selectedType}
              onValueChange={(value) => form.setValue("type", value as MachineValues["type"], { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(machineTypeLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Marca" error={form.formState.errors.brand?.message}>
            <TextInput disabled={saving} placeholder="John Deere" {...form.register("brand")} />
          </Field>

          <Field label="Modelo" error={form.formState.errors.model?.message}>
            <TextInput disabled={saving} placeholder="6110J" {...form.register("model")} />
          </Field>

          <Field label="Ano" error={form.formState.errors.year?.message}>
            <TextInput disabled={saving} type="number" min="1900" step="1" {...form.register("year")} />
          </Field>

          <Field label="Placa ou identificacao" error={form.formState.errors.identifier?.message}>
            <TextInput disabled={saving} placeholder="TR-001" {...form.register("identifier")} />
          </Field>

          <Field label="Horimetro atual" error={form.formState.errors.hourMeter?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("hourMeter")} />
          </Field>

          <Field label="Consumo medio por hora" error={form.formState.errors.fuelConsumption?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("fuelConsumption")} />
          </Field>

          <Field label="Custo operacional por hora" error={form.formState.errors.operationalCost?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("operationalCost")} />
          </Field>

          <Field label="Status" error={form.formState.errors.status?.message}>
            <Select
              disabled={saving}
              value={selectedStatus}
              onValueChange={(value) => form.setValue("status", value as MachineValues["status"], { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione o status" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(machineStatusLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Proxima manutencao" error={form.formState.errors.nextMaintenance?.message}>
            <TextInput disabled={saving} type="date" {...form.register("nextMaintenance")} />
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} placeholder="Historico, operacao, talhao, restricoes ou observacoes." {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
