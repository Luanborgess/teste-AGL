"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { AlertTriangle, Loader2, Save } from "lucide-react";
import { useEffect } from "react";
import { useForm, useWatch } from "react-hook-form";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Field, TextAreaInput, TextInput } from "@/components/forms/form-fields";
import type { SerializedMachine } from "@/lib/machine-calculations";
import { formatHours } from "@/lib/formatters";
import { machineHourMeterSchema, type MachineHourMeterInput, type MachineHourMeterValues } from "@/lib/validations";

function emptyValues(machine: SerializedMachine | null): MachineHourMeterInput {
  return {
    machineId: machine?.id ?? "",
    newValue: machine?.hourMeter ?? 0,
    date: new Date().toISOString().slice(0, 10),
    notes: "",
  };
}

export function HourMeterModal({
  open,
  machines,
  machine,
  saving,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  machines: SerializedMachine[];
  machine: SerializedMachine | null;
  saving: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: MachineHourMeterValues) => Promise<void>;
}) {
  const form = useForm<MachineHourMeterInput, unknown, MachineHourMeterValues>({
    resolver: zodResolver(machineHourMeterSchema),
    defaultValues: emptyValues(machine),
  });
  const selectedMachineId = useWatch({ control: form.control, name: "machineId" });
  const newValue = Number(useWatch({ control: form.control, name: "newValue" }) ?? 0);
  const currentMachine = machines.find((item) => item.id === selectedMachineId) ?? machine;
  const invalidLowerValue = Boolean(currentMachine && newValue < currentMachine.hourMeter);

  useEffect(() => {
    if (open) {
      form.reset(emptyValues(machine));
    }
  }, [form, machine, open]);

  async function submit(values: MachineHourMeterValues) {
    if (invalidLowerValue) {
      form.setError("newValue", { message: "O novo horimetro nao pode ser menor que o atual" });
      return;
    }

    await onSubmit(values);
    form.reset(emptyValues(null));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100vh-2rem)] overflow-y-auto border-emerald-500/15 bg-popover/95 sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Atualizar horimetro</DialogTitle>
          <DialogDescription>O valor novo precisa ser maior ou igual ao horimetro atual da maquina.</DialogDescription>
        </DialogHeader>

        {currentMachine ? (
          <Alert className="rounded-xl border-emerald-500/20 bg-emerald-500/10">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Horimetro atual</AlertTitle>
            <AlertDescription>{currentMachine.name}: {formatHours(currentMachine.hourMeter)}</AlertDescription>
          </Alert>
        ) : null}

        <form className="grid gap-4 md:grid-cols-2" onSubmit={form.handleSubmit(submit)}>
          <Field label="Maquina" error={form.formState.errors.machineId?.message} className="md:col-span-2">
            <Select
              disabled={saving || Boolean(machine)}
              value={selectedMachineId}
              onValueChange={(value) => form.setValue("machineId", value, { shouldValidate: true })}
            >
              <SelectTrigger className="w-full bg-background/70">
                <SelectValue placeholder="Selecione a maquina" />
              </SelectTrigger>
              <SelectContent>
                {machines.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>

          <Field label="Novo horimetro" error={form.formState.errors.newValue?.message}>
            <TextInput disabled={saving} type="number" min="0" step="0.01" {...form.register("newValue")} />
          </Field>

          <Field label="Data" error={form.formState.errors.date?.message}>
            <TextInput disabled={saving} type="date" {...form.register("date")} />
          </Field>

          <Field label="Observacoes" error={form.formState.errors.notes?.message} className="md:col-span-2">
            <TextAreaInput disabled={saving} {...form.register("notes")} />
          </Field>

          <DialogFooter className="md:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" disabled={saving || invalidLowerValue}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
