"use client";

import { Plus, Tractor } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export function EmptyMachinesState({ onCreate }: { onCreate: () => void }) {
  return (
    <Card className="rounded-xl border-dashed border-emerald-500/25 bg-card/70">
      <CardContent className="flex min-h-72 flex-col items-center justify-center p-6 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-xl border border-emerald-400/25 bg-emerald-500/10 text-emerald-300">
          <Tractor className="h-7 w-7" />
        </span>
        <h2 className="mt-4 text-lg font-semibold">Nenhuma maquina cadastrada</h2>
        <p className="mt-2 max-w-md text-sm text-muted-foreground">
          Cadastre a primeira maquina para controlar horimetro, revisoes, consumo e custos reais da frota.
        </p>
        <Button className="mt-4 bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={onCreate}>
          <Plus className="h-4 w-4" />
          Nova Maquina
        </Button>
      </CardContent>
    </Card>
  );
}
