"use client";

import { Fuel, Gauge, Plus, RefreshCw, Wrench } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmptyMachinesState } from "@/components/maquinario/empty-machines-state";
import { FuelLogModal } from "@/components/maquinario/fuel-log-modal";
import { HourMeterModal } from "@/components/maquinario/hour-meter-modal";
import { MachineCard } from "@/components/maquinario/machine-card";
import { MachineDeleteDialog } from "@/components/maquinario/machine-delete-dialog";
import { MachineDetailsModal } from "@/components/maquinario/machine-details-modal";
import { MachineFilters, type MachineFiltersState } from "@/components/maquinario/machine-filters";
import { MachineFormModal } from "@/components/maquinario/machine-form-modal";
import { MachineMaintenanceAlertBanner } from "@/components/maquinario/machine-maintenance-alert";
import { MachineStatusModal } from "@/components/maquinario/machine-status-modal";
import { MachineSummaryCards } from "@/components/maquinario/machine-summary-cards";
import { MaintenanceFormModal } from "@/components/maquinario/maintenance-form-modal";
import { MaintenanceHistoryTable } from "@/components/maquinario/maintenance-history-table";
import {
  buildMachineMaintenanceAlerts,
  buildMachineSummary,
  calculateMachineMaintenanceCost,
  machineTypeLabels,
  type SerializedMachine,
  type SerializedMachineFuelLog,
  type SerializedMachineMaintenance,
} from "@/lib/machine-calculations";
import type {
  MachineFuelLogValues,
  MachineHourMeterValues,
  MachineMaintenanceValues,
  MachineStatusValue,
  MachineValues,
} from "@/lib/validations";

type MachinePayload = {
  machines: SerializedMachine[];
};

type MaintenancePayload = {
  maintenances: SerializedMachineMaintenance[];
};

type FuelLogPayload = {
  fuelLogs: SerializedMachineFuelLog[];
};

function getApiError(payload: unknown, fallback: string) {
  if (payload && typeof payload === "object" && "error" in payload && typeof payload.error === "string") {
    return payload.error;
  }

  return fallback;
}

function normalizeMachine(machine: SerializedMachine): SerializedMachine {
  return {
    ...machine,
    nextMaintenance: machine.nextMaintenance ? new Date(machine.nextMaintenance).toISOString() : null,
    createdAt: new Date(machine.createdAt).toISOString(),
    updatedAt: new Date(machine.updatedAt).toISOString(),
    maintenances: machine.maintenances.map((maintenance) => ({
      ...maintenance,
      performedAt: new Date(maintenance.performedAt).toISOString(),
      nextReview: maintenance.nextReview ? new Date(maintenance.nextReview).toISOString() : null,
      createdAt: new Date(maintenance.createdAt).toISOString(),
    })),
    fuelLogs: machine.fuelLogs.map((fuelLog) => ({
      ...fuelLog,
      date: new Date(fuelLog.date).toISOString(),
      createdAt: new Date(fuelLog.createdAt).toISOString(),
    })),
    hourMeterLogs: machine.hourMeterLogs.map((log) => ({
      ...log,
      date: new Date(log.date).toISOString(),
      createdAt: new Date(log.createdAt).toISOString(),
    })),
  };
}

export function MaquinarioDashboard({
  initialMachines,
  initialMaintenances,
  initialFuelLogs,
}: {
  initialMachines: SerializedMachine[];
  initialMaintenances: SerializedMachineMaintenance[];
  initialFuelLogs: SerializedMachineFuelLog[];
}) {
  const [machines, setMachines] = useState(() => initialMachines.map(normalizeMachine));
  const [maintenances, setMaintenances] = useState(initialMaintenances);
  const [fuelLogs, setFuelLogs] = useState(initialFuelLogs);
  const [filters, setFilters] = useState<MachineFiltersState>({
    search: "",
    status: "ALL",
    type: "ALL",
    brand: "ALL",
    year: "ALL",
    maintenancePending: "ALL",
    sort: "name",
  });
  const [loading, setLoading] = useState(false);
  const [savingMachine, setSavingMachine] = useState(false);
  const [savingMaintenance, setSavingMaintenance] = useState(false);
  const [savingFuelLog, setSavingFuelLog] = useState(false);
  const [savingHourMeter, setSavingHourMeter] = useState(false);
  const [savingStatus, setSavingStatus] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [machineModalOpen, setMachineModalOpen] = useState(false);
  const [maintenanceModalOpen, setMaintenanceModalOpen] = useState(false);
  const [fuelModalOpen, setFuelModalOpen] = useState(false);
  const [hourMeterModalOpen, setHourMeterModalOpen] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState<SerializedMachine | null>(null);
  const [detailsMachine, setDetailsMachine] = useState<SerializedMachine | null>(null);
  const [machineToDelete, setMachineToDelete] = useState<SerializedMachine | null>(null);
  const [statusMachine, setStatusMachine] = useState<SerializedMachine | null>(null);

  const summary = useMemo(() => buildMachineSummary(machines), [machines]);
  const alerts = useMemo(() => buildMachineMaintenanceAlerts(machines), [machines]);
  const brands = useMemo(() => Array.from(new Set(machines.map((machine) => machine.brand))).sort(), [machines]);
  const years = useMemo(() => Array.from(new Set(machines.map((machine) => machine.year))).sort((a, b) => b - a), [machines]);

  const filteredMachines = useMemo(() => {
    const search = filters.search.trim().toLocaleLowerCase("pt-BR");
    const pendingIds = new Set(alerts.map((alert) => alert.machine.id));

    return machines
      .filter((machine) => {
        const matchesSearch =
          !search ||
          machine.name.toLocaleLowerCase("pt-BR").includes(search) ||
          machine.brand.toLocaleLowerCase("pt-BR").includes(search) ||
          (machine.model ?? "").toLocaleLowerCase("pt-BR").includes(search) ||
          machineTypeLabels[machine.type].toLocaleLowerCase("pt-BR").includes(search);
        const matchesStatus = filters.status === "ALL" || machine.status === filters.status;
        const matchesType = filters.type === "ALL" || machine.type === filters.type;
        const matchesBrand = filters.brand === "ALL" || machine.brand === filters.brand;
        const matchesYear = filters.year === "ALL" || machine.year === Number(filters.year);
        const matchesMaintenance = filters.maintenancePending === "ALL" || pendingIds.has(machine.id);

        return matchesSearch && matchesStatus && matchesType && matchesBrand && matchesYear && matchesMaintenance;
      })
      .sort((a, b) => {
        if (filters.sort === "year") {
          return b.year - a.year;
        }

        if (filters.sort === "hourMeter") {
          return b.hourMeter - a.hourMeter;
        }

        if (filters.sort === "maintenanceCost") {
          return calculateMachineMaintenanceCost(b) - calculateMachineMaintenanceCost(a);
        }

        if (filters.sort === "nextMaintenance") {
          const aTime = a.nextMaintenance ? new Date(a.nextMaintenance).getTime() : Number.MAX_SAFE_INTEGER;
          const bTime = b.nextMaintenance ? new Date(b.nextMaintenance).getTime() : Number.MAX_SAFE_INTEGER;
          return aTime - bTime;
        }

        return a.name.localeCompare(b.name, "pt-BR");
      });
  }, [alerts, filters, machines]);

  async function loadMaquinario() {
    setLoading(true);
    setError(null);

    const [machinesResponse, maintenancesResponse, fuelLogsResponse] = await Promise.all([
      fetch("/api/maquinario/machines", { cache: "no-store" }),
      fetch("/api/maquinario/maintenances", { cache: "no-store" }),
      fetch("/api/maquinario/fuel-logs", { cache: "no-store" }),
    ]);
    const [machinesPayload, maintenancesPayload, fuelLogsPayload] = await Promise.all([
      machinesResponse.json().catch(() => null),
      maintenancesResponse.json().catch(() => null),
      fuelLogsResponse.json().catch(() => null),
    ]);
    setLoading(false);

    if (!machinesResponse.ok) {
      const message = getApiError(machinesPayload, "Nao foi possivel carregar as maquinas.");
      setError(message);
      toast.error(message);
      return;
    }

    if (!maintenancesResponse.ok || !fuelLogsResponse.ok) {
      const message = "Nao foi possivel carregar todo o historico do maquinario.";
      setError(message);
      toast.error(message);
      return;
    }

    setMachines((machinesPayload as MachinePayload).machines.map(normalizeMachine));
    setMaintenances((maintenancesPayload as MaintenancePayload).maintenances);
    setFuelLogs((fuelLogsPayload as FuelLogPayload).fuelLogs);
  }

  function openCreateMachine() {
    setSelectedMachine(null);
    setMachineModalOpen(true);
  }

  function openEditMachine(machine: SerializedMachine) {
    setSelectedMachine(machine);
    setMachineModalOpen(true);
  }

  function openMaintenance(machine: SerializedMachine | null = null) {
    setSelectedMachine(machine);
    setMaintenanceModalOpen(true);
  }

  function openFuel(machine: SerializedMachine | null = null) {
    setSelectedMachine(machine);
    setFuelModalOpen(true);
  }

  function openHourMeter(machine: SerializedMachine | null = null) {
    setSelectedMachine(machine);
    setHourMeterModalOpen(true);
  }

  async function saveMachine(values: MachineValues) {
    setSavingMachine(true);
    const isEdit = Boolean(selectedMachine);
    const response = await fetch(isEdit ? `/api/maquinario/machines/${selectedMachine?.id}` : "/api/maquinario/machines", {
      method: isEdit ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingMachine(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel salvar a maquina."));
      return;
    }

    toast.success(isEdit ? "Maquina atualizada." : "Maquina criada.");
    setMachineModalOpen(false);
    setSelectedMachine(null);
    await loadMaquinario();
  }

  async function saveMaintenance(values: MachineMaintenanceValues) {
    setSavingMaintenance(true);
    const response = await fetch("/api/maquinario/maintenances", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingMaintenance(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel registrar a manutencao."));
      return;
    }

    toast.success("Manutencao registrada.");
    setMaintenanceModalOpen(false);
    setSelectedMachine(null);
    await loadMaquinario();
  }

  async function saveFuelLog(values: MachineFuelLogValues) {
    setSavingFuelLog(true);
    const response = await fetch("/api/maquinario/fuel-logs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingFuelLog(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel registrar o consumo."));
      return;
    }

    toast.success("Consumo registrado.");
    setFuelModalOpen(false);
    setSelectedMachine(null);
    await loadMaquinario();
  }

  async function saveHourMeter(values: MachineHourMeterValues) {
    setSavingHourMeter(true);
    const response = await fetch("/api/maquinario/hour-meter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const payload = await response.json().catch(() => null);
    setSavingHourMeter(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel atualizar o horimetro."));
      return;
    }

    toast.success("Horimetro atualizado.");
    setHourMeterModalOpen(false);
    setSelectedMachine(null);
    await loadMaquinario();
  }

  async function saveStatus(status: MachineStatusValue) {
    if (!statusMachine) {
      return;
    }

    setSavingStatus(true);
    const response = await fetch(`/api/maquinario/machines/${statusMachine.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...statusMachine, status, nextMaintenance: statusMachine.nextMaintenance?.slice(0, 10) ?? "" }),
    });
    const payload = await response.json().catch(() => null);
    setSavingStatus(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel alterar o status."));
      return;
    }

    toast.success("Status atualizado.");
    setStatusMachine(null);
    await loadMaquinario();
  }

  async function deleteMachine() {
    if (!machineToDelete) {
      return;
    }

    setDeleting(true);
    const response = await fetch(`/api/maquinario/machines/${machineToDelete.id}`, { method: "DELETE" });
    const payload = await response.json().catch(() => null);
    setDeleting(false);

    if (!response.ok) {
      toast.error(getApiError(payload, "Nao foi possivel excluir a maquina."));
      return;
    }

    toast.success("Maquina excluida.");
    setMachineToDelete(null);
    await loadMaquinario();
  }

  if (loading && machines.length === 0) {
    return <MaquinarioSkeleton />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 rounded-xl border border-emerald-500/15 bg-card/70 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium">Frota agricola da fazenda</p>
          <p className="text-sm text-muted-foreground">Maquinas reais cadastradas pelo usuario, com historico persistido no banco.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400" onClick={openCreateMachine}>
            <Plus className="h-4 w-4" />
            Nova Maquina
          </Button>
          <Button variant="outline" onClick={() => openMaintenance(null)} disabled={machines.length === 0}>
            <Wrench className="h-4 w-4" />
            Registrar manutencao
          </Button>
          <Button variant="outline" onClick={() => openFuel(null)} disabled={machines.length === 0}>
            <Fuel className="h-4 w-4" />
            Registrar consumo
          </Button>
          <Button variant="outline" onClick={() => openHourMeter(null)} disabled={machines.length === 0}>
            <Gauge className="h-4 w-4" />
            Atualizar horimetro
          </Button>
          <Button variant="outline" onClick={loadMaquinario} disabled={loading}>
            <RefreshCw className={loading ? "h-4 w-4 animate-spin" : "h-4 w-4"} />
            Atualizar
          </Button>
        </div>
      </div>

      {error ? (
        <Card className="rounded-xl border-red-500/20 bg-red-500/10">
          <CardContent className="p-4 text-sm text-red-200">{error}</CardContent>
        </Card>
      ) : null}

      <MachineSummaryCards summary={summary} />
      <MachineMaintenanceAlertBanner alerts={alerts} onRegisterMaintenance={() => openMaintenance(null)} />

      {machines.length === 0 ? (
        <EmptyMachinesState onCreate={openCreateMachine} />
      ) : (
        <Tabs defaultValue="maquinas" className="space-y-4">
          <TabsList className="bg-card/80">
            <TabsTrigger value="maquinas">Maquinas</TabsTrigger>
            <TabsTrigger value="historico">Historico de manutencao</TabsTrigger>
            <TabsTrigger value="consumo">Consumo</TabsTrigger>
          </TabsList>

          <TabsContent value="maquinas" className="space-y-4">
            <MachineFilters filters={filters} brands={brands} years={years} onChange={setFilters} />
            {filteredMachines.length === 0 ? (
              <div className="flex min-h-44 items-center justify-center rounded-xl border border-dashed border-foreground/10 bg-card/60 text-sm text-muted-foreground">
                Nenhuma maquina encontrada com os filtros atuais.
              </div>
            ) : (
              <div className="grid gap-4">
                {filteredMachines.map((machine) => (
                  <MachineCard
                    key={machine.id}
                    machine={machine}
                    onView={setDetailsMachine}
                    onEdit={openEditMachine}
                    onDelete={setMachineToDelete}
                    onMaintenance={openMaintenance}
                    onFuel={openFuel}
                    onHourMeter={openHourMeter}
                    onStatus={setStatusMachine}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="historico">
            <MaintenanceHistoryTable maintenances={maintenances} machines={machines} />
          </TabsContent>

          <TabsContent value="consumo">
            <FuelLogList fuelLogs={fuelLogs} />
          </TabsContent>
        </Tabs>
      )}

      <MachineFormModal open={machineModalOpen} machine={selectedMachine} saving={savingMachine} onOpenChange={setMachineModalOpen} onSubmit={saveMachine} />
      <MaintenanceFormModal open={maintenanceModalOpen} machines={machines} machine={selectedMachine} saving={savingMaintenance} onOpenChange={setMaintenanceModalOpen} onSubmit={saveMaintenance} />
      <FuelLogModal open={fuelModalOpen} machines={machines} machine={selectedMachine} saving={savingFuelLog} onOpenChange={setFuelModalOpen} onSubmit={saveFuelLog} />
      <HourMeterModal open={hourMeterModalOpen} machines={machines} machine={selectedMachine} saving={savingHourMeter} onOpenChange={setHourMeterModalOpen} onSubmit={saveHourMeter} />
      <MachineDetailsModal machine={detailsMachine} onOpenChange={(open) => { if (!open) setDetailsMachine(null); }} />
      <MachineDeleteDialog machine={machineToDelete} deleting={deleting} onOpenChange={(open) => { if (!open) setMachineToDelete(null); }} onConfirm={deleteMachine} />
      <MachineStatusModal machine={statusMachine} saving={savingStatus} onOpenChange={(open) => { if (!open) setStatusMachine(null); }} onSubmit={saveStatus} />
    </div>
  );
}

function FuelLogList({ fuelLogs }: { fuelLogs: SerializedMachineFuelLog[] }) {
  if (fuelLogs.length === 0) {
    return (
      <Card className="rounded-xl border-foreground/10 bg-card/80">
        <CardContent className="flex min-h-40 items-center justify-center text-sm text-muted-foreground">
          Nenhum consumo registrado.
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="rounded-xl border-foreground/10 bg-card/80">
      <CardContent className="grid gap-3 p-4 md:grid-cols-2 xl:grid-cols-3">
        {fuelLogs.slice(0, 24).map((fuelLog) => (
          <div key={fuelLog.id} className="rounded-lg border border-foreground/10 bg-background/45 p-3">
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-medium">{fuelLog.machineName}</p>
              <span className="text-xs text-muted-foreground">{new Date(fuelLog.date).toLocaleDateString("pt-BR")}</span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {fuelLog.liters.toLocaleString("pt-BR")} L x {fuelLog.pricePerLiter.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
            </p>
            <p className="mt-1 text-sm font-semibold">
              {fuelLog.totalCost.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
            </p>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function MaquinarioSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
        {["total", "operacionais", "manutencao", "alertas", "custo", "consumo"].map((item) => (
          <div key={item} className="h-28 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
        ))}
      </div>
      <div className="h-32 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
      <div className="h-96 animate-pulse rounded-xl border border-foreground/10 bg-card/70" />
    </div>
  );
}
