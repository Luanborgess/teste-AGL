import type {
  FarmProfile,
  FinancialEntry,
  Shipment,
  StockMovement,
} from "@prisma/client";

export type FarmProfileData = FarmProfile;
export type FinancialEntryData = FinancialEntry;
export type StockMovementData = StockMovement;
export type ShipmentData = Shipment;

export type OperationSnapshot = {
  profile: FarmProfileData | null;
  financialEntries: FinancialEntryData[];
  stockMovements: StockMovementData[];
  shipments: ShipmentData[];
};

export type MetricState = {
  label: string;
  value: string;
  helper: string;
  status?: "default" | "good" | "warning" | "danger";
};
