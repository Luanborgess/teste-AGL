export type OperationalInputs = {
  productiveArea?: number | null;
  productivityPerHectare?: number | null;
  pricePerUnit?: number | null;
  estimatedCosts?: number | null;
  initialStock?: number | null;
  loadCapacity?: number | null;
  monthlyVolume?: number | null;
};

const hasPositive = (value?: number | null) =>
  typeof value === "number" && Number.isFinite(value) && value > 0;

const hasNumber = (value?: number | null) =>
  typeof value === "number" && Number.isFinite(value);

export function estimatedProduction({
  productiveArea,
  productivityPerHectare,
}: OperationalInputs) {
  if (!hasPositive(productiveArea) || !hasPositive(productivityPerHectare)) {
    return null;
  }

  return productiveArea! * productivityPerHectare!;
}

export function estimatedRevenue(inputs: OperationalInputs) {
  const production = estimatedProduction(inputs);

  if (!hasPositive(production) || !hasNumber(inputs.pricePerUnit)) {
    return null;
  }

  return production! * inputs.pricePerUnit!;
}

export function estimatedProfit(inputs: OperationalInputs) {
  const revenue = estimatedRevenue(inputs);

  if (!hasNumber(revenue) || !hasNumber(inputs.estimatedCosts)) {
    return null;
  }

  return revenue! - inputs.estimatedCosts!;
}

export function estimatedMargin(inputs: OperationalInputs) {
  const revenue = estimatedRevenue(inputs);
  const profit = estimatedProfit(inputs);

  if (!hasPositive(revenue) || !hasNumber(profit)) {
    return null;
  }

  return profit! / revenue!;
}

export function requiredLoads(inputs: OperationalInputs) {
  const production = estimatedProduction(inputs);

  if (!hasPositive(production) || !hasPositive(inputs.loadCapacity)) {
    return null;
  }

  return production! / inputs.loadCapacity!;
}

export function monthsToShip(inputs: OperationalInputs) {
  const production = estimatedProduction(inputs);

  if (!hasPositive(production) || !hasPositive(inputs.monthlyVolume)) {
    return null;
  }

  return production! / inputs.monthlyVolume!;
}

export function costPerHectare(inputs: OperationalInputs) {
  if (!hasNumber(inputs.estimatedCosts) || !hasPositive(inputs.productiveArea)) {
    return null;
  }

  return inputs.estimatedCosts! / inputs.productiveArea!;
}

export function costPerUnit(inputs: OperationalInputs) {
  const production = estimatedProduction(inputs);

  if (!hasNumber(inputs.estimatedCosts) || !hasPositive(production)) {
    return null;
  }

  return inputs.estimatedCosts! / production!;
}

export function currentStock({
  initialStock,
  entries,
  exits,
}: {
  initialStock?: number | null;
  entries: number;
  exits: number;
}) {
  if (!hasNumber(initialStock)) {
    return null;
  }

  return initialStock! + entries - exits;
}

export function buildOperationalMetrics(inputs: OperationalInputs) {
  return {
    production: estimatedProduction(inputs),
    revenue: estimatedRevenue(inputs),
    profit: estimatedProfit(inputs),
    margin: estimatedMargin(inputs),
    loads: requiredLoads(inputs),
    monthsToShip: monthsToShip(inputs),
    costPerHectare: costPerHectare(inputs),
    costPerUnit: costPerUnit(inputs),
  };
}
