import type { WeatherRiskLevel } from "@prisma/client";

export type WeatherProvider = "open-meteo";

export type WeatherLocationStatus = "NO_FARM" | "MISSING_LOCATION" | "READY";

export type FarmWeatherContext = {
  id: string;
  name: string;
  city: string;
  state: string;
  productionType: string | null;
  totalArea: number;
  coordinates: string | null;
  fields: {
    id: string;
    name: string;
    area: number;
    currentCrop: string | null;
    coordinates: string | null;
  }[];
};

export type WeatherLocation = {
  label: string;
  city: string | null;
  state: string | null;
  latitude: number;
  longitude: number;
  source: "farm_coordinates" | "farm_city_state" | "field_coordinates";
};

export type WeatherCurrent = {
  temperature: number | null;
  apparentTemperature: number | null;
  condition: string;
  weatherCode: number | null;
  humidity: number | null;
  windSpeed: number | null;
  windGusts: number | null;
  precipitation: number | null;
  uvIndex: number | null;
  updatedAt: string;
};

export type WeatherDailyForecast = {
  date: string;
  condition: string;
  weatherCode: number | null;
  temperatureMin: number | null;
  temperatureMax: number | null;
  precipitationProbability: number | null;
  precipitationSum: number | null;
  rainSum: number | null;
  windSpeedMax: number | null;
  windGustsMax: number | null;
  humidityMean: number | null;
  uvIndexMax: number | null;
};

export type WeatherAlertSeverity = "info" | "warning" | "critical" | "success";

export type WeatherAlert = {
  id: string;
  title: string;
  description: string;
  severity: WeatherAlertSeverity;
  area: "producao" | "estoque" | "logistica" | "maquinario" | "equipe" | "campo";
  evidence: string;
};

export type OperationalWindow = {
  label: string;
  description: string;
  favorable: boolean;
  bestDate: string | null;
};

export type WeatherAiRecommendations = {
  resumo: string;
  nivelRisco: WeatherRiskLevel;
  recomendacoesProducao: string[];
  recomendacoesEstoque: string[];
  recomendacoesLogistica: string[];
  recomendacoesMaquinario: string[];
  recomendacoesEquipe: string[];
  alertasCriticos: string[];
  melhorJanelaOperacional: string;
  advancedAiActive: boolean;
};

export type AgroClimateScore = {
  score: number;
  label: "Ruim" | "Atenção" | "Favorável";
  description: string;
};

export type NormalizedWeather = {
  provider: WeatherProvider;
  farm: FarmWeatherContext;
  location: WeatherLocation;
  current: WeatherCurrent;
  forecast: WeatherDailyForecast[];
  alerts: WeatherAlert[];
  agroScore: AgroClimateScore;
  riskLevel: WeatherRiskLevel;
  bestOperationalWindow: OperationalWindow;
  fetchedAt: string;
  fromCache: boolean;
  cacheAgeMinutes: number | null;
};

export type WeatherApiResponse = {
  status: WeatherLocationStatus;
  message?: string;
  weather?: NormalizedWeather;
};
