import { formatDateBR } from "@/lib/formatters";
import type {
  AttendanceStatusValue,
  EmployeeStatusValue,
  TeamAssignmentStatusValue,
} from "@/lib/validations";

export type SerializedEmployeeAttendance = {
  id: string;
  employeeId: string;
  employeeName?: string;
  date: string;
  status: AttendanceStatusValue;
  checkIn: string | null;
  checkOut: string | null;
  notes: string | null;
  createdAt: string;
};

export type SerializedTeamAssignmentMember = {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeRole: string;
  employeeSalary: number;
  roleInActivity: string | null;
  createdAt: string;
};

export type SerializedTeamAssignment = {
  id: string;
  activity: string;
  location: string;
  date: string;
  startTime: string | null;
  endTime: string | null;
  transport: string | null;
  vehicle: string | null;
  driver: string | null;
  status: TeamAssignmentStatusValue;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  members: SerializedTeamAssignmentMember[];
};

export type SerializedEmployeeSalaryHistory = {
  id: string;
  employeeId: string;
  oldSalary: number;
  newSalary: number;
  reason: string | null;
  changedAt: string;
};

export type SerializedEmployee = {
  id: string;
  fullName: string;
  cpf: string;
  phone: string;
  email: string | null;
  role: string;
  department: string | null;
  salary: number;
  status: EmployeeStatusValue;
  admissionDate: string;
  address: string | null;
  emergencyContact: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  attendances: SerializedEmployeeAttendance[];
  assignments: Array<{
    id: string;
    roleInActivity: string | null;
    createdAt: string;
    assignment: SerializedTeamAssignment;
  }>;
  salaryHistory: SerializedEmployeeSalaryHistory[];
};

export type EmployeeSummary = {
  totalEmployees: number;
  activeEmployees: number;
  payroll: number;
  fieldTeamsToday: number;
  estimatedDailyCost: number;
  absencesToday: number;
};

export const employeeStatusLabels: Record<EmployeeStatusValue, string> = {
  ATIVO: "Ativo",
  INATIVO: "Inativo",
  AFASTADO: "Afastado",
  DEMITIDO: "Demitido",
};

export const attendanceStatusLabels: Record<AttendanceStatusValue, string> = {
  PRESENTE: "Presente",
  AUSENTE: "Ausente",
  ATRASADO: "Atrasado",
  JUSTIFICADO: "Falta justificada",
};

export const assignmentStatusLabels: Record<TeamAssignmentStatusValue, string> = {
  PLANEJADA: "Planejada",
  EM_CAMPO: "Em campo",
  CONCLUIDA: "Concluida",
  CANCELADA: "Cancelada",
  ATRASADA: "Atrasada",
};

export const assignmentActivities = [
  "Plantio",
  "Colheita",
  "Pulverizacao",
  "Adubacao",
  "Irrigacao",
  "Manutencao",
  "Transporte",
  "Limpeza",
  "Monitoramento",
  "Outro",
];

export function toDateKey(value: Date | string) {
  const date = new Date(value);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function isSameDate(a: Date | string, b: Date | string) {
  return toDateKey(a) === toDateKey(b);
}

export function getLastAttendance(employee: SerializedEmployee) {
  return [...employee.attendances].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0] ?? null;
}

export function getCurrentAssignment(employee: SerializedEmployee, today = new Date()) {
  return (
    employee.assignments
      .map((member) => member.assignment)
      .filter((assignment) => isSameDate(assignment.date, today) && assignment.status !== "CANCELADA")
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0] ?? null
  );
}

export function calculateTotalEmployees(employees: SerializedEmployee[]) {
  return employees.length;
}

export function calculateActiveEmployees(employees: SerializedEmployee[]) {
  return employees.filter((employee) => employee.status === "ATIVO").length;
}

export function calculatePayroll(employees: SerializedEmployee[]) {
  return employees
    .filter((employee) => employee.status === "ATIVO")
    .reduce((total, employee) => total + employee.salary, 0);
}

export function calculateFieldTeamsToday(assignments: SerializedTeamAssignment[], today = new Date()) {
  return assignments.filter((assignment) => isSameDate(assignment.date, today) && assignment.status === "EM_CAMPO").length;
}

export function calculateEstimatedDailyCost(assignments: SerializedTeamAssignment[], today = new Date()) {
  const assignedEmployees = new Map<string, number>();

  assignments
    .filter((assignment) => isSameDate(assignment.date, today) && assignment.status !== "CANCELADA")
    .forEach((assignment) => {
      assignment.members.forEach((member) => {
        assignedEmployees.set(member.employeeId, member.employeeSalary);
      });
    });

  return [...assignedEmployees.values()].reduce((total, salary) => total + salary / 30, 0);
}

export function calculateAbsencesToday(attendances: SerializedEmployeeAttendance[], today = new Date()) {
  return attendances.filter((attendance) => isSameDate(attendance.date, today) && attendance.status === "AUSENTE").length;
}

export function buildEmployeeSummary(
  employees: SerializedEmployee[],
  assignments: SerializedTeamAssignment[],
  attendances: SerializedEmployeeAttendance[],
  today = new Date(),
): EmployeeSummary {
  return {
    totalEmployees: calculateTotalEmployees(employees),
    activeEmployees: calculateActiveEmployees(employees),
    payroll: calculatePayroll(employees),
    fieldTeamsToday: calculateFieldTeamsToday(assignments, today),
    estimatedDailyCost: calculateEstimatedDailyCost(assignments, today),
    absencesToday: calculateAbsencesToday(attendances, today),
  };
}

export function groupEmployeesByDepartment(employees: SerializedEmployee[]) {
  return employees.reduce<Record<string, number>>((groups, employee) => {
    const key = employee.department || "Sem setor";
    groups[key] = (groups[key] ?? 0) + 1;
    return groups;
  }, {});
}

export function groupEmployeesByStatus(employees: SerializedEmployee[]) {
  return employees.reduce<Record<EmployeeStatusValue, number>>(
    (groups, employee) => {
      groups[employee.status] += 1;
      return groups;
    },
    { ATIVO: 0, INATIVO: 0, AFASTADO: 0, DEMITIDO: 0 },
  );
}

export function describeAttendance(attendance: SerializedEmployeeAttendance | null) {
  if (!attendance) {
    return "Sem ponto registrado";
  }

  return `${attendanceStatusLabels[attendance.status]} em ${formatDateBR(attendance.date)}`;
}
