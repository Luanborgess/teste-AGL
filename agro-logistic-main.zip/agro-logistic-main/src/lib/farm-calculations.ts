import type { Farm, Field, FieldStatus } from "@prisma/client";

export type FarmRecord = Pick<
  Farm,
  | "id"
  | "name"
  | "owner"
  | "city"
  | "state"
  | "totalArea"
  | "productionType"
  | "coordinates"
  | "notes"
  | "createdAt"
  | "updatedAt"
>;

export type FieldRecord = Pick<
  Field,
  | "id"
  | "farmId"
  | "name"
  | "area"
  | "soilType"
  | "currentCrop"
  | "expectedProductivity"
  | "status"
  | "coordinates"
  | "notes"
  | "createdAt"
  | "updatedAt"
>;

export type SerializedField = Omit<FieldRecord, "createdAt" | "updatedAt"> & {
  createdAt: string;
  updatedAt: string;
};

export type SerializedFarm = Omit<FarmRecord, "createdAt" | "updatedAt"> & {
  createdAt: string;
  updatedAt: string;
  fields: SerializedField[];
};

export const fieldStatusLabels: Record<FieldStatus, string> = {
  ATIVO: "Ativo",
  EM_PREPARO: "Em preparo",
  INATIVO: "Inativo",
  EM_DESCANSO: "Em descanso",
  PROBLEMA: "Problema",
};

export const activeFieldStatuses = new Set<FieldStatus>(["ATIVO", "EM_PREPARO"]);

function finite(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) ? value : 0;
}

export function calculateTotalFieldArea(fields: Pick<FieldRecord, "area">[]) {
  return fields.reduce((total, field) => total + finite(field.area), 0);
}

export function calculateCultivatedArea(fields: Pick<FieldRecord, "area" | "status">[]) {
  return fields.reduce((total, field) => total + (activeFieldStatuses.has(field.status) ? finite(field.area) : 0), 0);
}

export function calculateAvailableArea(totalArea: number, fields: Pick<FieldRecord, "area">[]) {
  return totalArea - calculateTotalFieldArea(fields);
}

export function calculateAverageProductivity(fields: Pick<FieldRecord, "expectedProductivity">[]) {
  const productivities = fields
    .map((field) => field.expectedProductivity)
    .filter((value): value is number => typeof value === "number" && Number.isFinite(value));

  if (productivities.length === 0) {
    return null;
  }

  return productivities.reduce((total, value) => total + value, 0) / productivities.length;
}

export function calculateActiveCrops(fields: Pick<FieldRecord, "currentCrop" | "status">[]) {
  return Array.from(
    new Set(
      fields
        .filter((field) => activeFieldStatuses.has(field.status))
        .map((field) => field.currentCrop?.trim())
        .filter((crop): crop is string => Boolean(crop)),
    ),
  ).sort((a, b) => a.localeCompare(b, "pt-BR"));
}

export function calculateFieldsByStatus(fields: Pick<FieldRecord, "status">[]) {
  return fields.reduce(
    (acc, field) => {
      acc[field.status] += 1;
      return acc;
    },
    {
      ATIVO: 0,
      EM_PREPARO: 0,
      INATIVO: 0,
      EM_DESCANSO: 0,
      PROBLEMA: 0,
    } satisfies Record<FieldStatus, number>,
  );
}

export function calculateAreaByCrop(fields: Pick<FieldRecord, "area" | "currentCrop">[]) {
  const map = new Map<string, number>();

  fields.forEach((field) => {
    const crop = field.currentCrop?.trim() || "Sem cultura";
    map.set(crop, (map.get(crop) ?? 0) + finite(field.area));
  });

  return Array.from(map.entries())
    .map(([crop, area]) => ({ crop, area }))
    .sort((a, b) => b.area - a.area);
}

export function canFitFieldArea({
  totalArea,
  fields,
  nextArea,
  ignoredFieldId,
}: {
  totalArea: number;
  fields: Pick<FieldRecord, "id" | "area">[];
  nextArea: number;
  ignoredFieldId?: string;
}) {
  const usedArea = calculateTotalFieldArea(fields.filter((field) => field.id !== ignoredFieldId));
  return usedArea + nextArea <= totalArea;
}

export function buildFarmSummary(farm: Pick<FarmRecord, "totalArea"> & { fields: FieldRecord[] | SerializedField[] }) {
  const totalFieldArea = calculateTotalFieldArea(farm.fields);
  const cultivatedArea = calculateCultivatedArea(farm.fields);
  const availableArea = farm.totalArea - totalFieldArea;
  const averageProductivity = calculateAverageProductivity(farm.fields);
  const activeCrops = calculateActiveCrops(farm.fields);

  return {
    totalArea: farm.totalArea,
    totalFieldArea,
    cultivatedArea,
    availableArea,
    fieldCount: farm.fields.length,
    averageProductivity,
    activeCrops,
    activeCropCount: activeCrops.length,
    fieldsByStatus: calculateFieldsByStatus(farm.fields),
    areaByCrop: calculateAreaByCrop(farm.fields),
    isAreaExceeded: availableArea < 0,
  };
}
