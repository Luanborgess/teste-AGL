import type { Prisma } from "@prisma/client";
import type {
  SerializedMachine,
  SerializedMachineFuelLog,
  SerializedMachineHourMeterLog,
  SerializedMachineMaintenance,
} from "@/lib/machine-calculations";

export type MachineWithHistory = Prisma.MachineGetPayload<{
  include: {
    maintenances: true;
    fuelLogs: true;
    hourMeterLogs: true;
  };
}>;

export type MaintenanceWithMachine = Prisma.MachineMaintenanceGetPayload<{
  include: {
    machine: {
      select: {
        name: true;
      };
    };
  };
}>;

export type FuelLogWithMachine = Prisma.MachineFuelLogGetPayload<{
  include: {
    machine: {
      select: {
        name: true;
      };
    };
  };
}>;

export type HourMeterLogWithMachine = Prisma.MachineHourMeterLogGetPayload<{
  include: {
    machine: {
      select: {
        name: true;
      };
    };
  };
}>;

export function serializeMachineMaintenance(
  maintenance: MaintenanceWithMachine | (MachineWithHistory["maintenances"][number] & { machine?: { name: string } }),
): SerializedMachineMaintenance {
  return {
    id: maintenance.id,
    machineId: maintenance.machineId,
    machineName: maintenance.machine?.name ?? "",
    type: maintenance.type,
    description: maintenance.description,
    cost: maintenance.cost,
    performedAt: maintenance.performedAt.toISOString(),
    nextReview: maintenance.nextReview?.toISOString() ?? null,
    partsChanged: maintenance.partsChanged,
    responsible: maintenance.responsible,
    hourMeter: maintenance.hourMeter,
    notes: maintenance.notes,
    createdAt: maintenance.createdAt.toISOString(),
  };
}

export function serializeMachineFuelLog(
  fuelLog: FuelLogWithMachine | (MachineWithHistory["fuelLogs"][number] & { machine?: { name: string } }),
): SerializedMachineFuelLog {
  return {
    id: fuelLog.id,
    machineId: fuelLog.machineId,
    machineName: fuelLog.machine?.name ?? "",
    date: fuelLog.date.toISOString(),
    liters: fuelLog.liters,
    pricePerLiter: fuelLog.pricePerLiter,
    totalCost: fuelLog.totalCost,
    hourMeter: fuelLog.hourMeter,
    responsible: fuelLog.responsible,
    notes: fuelLog.notes,
    createdAt: fuelLog.createdAt.toISOString(),
  };
}

export function serializeMachineHourMeterLog(
  hourMeterLog: HourMeterLogWithMachine | (MachineWithHistory["hourMeterLogs"][number] & { machine?: { name: string } }),
): SerializedMachineHourMeterLog {
  return {
    id: hourMeterLog.id,
    machineId: hourMeterLog.machineId,
    machineName: hourMeterLog.machine?.name ?? "",
    previousValue: hourMeterLog.previousValue,
    newValue: hourMeterLog.newValue,
    date: hourMeterLog.date.toISOString(),
    notes: hourMeterLog.notes,
    createdAt: hourMeterLog.createdAt.toISOString(),
  };
}

export function serializeMachine(machine: MachineWithHistory): SerializedMachine {
  return {
    id: machine.id,
    name: machine.name,
    type: machine.type,
    brand: machine.brand,
    model: machine.model,
    year: machine.year,
    identifier: machine.identifier,
    hourMeter: machine.hourMeter,
    fuelConsumption: machine.fuelConsumption,
    operationalCost: machine.operationalCost,
    nextMaintenance: machine.nextMaintenance?.toISOString() ?? null,
    status: machine.status,
    notes: machine.notes,
    createdAt: machine.createdAt.toISOString(),
    updatedAt: machine.updatedAt.toISOString(),
    maintenances: machine.maintenances.map((maintenance) =>
      serializeMachineMaintenance({ ...maintenance, machine: { name: machine.name } }),
    ),
    fuelLogs: machine.fuelLogs.map((fuelLog) => serializeMachineFuelLog({ ...fuelLog, machine: { name: machine.name } })),
    hourMeterLogs: machine.hourMeterLogs.map((hourMeterLog) =>
      serializeMachineHourMeterLog({ ...hourMeterLog, machine: { name: machine.name } }),
    ),
  };
}
