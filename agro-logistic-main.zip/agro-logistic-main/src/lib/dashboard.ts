import type { FarmProfile, FinancialEntry, Shipment, StockMovement } from "@prisma/client";
import { buildOperationalMetrics, currentStock } from "@/lib/calculations";

export function getStockTotals(movements: StockMovement[]) {
  return movements.reduce(
    (totals, movement) => {
      if (movement.type === "IN") {
        totals.entries += movement.quantity;
      } else {
        totals.exits += movement.quantity;
      }

      return totals;
    },
    { entries: 0, exits: 0 },
  );
}

export function getFinancialTotals(entries: FinancialEntry[]) {
  return entries.reduce(
    (totals, entry) => {
      if (entry.type === "REVENUE") {
        totals.revenue += entry.amount;
      } else {
        totals.expenses += entry.amount;
      }

      totals.balance = totals.revenue - totals.expenses;
      return totals;
    },
    { revenue: 0, expenses: 0, balance: 0 },
  );
}

export function getShipmentTotals(shipments: Shipment[]) {
  return shipments.reduce(
    (totals, shipment) => {
      if (shipment.status !== "CANCELED") {
        totals.volume += shipment.volume;
      }

      totals.freight += shipment.freightCost;
      return totals;
    },
    { volume: 0, freight: 0 },
  );
}

export function getDashboardData(
  profile: FarmProfile | null,
  financialEntries: FinancialEntry[],
  stockMovements: StockMovement[],
  shipments: Shipment[],
) {
  const stockTotals = getStockTotals(stockMovements);
  const financialTotals = getFinancialTotals(financialEntries);
  const shipmentTotals = getShipmentTotals(shipments);
  const operationalMetrics = profile ? buildOperationalMetrics(profile) : null;
  const stock = profile
    ? currentStock({
        initialStock: profile.initialStock,
        entries: stockTotals.entries,
        exits: stockTotals.exits,
      })
    : null;

  return {
    operationalMetrics,
    stock,
    stockTotals,
    financialTotals,
    shipmentTotals,
  };
}

export function hasCompleteProfile(profile: FarmProfile | null) {
  return Boolean(
    profile?.farmName &&
      profile.productiveArea > 0 &&
      profile.productivityPerHectare > 0 &&
      profile.loadCapacity > 0 &&
      profile.monthlyVolume > 0,
  );
}
