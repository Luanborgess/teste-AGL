import type { WeatherRiskLevel } from "@prisma/client";
import type {
  AgroClimateScore,
  NormalizedWeather,
  OperationalWindow,
  WeatherAiRecommendations,
  WeatherAlert,
  WeatherCurrent,
  WeatherDailyForecast,
  WeatherLocation,
  FarmWeatherContext,
} from "@/lib/weather-types";

type OpenMeteoRawResponse = {
  current?: Record<string, unknown>;
  daily?: Record<string, unknown[]>;
  latitude?: number;
  longitude?: number;
  timezone?: string;
};

const weatherCodeLabels: Record<number, string> = {
  0: "Céu limpo",
  1: "Predominantemente limpo",
  2: "Parcialmente nublado",
  3: "Nublado",
  45: "Nevoeiro",
  48: "Nevoeiro com deposição",
  51: "Garoa leve",
  53: "Garoa moderada",
  55: "Garoa intensa",
  56: "Garoa congelante leve",
  57: "Garoa congelante intensa",
  61: "Chuva fraca",
  63: "Chuva moderada",
  65: "Chuva forte",
  66: "Chuva congelante leve",
  67: "Chuva congelante forte",
  71: "Neve fraca",
  73: "Neve moderada",
  75: "Neve forte",
  77: "Grãos de neve",
  80: "Pancadas de chuva leves",
  81: "Pancadas de chuva moderadas",
  82: "Pancadas de chuva fortes",
  85: "Pancadas de neve leves",
  86: "Pancadas de neve fortes",
  95: "Trovoadas",
  96: "Trovoadas com granizo leve",
  99: "Trovoadas com granizo forte",
};

function asNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function asString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value : null;
}

function dailyValue<T>(daily: Record<string, unknown[]> | undefined, key: string, index: number, mapper: (value: unknown) => T): T {
  return mapper(daily?.[key]?.[index]);
}

export function formatWeatherCode(code: number | null) {
  if (typeof code !== "number") {
    return "Condição indisponível";
  }

  return weatherCodeLabels[code] ?? `Código ${code}`;
}

export function normalizeWeatherApiResponse({
  raw,
  farm,
  location,
  fetchedAt,
  fromCache,
  cacheAgeMinutes,
}: {
  raw: OpenMeteoRawResponse;
  farm: FarmWeatherContext;
  location: WeatherLocation;
  fetchedAt: Date;
  fromCache: boolean;
  cacheAgeMinutes: number | null;
}): NormalizedWeather {
  const currentCode = asNumber(raw.current?.weather_code);
  const current: WeatherCurrent = {
    temperature: asNumber(raw.current?.temperature_2m),
    apparentTemperature: asNumber(raw.current?.apparent_temperature),
    condition: formatWeatherCode(currentCode),
    weatherCode: currentCode,
    humidity: asNumber(raw.current?.relative_humidity_2m),
    windSpeed: asNumber(raw.current?.wind_speed_10m),
    windGusts: asNumber(raw.current?.wind_gusts_10m),
    precipitation: asNumber(raw.current?.precipitation),
    uvIndex: null,
    updatedAt: asString(raw.current?.time) ?? fetchedAt.toISOString(),
  };

  const dayCount = raw.daily?.time?.length ?? 0;
  const forecast: WeatherDailyForecast[] = Array.from({ length: dayCount }).map((_, index) => {
    const weatherCode = dailyValue(raw.daily, "weather_code", index, asNumber);

    return {
      date: dailyValue(raw.daily, "time", index, (value) => asString(value) ?? fetchedAt.toISOString().slice(0, 10)),
      condition: formatWeatherCode(weatherCode),
      weatherCode,
      temperatureMin: dailyValue(raw.daily, "temperature_2m_min", index, asNumber),
      temperatureMax: dailyValue(raw.daily, "temperature_2m_max", index, asNumber),
      precipitationProbability: dailyValue(raw.daily, "precipitation_probability_max", index, asNumber),
      precipitationSum: dailyValue(raw.daily, "precipitation_sum", index, asNumber),
      rainSum: dailyValue(raw.daily, "rain_sum", index, asNumber),
      windSpeedMax: dailyValue(raw.daily, "wind_speed_10m_max", index, asNumber),
      windGustsMax: dailyValue(raw.daily, "wind_gusts_10m_max", index, asNumber),
      humidityMean: dailyValue(raw.daily, "relative_humidity_2m_mean", index, asNumber),
      uvIndexMax: dailyValue(raw.daily, "uv_index_max", index, asNumber),
    };
  });

  const alerts = detectWeatherAlerts(current, forecast);
  const agroScore = calculateAgroClimateScore(current, forecast, alerts);
  const riskLevel = calculateWeatherRiskLevel(current, forecast, alerts);
  const bestOperationalWindow = findBestOperationalWindow(forecast);

  return {
    provider: "open-meteo",
    farm,
    location,
    current,
    forecast,
    alerts,
    agroScore,
    riskLevel,
    bestOperationalWindow,
    fetchedAt: fetchedAt.toISOString(),
    fromCache,
    cacheAgeMinutes,
  };
}

export function calculateAgroClimateScore(current: WeatherCurrent, forecast: WeatherDailyForecast[], alerts: WeatherAlert[]): AgroClimateScore {
  const nextDays = forecast.slice(0, 5);
  let score = 100;

  const totalRain = nextDays.reduce((total, day) => total + (day.precipitationSum ?? 0), 0);
  const maxRain = Math.max(0, ...nextDays.map((day) => day.precipitationSum ?? 0));
  const maxWind = Math.max(current.windSpeed ?? 0, ...nextDays.map((day) => day.windSpeedMax ?? 0));
  const maxTemp = Math.max(current.temperature ?? 0, ...nextDays.map((day) => day.temperatureMax ?? 0));
  const minTemp = Math.min(current.temperature ?? 99, ...nextDays.map((day) => day.temperatureMin ?? 99));
  const avgHumidity =
    nextDays.length > 0 ? nextDays.reduce((total, day) => total + (day.humidityMean ?? current.humidity ?? 60), 0) / nextDays.length : current.humidity ?? 60;

  if (maxRain >= 45) score -= 24;
  else if (maxRain >= 25) score -= 16;
  else if (totalRain < 5) score -= 14;

  if (maxWind >= 45) score -= 22;
  else if (maxWind >= 30) score -= 14;

  if (maxTemp >= 38 || minTemp <= 5) score -= 18;
  else if (maxTemp >= 34 || minTemp <= 9) score -= 10;

  if (avgHumidity >= 88 || avgHumidity <= 30) score -= 12;
  else if (avgHumidity >= 80 || avgHumidity <= 40) score -= 6;

  score -= alerts.filter((alert) => alert.severity === "critical").length * 8;
  score -= alerts.filter((alert) => alert.severity === "warning").length * 4;
  score = Math.max(0, Math.min(100, Math.round(score)));

  if (score <= 39) {
    return { score, label: "Ruim", description: "Operação com restrições relevantes. Priorize segurança, solo e logística." };
  }

  if (score <= 69) {
    return { score, label: "Atenção", description: "Há janelas possíveis, mas algumas atividades exigem cautela." };
  }

  return { score, label: "Favorável", description: "Condição geral boa para planejar atividades de campo." };
}

export function calculateWeatherRiskLevel(current: WeatherCurrent, forecast: WeatherDailyForecast[], alerts: WeatherAlert[]): WeatherRiskLevel {
  const hasCritical = alerts.some((alert) => alert.severity === "critical");
  const maxRain = Math.max(0, ...forecast.slice(0, 5).map((day) => day.precipitationSum ?? 0));
  const maxWind = Math.max(current.windSpeed ?? 0, ...forecast.slice(0, 5).map((day) => day.windSpeedMax ?? 0));
  const maxTemp = Math.max(current.temperature ?? 0, ...forecast.slice(0, 5).map((day) => day.temperatureMax ?? 0));
  const minTemp = Math.min(current.temperature ?? 99, ...forecast.slice(0, 5).map((day) => day.temperatureMin ?? 99));

  if (hasCritical || maxRain >= 45 || maxWind >= 45 || maxTemp >= 38 || minTemp <= 5) {
    return "ALTO";
  }

  if (alerts.some((alert) => alert.severity === "warning") || maxRain >= 20 || maxWind >= 30 || maxTemp >= 34 || minTemp <= 9) {
    return "MEDIO";
  }

  return "BAIXO";
}

export function detectWeatherAlerts(current: WeatherCurrent, forecast: WeatherDailyForecast[]): WeatherAlert[] {
  const alerts: WeatherAlert[] = [];
  const nextDays = forecast.slice(0, 5);
  const totalRain = nextDays.reduce((total, day) => total + (day.precipitationSum ?? 0), 0);
  const maxRainDay = nextDays.reduce<WeatherDailyForecast | null>(
    (highest, day) => ((day.precipitationSum ?? 0) > (highest?.precipitationSum ?? 0) ? day : highest),
    null,
  );
  const maxWindDay = nextDays.reduce<WeatherDailyForecast | null>(
    (highest, day) => ((day.windSpeedMax ?? 0) > (highest?.windSpeedMax ?? 0) ? day : highest),
    null,
  );
  const humidDays = nextDays.filter((day) => (day.humidityMean ?? 0) >= 85 && (day.precipitationProbability ?? 0) >= 50);
  const dryDays = nextDays.filter((day) => (day.precipitationSum ?? 0) < 1 && (day.humidityMean ?? 100) <= 45);
  const stableDryDays = nextDays.filter((day) => (day.precipitationProbability ?? 100) <= 25 && (day.precipitationSum ?? 0) < 2 && (day.windSpeedMax ?? 99) < 25);

  if ((maxRainDay?.precipitationSum ?? 0) >= 30) {
    alerts.push({
      id: "heavy-rain",
      title: "Chuva forte prevista",
      description: "Há previsão de volume elevado de chuva nos próximos dias. Antecipe operações sensíveis ao solo úmido.",
      severity: (maxRainDay?.precipitationSum ?? 0) >= 50 ? "critical" : "warning",
      area: "logistica",
      evidence: `${maxRainDay?.precipitationSum?.toLocaleString("pt-BR")} mm em ${new Date(maxRainDay?.date ?? "").toLocaleDateString("pt-BR")}`,
    });
  }

  if (dryDays.length >= 4 || totalRain < 3) {
    alerts.push({
      id: "dry-risk",
      title: "Risco de déficit hídrico",
      description: "A previsão indica pouca chuva no período analisado. Reavalie plantio, irrigação e demanda hídrica da cultura.",
      severity: dryDays.length >= 4 ? "warning" : "info",
      area: "producao",
      evidence: `Chuva acumulada prevista de ${totalRain.toLocaleString("pt-BR")} mm em 5 dias`,
    });
  }

  if ((maxWindDay?.windSpeedMax ?? current.windSpeed ?? 0) >= 30) {
    alerts.push({
      id: "wind-spray",
      title: "Janela ruim para pulverização",
      description: "O vento previsto está acima de um limite conservador para aplicação no campo.",
      severity: (maxWindDay?.windSpeedMax ?? 0) >= 45 ? "critical" : "warning",
      area: "campo",
      evidence: `Vento de até ${(maxWindDay?.windSpeedMax ?? current.windSpeed ?? 0).toLocaleString("pt-BR")} km/h`,
    });
  }

  if (humidDays.length >= 2) {
    alerts.push({
      id: "fungal-pressure",
      title: "Umidade alta com chuva",
      description: "Condição pode elevar pressão de doenças fúngicas. Acompanhe talhões mais sensíveis e estoque de defensivos.",
      severity: "warning",
      area: "estoque",
      evidence: `${humidDays.length} dias com umidade alta e chance relevante de chuva`,
    });
  }

  const maxTemp = Math.max(current.temperature ?? 0, ...nextDays.map((day) => day.temperatureMax ?? 0));
  if (maxTemp >= 35) {
    alerts.push({
      id: "extreme-heat",
      title: "Calor intenso",
      description: "Ajuste jornada da equipe, hidratação e atividades de maior esforço.",
      severity: maxTemp >= 38 ? "critical" : "warning",
      area: "equipe",
      evidence: `Temperatura máxima prevista de ${maxTemp.toLocaleString("pt-BR")} °C`,
    });
  }

  const minTemp = Math.min(current.temperature ?? 99, ...nextDays.map((day) => day.temperatureMin ?? 99));
  if (minTemp <= 9) {
    alerts.push({
      id: "cold-risk",
      title: "Frio intenso",
      description: "Monitore culturas sensíveis e programe atividades de campo considerando a queda de temperatura.",
      severity: minTemp <= 5 ? "critical" : "warning",
      area: "producao",
      evidence: `Temperatura mínima prevista de ${minTemp.toLocaleString("pt-BR")} °C`,
    });
  }

  if (stableDryDays.length >= 2) {
    alerts.push({
      id: "harvest-window",
      title: "Possível janela para colheita",
      description: "Há dias com baixa chuva prevista e vento moderado, favoráveis para operações de colheita e campo.",
      severity: "success",
      area: "producao",
      evidence: `${stableDryDays.length} dias com baixa chance de chuva e vento moderado`,
    });
  }

  const plantingWindow = nextDays.filter((day) => {
    const rain = day.precipitationSum ?? 0;
    return rain >= 5 && rain <= 25 && (day.windSpeedMax ?? 99) < 30;
  });

  if (plantingWindow.length >= 1) {
    alerts.push({
      id: "planting-window",
      title: "Boa janela para plantio",
      description: "A previsão indica chuva moderada sem vento forte em pelo menos um dia do período.",
      severity: "success",
      area: "campo",
      evidence: `${plantingWindow.length} dia(s) com chuva moderada prevista`,
    });
  }

  if ((maxRainDay?.precipitationSum ?? 0) >= 20) {
    alerts.push({
      id: "heavy-machinery",
      title: "Atenção para máquinas pesadas",
      description: "Evite tráfego pesado em áreas com solo muito úmido após chuvas relevantes.",
      severity: "warning",
      area: "maquinario",
      evidence: `Maior chuva diária prevista: ${(maxRainDay?.precipitationSum ?? 0).toLocaleString("pt-BR")} mm`,
    });
  }

  return alerts;
}

export function findBestOperationalWindow(forecast: WeatherDailyForecast[]): OperationalWindow {
  const candidates = forecast
    .slice(0, 7)
    .map((day) => {
      let score = 100;
      score -= Math.min(45, (day.precipitationProbability ?? 50) * 0.35);
      score -= Math.min(35, (day.precipitationSum ?? 0) * 1.4);
      score -= Math.max(0, (day.windSpeedMax ?? 0) - 18) * 1.4;
      score -= Math.max(0, (day.temperatureMax ?? 28) - 34) * 3;
      return { day, score };
    })
    .sort((a, b) => b.score - a.score);

  const best = candidates[0];

  if (!best) {
    return {
      label: "Sem previsão suficiente",
      description: "A API não retornou dias suficientes para calcular uma janela operacional.",
      favorable: false,
      bestDate: null,
    };
  }

  const date = new Date(`${best.day.date}T12:00:00`);
  const formattedDate = date.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "2-digit" });
  const favorable = best.score >= 68;

  return {
    label: favorable ? "Janela favorável" : "Janela com restrições",
    description: `${formattedDate}: ${best.day.condition}, ${best.day.precipitationProbability ?? 0}% de chance de chuva, ${best.day.precipitationSum ?? 0} mm e vento até ${best.day.windSpeedMax ?? 0} km/h.`,
    favorable,
    bestDate: best.day.date,
  };
}

export function generateLocalWeatherRecommendations(weather: NormalizedWeather): WeatherAiRecommendations {
  const highWind = weather.alerts.some((alert) => alert.id === "wind-spray");
  const heavyRain = weather.alerts.some((alert) => alert.id === "heavy-rain");
  const dryRisk = weather.alerts.some((alert) => alert.id === "dry-risk");
  const fungalRisk = weather.alerts.some((alert) => alert.id === "fungal-pressure");
  const heat = weather.alerts.some((alert) => alert.id === "extreme-heat");
  const machineryRisk = weather.alerts.some((alert) => alert.id === "heavy-machinery");
  return {
    resumo: `Avaliação local baseada em dados reais da Open-Meteo para ${weather.location.label}. Índice AgroClimático ${weather.agroScore.score}/100 (${weather.agroScore.label}).`,
    nivelRisco: weather.riskLevel,
    recomendacoesProducao: [
      highWind ? "Evite pulverização nas janelas com vento elevado." : "Pulverizações podem ser avaliadas nas janelas com vento moderado e sem chuva próxima.",
      heavyRain ? "Evite colheita e preparo de solo nos períodos com chuva forte prevista." : "Planeje atividades de campo priorizando os dias com menor chance de chuva.",
      dryRisk ? "Reavalie plantio e irrigação por risco de baixa disponibilidade hídrica." : "Use a previsão de chuva moderada para ajustar plantio e manejo.",
    ],
    recomendacoesEstoque: [
      fungalRisk ? "Confira estoque de fungicidas e EPIs para possível aumento de pressão de doenças." : "Mantenha estoque operacional alinhado ao cronograma de campo.",
      heavyRain ? "Proteja insumos sensíveis à umidade e antecipe separação de materiais." : "Aproveite dias estáveis para organizar insumos por operação.",
    ],
    recomendacoesLogistica: [
      heavyRain ? "Antecipe cargas e deslocamentos antes das chuvas mais intensas." : "Distribua fretes e deslocamentos nas melhores janelas operacionais.",
      "Monitore acessos internos após chuva para evitar atrasos e atolamentos.",
    ],
    recomendacoesMaquinario: [
      machineryRisk ? "Evite máquinas pesadas em solo encharcado e priorize áreas com melhor drenagem." : "Programe manutenção preventiva nos períodos menos favoráveis ao campo.",
      highWind ? "Reavalie uso de pulverizadores nos horários de vento mais forte." : "Mantenha pulverizadores prontos para as janelas com vento seguro.",
    ],
    recomendacoesEquipe: [
      heat ? "Ajuste jornada, pausas e hidratação da equipe por calor intenso." : "Organize equipe conforme a melhor janela operacional prevista.",
      heavyRain ? "Evite expor equipe a tempestades, descargas elétricas e vias internas críticas." : "Mantenha comunicação diária sobre mudanças de previsão.",
    ],
    alertasCriticos: weather.alerts.filter((alert) => alert.severity === "critical").map((alert) => alert.title),
    melhorJanelaOperacional: weather.bestOperationalWindow.description,
    advancedAiActive: false,
  };
}
