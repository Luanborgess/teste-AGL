import { z } from "zod";

const requiredString = z.string().trim().min(1, "Campo obrigatório");
const money = z.coerce.number().nonnegative("Informe um valor igual ou maior que zero");
const positive = z.coerce.number().positive("Informe um valor maior que zero");

export const loginSchema = z.object({
  name: requiredString.min(3, "Informe seu nome"),
  email: z.email("Informe um e-mail válido"),
});

export const farmProfileSchema = z.object({
  farmName: requiredString,
  responsible: requiredString,
  phone: requiredString,
  operationType: requiredString,
  totalArea: positive,
  productiveArea: positive,
  mainCrop: requiredString,
  productivityPerHectare: positive,
  pricePerUnit: money,
  estimatedCosts: money,
  initialStock: money,
  machines: z.coerce.number().int().nonnegative("Informe zero ou mais máquinas"),
  loadCapacity: positive,
  monthlyVolume: positive,
  city: requiredString,
  state: requiredString.max(2, "Use a sigla do estado").min(2, "Use a sigla do estado"),
  notes: z.string().trim().optional(),
});

export const financialEntrySchema = z.object({
  type: z.enum(["REVENUE", "EXPENSE"]),
  description: requiredString,
  category: requiredString,
  amount: positive,
  date: requiredString,
});

export const transactionTypeSchema = z.enum(["RECEITA", "DESPESA", "INVESTIMENTO"]);

export const transactionSchema = z.object({
  description: requiredString.min(3, "A descricao precisa ter pelo menos 3 caracteres"),
  amount: positive,
  category: requiredString,
  type: transactionTypeSchema,
  date: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
    message: "Informe uma data valida",
  }),
  notes: z.string().trim().optional(),
});

export const cropStatusSchema = z.enum(["PLANTADO", "EM_CRESCIMENTO", "COLHIDO", "CANCELADO"]);

export const cropSchema = z
  .object({
    name: requiredString.min(2, "Informe o cultivo"),
    variety: z.string().trim().optional(),
    plantedArea: positive,
    plantingDate: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
      message: "Informe uma data de plantio valida",
    }),
    expectedHarvestDate: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
      message: "Informe uma data prevista valida",
    }),
    expectedProduction: money,
    harvestedProduction: money,
    status: cropStatusSchema,
    notes: z.string().trim().optional(),
  })
  .superRefine((value, context) => {
    const plantingDate = new Date(value.plantingDate);
    const expectedHarvestDate = new Date(value.expectedHarvestDate);

    if (expectedHarvestDate < plantingDate) {
      context.addIssue({
        code: "custom",
        path: ["expectedHarvestDate"],
        message: "A colheita prevista nao pode ser anterior ao plantio",
      });
    }
  });

export const stockMovementSchema = z.object({
  type: z.enum(["IN", "OUT"]),
  description: requiredString,
  quantity: positive,
  date: requiredString,
});

export const inventoryCategorySchema = z.enum([
  "SEMENTES",
  "FERTILIZANTES",
  "DEFENSIVOS",
  "COMBUSTIVEIS",
  "LUBRIFICANTES",
  "PECAS",
  "EQUIPAMENTOS",
  "FERRAMENTAS",
  "EPIS",
  "EMBALAGENS",
  "PRODUCAO_COLHIDA",
  "OUTROS",
]);

export const inventoryUnitSchema = z.enum([
  "sacas",
  "kg",
  "toneladas",
  "litros",
  "unidades",
  "caixas",
  "galoes",
  "metros",
  "hectares tratados",
  "outros",
]);

export const inventoryMovementTypeSchema = z.enum(["ENTRADA", "SAIDA", "CONSUMO", "PERDA", "AJUSTE"]);

const optionalDateInput = z
  .string()
  .trim()
  .optional()
  .refine((value) => !value || !Number.isNaN(new Date(value).getTime()), {
    message: "Informe uma data valida",
  });

const optionalMoney = z.preprocess(
  (value) => (value === "" || value === null ? undefined : value),
  z.coerce.number().nonnegative("Informe um custo igual ou maior que zero").optional(),
);

export const inventoryItemSchema = z.object({
  name: requiredString.min(2, "Informe o produto"),
  category: inventoryCategorySchema,
  unit: inventoryUnitSchema,
  quantity: money,
  minimumStock: money,
  unitCost: money,
  supplier: z.string().trim().optional(),
  expirationDate: optionalDateInput,
  location: z.string().trim().optional(),
  sku: z.string().trim().optional(),
  notes: z.string().trim().optional(),
});

export const inventoryMovementSchema = z
  .object({
    itemId: requiredString,
    type: inventoryMovementTypeSchema,
    quantity: positive,
    responsible: z.string().trim().optional(),
    date: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
      message: "Informe uma data valida",
    }),
    notes: z.string().trim().optional(),
    originOrDestination: z.string().trim().optional(),
    unitCost: optionalMoney,
    reason: z.string().trim().optional(),
  })
  .superRefine((value, context) => {
    if ((value.type === "PERDA" || value.type === "AJUSTE") && !value.reason) {
      context.addIssue({
        code: "custom",
        path: ["reason"],
        message: "Informe o motivo",
      });
    }
  });

export const shipmentSchema = z.object({
  origin: requiredString,
  destination: requiredString,
  carrier: requiredString,
  status: z.enum(["PLANNED", "IN_TRANSIT", "DELIVERED", "DELAYED", "CANCELED"]),
  volume: positive,
  freightCost: money,
  date: requiredString,
});

export const employeeStatusSchema = z.enum(["ATIVO", "INATIVO", "AFASTADO", "DEMITIDO"]);
export const attendanceStatusSchema = z.enum(["PRESENTE", "AUSENTE", "ATRASADO", "JUSTIFICADO"]);
export const teamAssignmentStatusSchema = z.enum(["PLANEJADA", "EM_CAMPO", "CONCLUIDA", "CANCELADA", "ATRASADA"]);

export const machineStatusSchema = z.enum(["OPERACIONAL", "MANUTENCAO", "EM_REPARO", "PARADA", "VENDIDA"]);
export const machineTypeSchema = z.enum([
  "TRATOR",
  "COLHEITADEIRA",
  "PULVERIZADOR",
  "PLANTADEIRA",
  "CAMINHAO",
  "CARRETA",
  "PA_CARREGADEIRA",
  "IMPLEMENTO",
  "IRRIGACAO",
  "VEICULO_APOIO",
  "OUTRO",
]);
export const maintenanceTypeSchema = z.enum([
  "PREVENTIVA",
  "CORRETIVA",
  "REVISAO",
  "TROCA_OLEO",
  "TROCA_PECA",
  "REPARO_EMERGENCIAL",
  "OUTRO",
]);

const cpfInput = requiredString.refine((value) => value.replace(/\D/g, "").length === 11, {
  message: "Informe um CPF valido",
});

const optionalEmail = z
  .string()
  .trim()
  .optional()
  .refine((value) => !value || z.email().safeParse(value).success, {
    message: "Informe um e-mail valido",
  });

const optionalTimeInput = z
  .string()
  .trim()
  .optional()
  .refine((value) => !value || /^\d{2}:\d{2}$/.test(value), {
    message: "Informe um horario valido",
  });

export const employeeSchema = z.object({
  fullName: requiredString.min(3, "Informe o nome completo"),
  cpf: cpfInput,
  phone: requiredString,
  email: optionalEmail,
  role: requiredString,
  department: z.string().trim().optional(),
  salary: money,
  admissionDate: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
    message: "Informe uma data de admissao valida",
  }),
  status: employeeStatusSchema,
  address: z.string().trim().optional(),
  emergencyContact: z.string().trim().optional(),
  notes: z.string().trim().optional(),
  salaryChangeReason: z.string().trim().optional(),
});

export const employeeAttendanceSchema = z.object({
  employeeId: requiredString,
  date: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
    message: "Informe uma data valida",
  }),
  status: attendanceStatusSchema,
  checkIn: optionalTimeInput,
  checkOut: optionalTimeInput,
  notes: z.string().trim().optional(),
});

export const teamAssignmentSchema = z
  .object({
    activity: requiredString,
    location: requiredString,
    date: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
      message: "Informe uma data valida",
    }),
    startTime: optionalTimeInput,
    endTime: optionalTimeInput,
    employeeIds: z.array(requiredString).min(1, "Selecione pelo menos um funcionario"),
    transport: z.string().trim().optional(),
    vehicle: z.string().trim().optional(),
    driver: z.string().trim().optional(),
    notes: z.string().trim().optional(),
    status: teamAssignmentStatusSchema,
  })
  .superRefine((value, context) => {
    if (value.startTime && value.endTime && value.endTime < value.startTime) {
      context.addIssue({
        code: "custom",
        path: ["endTime"],
        message: "O retorno nao pode ser anterior a saida",
      });
    }
  });

export const machineSchema = z.object({
  name: requiredString.min(2, "Informe o nome da maquina"),
  type: machineTypeSchema,
  brand: requiredString,
  model: z.string().trim().optional(),
  year: z.coerce
    .number()
    .int("Informe um ano valido")
    .min(1900, "Informe um ano valido")
    .max(new Date().getFullYear() + 1, "Informe um ano valido"),
  identifier: z.string().trim().optional(),
  hourMeter: money,
  fuelConsumption: money,
  operationalCost: money,
  status: machineStatusSchema,
  nextMaintenance: optionalDateInput,
  notes: z.string().trim().optional(),
});

export const machineMaintenanceSchema = z.object({
  machineId: requiredString,
  type: maintenanceTypeSchema,
  description: z.string().trim().optional(),
  cost: money,
  performedAt: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
    message: "Informe uma data valida",
  }),
  nextReview: optionalDateInput,
  partsChanged: z.string().trim().optional(),
  responsible: z.string().trim().optional(),
  hourMeter: optionalMoney,
  statusAfterMaintenance: machineStatusSchema.optional(),
  notes: z.string().trim().optional(),
});

export const machineFuelLogSchema = z.object({
  machineId: requiredString,
  date: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
    message: "Informe uma data valida",
  }),
  liters: positive,
  pricePerLiter: positive,
  hourMeter: optionalMoney,
  responsible: z.string().trim().optional(),
  notes: z.string().trim().optional(),
});

export const machineHourMeterSchema = z.object({
  machineId: requiredString,
  newValue: money,
  date: requiredString.refine((value) => !Number.isNaN(new Date(value).getTime()), {
    message: "Informe uma data valida",
  }),
  notes: z.string().trim().optional(),
});

const optionalCoordinates = z
  .string()
  .trim()
  .optional()
  .refine((value) => !value || value.length <= 4000, {
    message: "Informe coordenadas com ate 4000 caracteres",
  });

export const fieldStatusSchema = z.enum(["ATIVO", "EM_PREPARO", "INATIVO", "EM_DESCANSO", "PROBLEMA"]);

export const farmSchema = z.object({
  name: requiredString.min(2, "Informe o nome da fazenda"),
  owner: requiredString.min(2, "Informe o proprietario ou responsavel"),
  city: requiredString.min(2, "Informe a cidade"),
  state: requiredString.min(2, "Informe o estado").max(2, "Use a sigla do estado"),
  totalArea: positive,
  productionType: requiredString.min(2, "Informe o tipo principal de producao"),
  coordinates: optionalCoordinates,
  notes: z.string().trim().optional(),
});

export const fieldSchema = z.object({
  name: requiredString.min(2, "Informe o nome do talhao"),
  area: positive,
  soilType: z.string().trim().optional(),
  currentCrop: z.string().trim().optional(),
  expectedProductivity: optionalMoney,
  status: fieldStatusSchema,
  coordinates: optionalCoordinates,
  notes: z.string().trim().optional(),
});

export type LoginInput = z.input<typeof loginSchema>;
export type LoginValues = z.output<typeof loginSchema>;
export type FarmProfileInput = z.input<typeof farmProfileSchema>;
export type FarmProfileValues = z.output<typeof farmProfileSchema>;
export type FinancialEntryInput = z.input<typeof financialEntrySchema>;
export type FinancialEntryValues = z.output<typeof financialEntrySchema>;
export type TransactionInput = z.input<typeof transactionSchema>;
export type TransactionValues = z.output<typeof transactionSchema>;
export type TransactionTypeValue = z.output<typeof transactionTypeSchema>;
export type CropInput = z.input<typeof cropSchema>;
export type CropValues = z.output<typeof cropSchema>;
export type CropStatusValue = z.output<typeof cropStatusSchema>;
export type StockMovementInput = z.input<typeof stockMovementSchema>;
export type StockMovementValues = z.output<typeof stockMovementSchema>;
export type InventoryCategoryValue = z.output<typeof inventoryCategorySchema>;
export type InventoryUnitValue = z.output<typeof inventoryUnitSchema>;
export type InventoryMovementTypeValue = z.output<typeof inventoryMovementTypeSchema>;
export type InventoryItemInput = z.input<typeof inventoryItemSchema>;
export type InventoryItemValues = z.output<typeof inventoryItemSchema>;
export type InventoryMovementInput = z.input<typeof inventoryMovementSchema>;
export type InventoryMovementValues = z.output<typeof inventoryMovementSchema>;
export type ShipmentInput = z.input<typeof shipmentSchema>;
export type ShipmentValues = z.output<typeof shipmentSchema>;
export type EmployeeStatusValue = z.output<typeof employeeStatusSchema>;
export type AttendanceStatusValue = z.output<typeof attendanceStatusSchema>;
export type TeamAssignmentStatusValue = z.output<typeof teamAssignmentStatusSchema>;
export type EmployeeInput = z.input<typeof employeeSchema>;
export type EmployeeValues = z.output<typeof employeeSchema>;
export type EmployeeAttendanceInput = z.input<typeof employeeAttendanceSchema>;
export type EmployeeAttendanceValues = z.output<typeof employeeAttendanceSchema>;
export type TeamAssignmentInput = z.input<typeof teamAssignmentSchema>;
export type TeamAssignmentValues = z.output<typeof teamAssignmentSchema>;
export type MachineStatusValue = z.output<typeof machineStatusSchema>;
export type MachineTypeValue = z.output<typeof machineTypeSchema>;
export type MaintenanceTypeValue = z.output<typeof maintenanceTypeSchema>;
export type MachineInput = z.input<typeof machineSchema>;
export type MachineValues = z.output<typeof machineSchema>;
export type MachineMaintenanceInput = z.input<typeof machineMaintenanceSchema>;
export type MachineMaintenanceValues = z.output<typeof machineMaintenanceSchema>;
export type MachineFuelLogInput = z.input<typeof machineFuelLogSchema>;
export type MachineFuelLogValues = z.output<typeof machineFuelLogSchema>;
export type MachineHourMeterInput = z.input<typeof machineHourMeterSchema>;
export type MachineHourMeterValues = z.output<typeof machineHourMeterSchema>;
export type FarmInput = z.input<typeof farmSchema>;
export type FarmValues = z.output<typeof farmSchema>;
export type FieldStatusValue = z.output<typeof fieldStatusSchema>;
export type FieldInput = z.input<typeof fieldSchema>;
export type FieldValues = z.output<typeof fieldSchema>;
