import type { Crop, CropStatus } from "@prisma/client";

export type CropRecord = Pick<
  Crop,
  | "id"
  | "name"
  | "variety"
  | "plantedArea"
  | "plantingDate"
  | "expectedHarvestDate"
  | "expectedProduction"
  | "harvestedProduction"
  | "status"
  | "notes"
  | "createdAt"
  | "updatedAt"
>;

export type SerializedCrop = Omit<
  CropRecord,
  "plantingDate" | "expectedHarvestDate" | "createdAt" | "updatedAt"
> & {
  plantingDate: string;
  expectedHarvestDate: string;
  createdAt: string;
  updatedAt: string;
};

type ProductionSummaryCrop = Pick<
  CropRecord | SerializedCrop,
  "status" | "plantedArea" | "expectedProduction" | "harvestedProduction"
>;

export const cropStatusLabels: Record<CropStatus, string> = {
  PLANTADO: "Plantado",
  EM_CRESCIMENTO: "Em crescimento",
  COLHIDO: "Colhido",
  CANCELADO: "Cancelado",
};

const activeStatuses = new Set<CropStatus>(["PLANTADO", "EM_CRESCIMENTO"]);

function finite(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) ? value : 0;
}

export function calculateActiveCrops(crops: Pick<CropRecord, "status">[]) {
  return crops.filter((crop) => activeStatuses.has(crop.status)).length;
}

export function calculateTotalPlantedArea(crops: Pick<CropRecord, "plantedArea">[]) {
  return crops.reduce((total, crop) => total + finite(crop.plantedArea), 0);
}

export function calculateExpectedProduction(crops: Pick<CropRecord, "expectedProduction">[]) {
  return crops.reduce((total, crop) => total + finite(crop.expectedProduction), 0);
}

export function calculateHarvestedProduction(crops: Pick<CropRecord, "harvestedProduction">[]) {
  return crops.reduce((total, crop) => total + finite(crop.harvestedProduction), 0);
}

export function calculateSeasonProgress(expectedProduction: number, harvestedProduction: number) {
  if (!Number.isFinite(expectedProduction) || expectedProduction <= 0) {
    return 0;
  }

  return Math.min(harvestedProduction / expectedProduction, 1);
}

export function calculateExpectedYieldPerHectare({
  expectedProduction,
  plantedArea,
}: Pick<CropRecord, "expectedProduction" | "plantedArea">) {
  if (!Number.isFinite(plantedArea) || plantedArea <= 0) {
    return null;
  }

  return expectedProduction / plantedArea;
}

export function calculateHarvestedYieldPerHectare({
  harvestedProduction,
  plantedArea,
}: Pick<CropRecord, "harvestedProduction" | "plantedArea">) {
  if (!Number.isFinite(plantedArea) || plantedArea <= 0) {
    return null;
  }

  return harvestedProduction / plantedArea;
}

export function calculateDaysUntilHarvest(expectedHarvestDate: Date | string, from = new Date()) {
  const harvest = new Date(expectedHarvestDate);

  if (Number.isNaN(harvest.getTime())) {
    return null;
  }

  const start = new Date(from.getFullYear(), from.getMonth(), from.getDate()).getTime();
  const end = new Date(harvest.getFullYear(), harvest.getMonth(), harvest.getDate()).getTime();

  return Math.ceil((end - start) / (1000 * 60 * 60 * 24));
}

export function buildProductionSummary(crops: ProductionSummaryCrop[]) {
  const expectedProduction = calculateExpectedProduction(crops);
  const harvestedProduction = calculateHarvestedProduction(crops);

  return {
    activeCrops: calculateActiveCrops(crops),
    plantedArea: calculateTotalPlantedArea(crops),
    expectedProduction,
    harvestedProduction,
    seasonProgress: calculateSeasonProgress(expectedProduction, harvestedProduction),
  };
}

export function buildProductionChartData(crops: CropRecord[] | SerializedCrop[]) {
  return crops.map((crop) => ({
    name: crop.variety ? `${crop.name} ${crop.variety}` : crop.name,
    esperado: finite(crop.expectedProduction),
    colhido: finite(crop.harvestedProduction),
  }));
}
