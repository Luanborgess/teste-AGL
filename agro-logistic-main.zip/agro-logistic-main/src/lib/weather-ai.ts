import type { WeatherRiskLevel } from "@prisma/client";
import { generateLocalWeatherRecommendations } from "@/lib/weather-calculations";
import type { NormalizedWeather, WeatherAiRecommendations } from "@/lib/weather-types";

type AiPayload = Omit<WeatherAiRecommendations, "advancedAiActive">;

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string" && item.trim().length > 0) : [];
}

function normalizeRisk(value: unknown, fallback: WeatherRiskLevel): WeatherRiskLevel {
  return value === "BAIXO" || value === "MEDIO" || value === "ALTO" ? value : fallback;
}

function normalizeAiPayload(value: unknown, fallback: WeatherAiRecommendations): WeatherAiRecommendations | null {
  if (!value || typeof value !== "object") {
    return null;
  }

  const payload = value as Record<string, unknown>;

  return {
    resumo: typeof payload.resumo === "string" ? payload.resumo : fallback.resumo,
    nivelRisco: normalizeRisk(payload.nivelRisco, fallback.nivelRisco),
    recomendacoesProducao: asStringArray(payload.recomendacoesProducao),
    recomendacoesEstoque: asStringArray(payload.recomendacoesEstoque),
    recomendacoesLogistica: asStringArray(payload.recomendacoesLogistica),
    recomendacoesMaquinario: asStringArray(payload.recomendacoesMaquinario),
    recomendacoesEquipe: asStringArray(payload.recomendacoesEquipe),
    alertasCriticos: asStringArray(payload.alertasCriticos),
    melhorJanelaOperacional:
      typeof payload.melhorJanelaOperacional === "string" ? payload.melhorJanelaOperacional : fallback.melhorJanelaOperacional,
    advancedAiActive: true,
  };
}

function extractJson(text: string) {
  const trimmed = text.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  return fenced?.[1] ?? trimmed;
}

async function analyzeWithOpenAi(weather: NormalizedWeather, fallback: WeatherAiRecommendations): Promise<WeatherAiRecommendations | null> {
  const apiKey = process.env.AI_API_KEY;
  const model = process.env.AI_MODEL || "gpt-4o-mini";

  if (!apiKey) {
    return null;
  }

  const input = {
    fazenda: weather.farm,
    localizacao: weather.location,
    climaAtual: weather.current,
    previsao: weather.forecast,
    alertasCalculados: weather.alerts,
    indiceAgroClimatico: weather.agroScore,
    riscoCalculado: weather.riskLevel,
    melhorJanelaCalculada: weather.bestOperationalWindow,
  };

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "Voce e um consultor agricola. Analise somente os dados climaticos recebidos. Nao invente previsao, valores, alertas ou datas. Responda em JSON valido.",
        },
        {
          role: "user",
          content: `Gere recomendacoes agricolas para o AgroLogistic neste formato JSON, usando nivelRisco apenas como BAIXO, MEDIO ou ALTO: ${JSON.stringify({
            resumo: "string",
            nivelRisco: "BAIXO",
            recomendacoesProducao: ["string"],
            recomendacoesEstoque: ["string"],
            recomendacoesLogistica: ["string"],
            recomendacoesMaquinario: ["string"],
            recomendacoesEquipe: ["string"],
            alertasCriticos: ["string"],
            melhorJanelaOperacional: "string",
          } satisfies AiPayload)}\n\nDados reais recebidos da API e do banco:\n${JSON.stringify(input)}`,
        },
      ],
    }),
  });

  if (!response.ok) {
    return null;
  }

  const payload = (await response.json().catch(() => null)) as { choices?: { message?: { content?: string } }[] } | null;
  const content = payload?.choices?.[0]?.message?.content;

  if (!content) {
    return null;
  }

  const parsed = JSON.parse(extractJson(content)) as unknown;
  const normalized = normalizeAiPayload(parsed, fallback);

  if (!normalized) {
    return null;
  }

  return {
    ...normalized,
    recomendacoesProducao: normalized.recomendacoesProducao.length ? normalized.recomendacoesProducao : fallback.recomendacoesProducao,
    recomendacoesEstoque: normalized.recomendacoesEstoque.length ? normalized.recomendacoesEstoque : fallback.recomendacoesEstoque,
    recomendacoesLogistica: normalized.recomendacoesLogistica.length ? normalized.recomendacoesLogistica : fallback.recomendacoesLogistica,
    recomendacoesMaquinario: normalized.recomendacoesMaquinario.length ? normalized.recomendacoesMaquinario : fallback.recomendacoesMaquinario,
    recomendacoesEquipe: normalized.recomendacoesEquipe.length ? normalized.recomendacoesEquipe : fallback.recomendacoesEquipe,
  };
}

export async function analyzeWeatherRecommendations(weather: NormalizedWeather) {
  const fallback = generateLocalWeatherRecommendations(weather);
  const provider = process.env.AI_PROVIDER?.toLocaleLowerCase("pt-BR");

  if (provider === "openai") {
    try {
      const advanced = await analyzeWithOpenAi(weather, fallback);

      if (advanced) {
        return {
          recommendations: advanced,
          source: "openai" as const,
          warning: null,
        };
      }
    } catch {
      return {
        recommendations: fallback,
        source: "fallback" as const,
        warning: "A avaliação avançada por IA falhou. Recomendações locais continuam ativas.",
      };
    }
  }

  return {
    recommendations: fallback,
    source: "fallback" as const,
    warning: "Avaliação avançada por IA não está ativa. Usando regras locais determinísticas.",
  };
}
