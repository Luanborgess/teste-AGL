import type { MachineStatusValue, MachineTypeValue, MaintenanceTypeValue } from "@/lib/validations";

export type SerializedMachineMaintenance = {
  id: string;
  machineId: string;
  machineName: string;
  type: MaintenanceTypeValue;
  description: string | null;
  cost: number;
  performedAt: string;
  nextReview: string | null;
  partsChanged: string | null;
  responsible: string | null;
  hourMeter: number | null;
  notes: string | null;
  createdAt: string;
};

export type SerializedMachineFuelLog = {
  id: string;
  machineId: string;
  machineName: string;
  date: string;
  liters: number;
  pricePerLiter: number;
  totalCost: number;
  hourMeter: number | null;
  responsible: string | null;
  notes: string | null;
  createdAt: string;
};

export type SerializedMachineHourMeterLog = {
  id: string;
  machineId: string;
  machineName: string;
  previousValue: number;
  newValue: number;
  date: string;
  notes: string | null;
  createdAt: string;
};

export type SerializedMachine = {
  id: string;
  name: string;
  type: MachineTypeValue;
  brand: string;
  model: string | null;
  year: number;
  identifier: string | null;
  hourMeter: number;
  fuelConsumption: number;
  operationalCost: number;
  nextMaintenance: string | null;
  status: MachineStatusValue;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  maintenances: SerializedMachineMaintenance[];
  fuelLogs: SerializedMachineFuelLog[];
  hourMeterLogs: SerializedMachineHourMeterLog[];
};

export type MachineMaintenanceAlert = {
  machine: SerializedMachine;
  status: "VENCIDA" | "PROXIMA";
  daysUntil: number;
};

export const machineStatusLabels: Record<MachineStatusValue, string> = {
  OPERACIONAL: "Operacional",
  MANUTENCAO: "Manutencao",
  EM_REPARO: "Em reparo",
  PARADA: "Parada",
  VENDIDA: "Vendida",
};

export const machineTypeLabels: Record<MachineTypeValue, string> = {
  TRATOR: "Trator",
  COLHEITADEIRA: "Colheitadeira",
  PULVERIZADOR: "Pulverizador",
  PLANTADEIRA: "Plantadeira",
  CAMINHAO: "Caminhao",
  CARRETA: "Carreta",
  PA_CARREGADEIRA: "Pa/carregadeira",
  IMPLEMENTO: "Implemento agricola",
  IRRIGACAO: "Irrigacao",
  VEICULO_APOIO: "Veiculo de apoio",
  OUTRO: "Outro equipamento",
};

export const maintenanceTypeLabels: Record<MaintenanceTypeValue, string> = {
  PREVENTIVA: "Preventiva",
  CORRETIVA: "Corretiva",
  REVISAO: "Revisao",
  TROCA_OLEO: "Troca de oleo",
  TROCA_PECA: "Troca de peca",
  REPARO_EMERGENCIAL: "Reparo emergencial",
  OUTRO: "Outro",
};

export function startOfToday() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return today;
}

export function daysBetween(from: Date, to: Date) {
  const oneDay = 24 * 60 * 60 * 1000;
  return Math.ceil((to.getTime() - from.getTime()) / oneDay);
}

export function buildMachineMaintenanceAlerts(machines: SerializedMachine[]) {
  const today = startOfToday();

  return machines
    .filter((machine) => Boolean(machine.nextMaintenance))
    .map((machine) => {
      const nextMaintenance = new Date(machine.nextMaintenance as string);
      nextMaintenance.setHours(0, 0, 0, 0);
      const daysUntil = daysBetween(today, nextMaintenance);

      if (daysUntil < 0) {
        return { machine, status: "VENCIDA" as const, daysUntil };
      }

      if (daysUntil <= 15) {
        return { machine, status: "PROXIMA" as const, daysUntil };
      }

      return null;
    })
    .filter((alert): alert is MachineMaintenanceAlert => Boolean(alert))
    .sort((a, b) => a.daysUntil - b.daysUntil);
}

export function calculateMachineMaintenanceCost(machine: SerializedMachine) {
  return machine.maintenances.reduce((total, maintenance) => total + maintenance.cost, 0);
}

export function calculateMachineFuelCost(machine: SerializedMachine) {
  return machine.fuelLogs.reduce((total, fuelLog) => total + fuelLog.totalCost, 0);
}

export function calculateMachineCostPerHour(machine: SerializedMachine) {
  const totalCost = calculateMachineMaintenanceCost(machine) + calculateMachineFuelCost(machine);

  if (machine.hourMeter <= 0 || totalCost <= 0) {
    return 0;
  }

  return totalCost / machine.hourMeter;
}

export function buildMachineSummary(machines: SerializedMachine[]) {
  const alerts = buildMachineMaintenanceAlerts(machines);
  const maintenanceCost = machines.reduce((total, machine) => total + calculateMachineMaintenanceCost(machine), 0);
  const fuelCost = machines.reduce((total, machine) => total + calculateMachineFuelCost(machine), 0);
  const averageConsumption =
    machines.length > 0
      ? machines.reduce((total, machine) => total + machine.fuelConsumption, 0) / machines.length
      : 0;

  return {
    totalMachines: machines.length,
    operational: machines.filter((machine) => machine.status === "OPERACIONAL").length,
    inMaintenance: machines.filter((machine) => machine.status === "MANUTENCAO" || machine.status === "EM_REPARO")
      .length,
    maintenanceAlerts: alerts.length,
    overdueMaintenances: alerts.filter((alert) => alert.status === "VENCIDA").length,
    upcomingMaintenances: alerts.filter((alert) => alert.status === "PROXIMA").length,
    maintenanceCost,
    fuelCost,
    averageConsumption,
    operationalCostTotal: machines.reduce((total, machine) => total + machine.operationalCost, 0),
  };
}

export function formatMachineStatusLabel(status: MachineStatusValue) {
  return machineStatusLabels[status];
}

export function formatMachineTypeLabel(type: MachineTypeValue) {
  return machineTypeLabels[type];
}

export function formatMaintenanceTypeLabel(type: MaintenanceTypeValue) {
  return maintenanceTypeLabels[type];
}
