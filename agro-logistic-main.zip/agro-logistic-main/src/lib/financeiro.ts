import type { TransactionTypeValue } from "@/lib/validations";

export type FinancialTransaction = {
  id: string;
  description: string;
  amount: number;
  category: string;
  type: TransactionTypeValue;
  notes: string | null;
  date: Date | string;
  createdAt?: Date | string;
  updatedAt?: Date | string;
};

export type FinancialTotals = {
  revenue: number;
  expenses: number;
  investments: number;
  netProfit: number;
};

export type MonthlyFinancialData = {
  month: string;
  receita: number;
  despesa: number;
  investimento: number;
};

export const transactionTypeLabels: Record<TransactionTypeValue, string> = {
  RECEITA: "Receita",
  DESPESA: "Despesa",
  INVESTIMENTO: "Investimento",
};

const monthLabels = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

export function calculateFinancialTotals(transactions: FinancialTransaction[]): FinancialTotals {
  const totals = transactions.reduce(
    (acc, transaction) => {
      if (transaction.type === "RECEITA") {
        acc.revenue += transaction.amount;
      }

      if (transaction.type === "DESPESA") {
        acc.expenses += transaction.amount;
      }

      if (transaction.type === "INVESTIMENTO") {
        acc.investments += transaction.amount;
      }

      return acc;
    },
    { revenue: 0, expenses: 0, investments: 0, netProfit: 0 },
  );

  // Lucro liquido operacional: investimentos ficam destacados separadamente e nao abatem o lucro.
  totals.netProfit = totals.revenue - totals.expenses;

  return totals;
}

export function groupTransactionsByMonth(transactions: FinancialTransaction[]): MonthlyFinancialData[] {
  const monthly = monthLabels.map((month) => ({
    month,
    receita: 0,
    despesa: 0,
    investimento: 0,
  }));

  transactions.forEach((transaction) => {
    const date = new Date(transaction.date);

    if (Number.isNaN(date.getTime())) {
      return;
    }

    const bucket = monthly[date.getMonth()];

    if (transaction.type === "RECEITA") {
      bucket.receita += transaction.amount;
    }

    if (transaction.type === "DESPESA") {
      bucket.despesa += transaction.amount;
    }

    if (transaction.type === "INVESTIMENTO") {
      bucket.investimento += transaction.amount;
    }
  });

  return monthly;
}

export function buildFinancialChartData(transactions: FinancialTransaction[]) {
  return groupTransactionsByMonth(transactions);
}

export function getTransactionCategories(transactions: FinancialTransaction[]) {
  return Array.from(new Set(transactions.map((transaction) => transaction.category).filter(Boolean))).sort(
    (a, b) => a.localeCompare(b, "pt-BR"),
  );
}
