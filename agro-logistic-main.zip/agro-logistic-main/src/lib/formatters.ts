export const insufficientData = "Dados insuficientes. Complete seu perfil operacional.";

export const brlFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  maximumFractionDigits: 2,
});

export const numberFormatter = new Intl.NumberFormat("pt-BR", {
  maximumFractionDigits: 2,
});

export const integerFormatter = new Intl.NumberFormat("pt-BR", {
  maximumFractionDigits: 0,
});

export function formatCurrency(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value)
    ? brlFormatter.format(value)
    : insufficientData;
}

export function formatCurrencyBRL(value: number | null | undefined) {
  return formatCurrency(value);
}

export function formatNumber(value: number | null | undefined, suffix = "") {
  return typeof value === "number" && Number.isFinite(value)
    ? `${numberFormatter.format(value)}${suffix}`
    : insufficientData;
}

export function formatInteger(value: number | null | undefined, suffix = "") {
  return typeof value === "number" && Number.isFinite(value)
    ? `${integerFormatter.format(Math.ceil(value))}${suffix}`
    : insufficientData;
}

export function formatPercent(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value)
    ? `${new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 }).format(value * 100)}%`
    : insufficientData;
}

export function formatPercentage(value: number | null | undefined) {
  return formatPercent(value);
}

export function formatHectares(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value)
    ? `${numberFormatter.format(value)} ha`
    : insufficientData;
}

export function formatProductivity(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value)
    ? `${numberFormatter.format(value)} sacas/ha`
    : insufficientData;
}

export function formatCoordinates(value: string | null | undefined) {
  if (!value) {
    return "Nao informado";
  }

  return value.length > 42 ? `${value.slice(0, 42)}...` : value;
}

export function formatDate(value: Date | string) {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(new Date(value));
}

export function formatDateBR(value: Date | string) {
  return formatDate(value);
}

export function formatDateTimeBR(value: Date | string) {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
}

export function formatTemperature(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) ? `${numberFormatter.format(value)} °C` : insufficientData;
}

export function formatRain(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) ? `${numberFormatter.format(value)} mm` : insufficientData;
}

export function formatWind(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) ? `${numberFormatter.format(value)} km/h` : insufficientData;
}

export function formatHumidity(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) ? `${numberFormatter.format(value)}%` : insufficientData;
}

export function formatWeatherCondition(value: string | null | undefined) {
  return value?.trim() || insufficientData;
}

export function formatRiskLevel(value: string | null | undefined) {
  if (value === "MEDIO") {
    return "Médio";
  }

  if (value === "ALTO") {
    return "Alto";
  }

  if (value === "BAIXO") {
    return "Baixo";
  }

  return insufficientData;
}

export function formatHours(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) ? `${numberFormatter.format(value)} h` : insufficientData;
}

export function formatLiters(value: number | null | undefined) {
  return typeof value === "number" && Number.isFinite(value) ? `${numberFormatter.format(value)} L` : insufficientData;
}

export function parseCurrencyInput(value: string | number) {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : 0;
  }

  const normalized = value
    .replace(/\s/g, "")
    .replace("R$", "")
    .replace(/\./g, "")
    .replace(",", ".");

  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
}

export function onlyDigits(value: string) {
  return value.replace(/\D/g, "");
}

export function formatCPF(value: string | null | undefined) {
  const digits = onlyDigits(value ?? "").slice(0, 11);

  if (digits.length <= 3) {
    return digits;
  }

  if (digits.length <= 6) {
    return `${digits.slice(0, 3)}.${digits.slice(3)}`;
  }

  if (digits.length <= 9) {
    return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
  }

  return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
}

export function formatPhoneBR(value: string | null | undefined) {
  const digits = onlyDigits(value ?? "").slice(0, 11);

  if (digits.length <= 2) {
    return digits ? `(${digits}` : "";
  }

  if (digits.length <= 6) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  }

  if (digits.length <= 10) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  }

  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

export function getInitials(value: string) {
  const names = value
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (names.length === 0) {
    return "--";
  }

  const first = names[0]?.[0] ?? "";
  const last = names.length > 1 ? names[names.length - 1]?.[0] ?? "" : names[0]?.[1] ?? "";

  return `${first}${last}`.toLocaleUpperCase("pt-BR");
}
