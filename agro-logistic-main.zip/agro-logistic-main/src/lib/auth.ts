import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { getPrisma } from "@/lib/prisma";

const authCookie = "agrologistic_user";

export async function setSession(userId: string) {
  const cookieStore = await cookies();

  cookieStore.set(authCookie, userId, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function getCurrentUser() {
  const cookieStore = await cookies();
  const userId = cookieStore.get(authCookie)?.value;

  if (!userId) {
    return null;
  }

  return getPrisma().user.findUnique({
    where: { id: userId },
    include: {
      farmProfile: true,
      financialEntries: { orderBy: { date: "desc" } },
      stockMovements: { orderBy: { date: "desc" } },
      shipments: { orderBy: { date: "desc" } },
    },
  });
}

export async function requireUser() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  return user;
}

export async function requireProfile() {
  const user = await requireUser();

  if (!user.farmProfile) {
    redirect("/onboarding");
  }

  return user;
}
