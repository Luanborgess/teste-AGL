import type {
  InventoryCategoryValue,
  InventoryMovementTypeValue,
  InventoryUnitValue,
} from "@/lib/validations";

export type InventorySituation = "OK" | "BAIXO_ESTOQUE" | "CRITICO" | "VENCENDO" | "VENCIDO";

export type SerializedInventoryMovement = {
  id: string;
  itemId: string;
  itemName: string;
  itemUnit: string;
  type: InventoryMovementTypeValue;
  quantity: number;
  unitCost: number | null;
  responsible: string | null;
  originOrDestination: string | null;
  reason: string | null;
  notes: string | null;
  balanceAfter: number | null;
  occurredAt: string;
  createdAt: string;
};

export type SerializedInventoryItem = {
  id: string;
  name: string;
  category: InventoryCategoryValue;
  unit: InventoryUnitValue;
  quantity: number;
  minimumStock: number;
  unitCost: number;
  supplier: string | null;
  expirationDate: string | null;
  location: string | null;
  sku: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  movements: SerializedInventoryMovement[];
};

export type InventoryAlert = {
  id: string;
  itemId: string;
  title: string;
  description: string;
  type: "critical" | "warning" | "expired" | "idle" | "consumption";
};

export const inventoryCategoryLabels: Record<InventoryCategoryValue, string> = {
  SEMENTES: "Sementes",
  FERTILIZANTES: "Fertilizantes",
  DEFENSIVOS: "Defensivos",
  COMBUSTIVEIS: "Combustiveis",
  LUBRIFICANTES: "Lubrificantes",
  PECAS: "Pecas",
  EQUIPAMENTOS: "Equipamentos",
  FERRAMENTAS: "Ferramentas",
  EPIS: "EPIs",
  EMBALAGENS: "Embalagens",
  PRODUCAO_COLHIDA: "Producao Colhida",
  OUTROS: "Outros",
};

export const inventoryUnitLabels: Record<InventoryUnitValue, string> = {
  sacas: "sacas",
  kg: "kg",
  toneladas: "toneladas",
  litros: "litros",
  unidades: "unidades",
  caixas: "caixas",
  galoes: "galoes",
  metros: "metros",
  "hectares tratados": "hectares tratados",
  outros: "outros",
};

export const inventorySituationLabels: Record<InventorySituation, string> = {
  OK: "OK",
  BAIXO_ESTOQUE: "Baixo Estoque",
  CRITICO: "Critico",
  VENCENDO: "Vencendo",
  VENCIDO: "Vencido",
};

export const inventoryMovementTypeLabels: Record<InventoryMovementTypeValue, string> = {
  ENTRADA: "Entrada",
  SAIDA: "Saida",
  CONSUMO: "Consumo",
  PERDA: "Perda",
  AJUSTE: "Ajuste",
};

export function getDaysUntil(date: string | Date, now = new Date()) {
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  const target = new Date(date);
  target.setHours(0, 0, 0, 0);

  return Math.ceil((target.getTime() - start.getTime()) / 86_400_000);
}

export function calculateInventorySituation(item: SerializedInventoryItem, now = new Date()): InventorySituation {
  if (item.expirationDate) {
    const daysUntilExpiration = getDaysUntil(item.expirationDate, now);

    if (daysUntilExpiration < 0) {
      return "VENCIDO";
    }

    if (daysUntilExpiration <= 30) {
      return "VENCENDO";
    }
  }

  if (item.quantity <= item.minimumStock) {
    return "CRITICO";
  }

  if (item.quantity <= item.minimumStock * 1.25) {
    return "BAIXO_ESTOQUE";
  }

  return "OK";
}

export function calculateInventoryValue(item: Pick<SerializedInventoryItem, "quantity" | "unitCost">) {
  return item.quantity * item.unitCost;
}

export function calculateNextBalance(currentQuantity: number, type: InventoryMovementTypeValue, quantity: number) {
  if (type === "ENTRADA") {
    return currentQuantity + quantity;
  }

  if (type === "AJUSTE") {
    return quantity;
  }

  return currentQuantity - quantity;
}

export function buildInventorySummary(
  items: SerializedInventoryItem[],
  movements: SerializedInventoryMovement[],
  now = new Date(),
) {
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  return {
    totalItems: items.length,
    stockAlerts: items.filter((item) => {
      const situation = calculateInventorySituation(item, now);
      return situation === "BAIXO_ESTOQUE" || situation === "CRITICO";
    }).length,
    totalValue: items.reduce((total, item) => total + calculateInventoryValue(item), 0),
    expiringItems: items.filter((item) => {
      if (!item.expirationDate) {
        return false;
      }

      const days = getDaysUntil(item.expirationDate, now);
      return days >= 0 && days <= 30;
    }).length,
    monthlyMovements: movements.filter((movement) => {
      const date = new Date(movement.occurredAt);
      return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
    }).length,
  };
}

export function buildInventoryAlerts(
  items: SerializedInventoryItem[],
  movements: SerializedInventoryMovement[],
  now = new Date(),
) {
  const alerts: InventoryAlert[] = [];
  const ninetyDaysAgo = new Date(now);
  ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
  const thirtyDaysAgo = new Date(now);
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  for (const item of items) {
    const situation = calculateInventorySituation(item, now);

    if (situation === "CRITICO") {
      alerts.push({
        id: `${item.id}-critical`,
        itemId: item.id,
        title: "Estoque critico",
        description: `${item.name} esta com ${item.quantity} ${item.unit}.`,
        type: "critical",
      });
    } else if (situation === "BAIXO_ESTOQUE") {
      alerts.push({
        id: `${item.id}-low`,
        itemId: item.id,
        title: "Estoque baixo",
        description: `${item.name} esta proximo do minimo cadastrado.`,
        type: "warning",
      });
    } else if (situation === "VENCIDO") {
      alerts.push({
        id: `${item.id}-expired`,
        itemId: item.id,
        title: "Produto vencido",
        description: `${item.name} passou da validade cadastrada.`,
        type: "expired",
      });
    } else if (situation === "VENCENDO") {
      alerts.push({
        id: `${item.id}-expiring`,
        itemId: item.id,
        title: "Produto vencendo",
        description: `${item.name} vence nos proximos 30 dias.`,
        type: "warning",
      });
    }

    const itemMovements = movements.filter((movement) => movement.itemId === item.id);
    const recentConsumption = itemMovements
      .filter((movement) => {
        const date = new Date(movement.occurredAt);
        return ["SAIDA", "CONSUMO", "PERDA"].includes(movement.type) && date >= thirtyDaysAgo;
      })
      .reduce((total, movement) => total + movement.quantity, 0);

    if (item.minimumStock > 0 && recentConsumption > item.minimumStock * 2) {
      alerts.push({
        id: `${item.id}-consumption`,
        itemId: item.id,
        title: "Alto consumo recente",
        description: `${item.name} teve consumo/saida/perda acima de 2x o estoque minimo em 30 dias.`,
        type: "consumption",
      });
    }

    const lastMovement = itemMovements
      .map((movement) => new Date(movement.occurredAt))
      .sort((a, b) => b.getTime() - a.getTime())[0];

    if (itemMovements.length > 0 && lastMovement < ninetyDaysAgo) {
      alerts.push({
        id: `${item.id}-idle`,
        itemId: item.id,
        title: "Sem movimentacao recente",
        description: `${item.name} nao tem movimentacao ha mais de 90 dias.`,
        type: "idle",
      });
    }
  }

  return alerts;
}

export function formatCategoryLabel(category: InventoryCategoryValue) {
  return inventoryCategoryLabels[category];
}

export function formatMovementTypeLabel(type: InventoryMovementTypeValue) {
  return inventoryMovementTypeLabels[type];
}

export function formatQuantity(value: number, unit?: string | null) {
  const formatted = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(value);
  return unit ? `${formatted} ${unit}` : formatted;
}
