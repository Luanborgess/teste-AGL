import { Prisma } from "@prisma/client";
import { getPrisma } from "@/lib/prisma";
import { normalizeWeatherApiResponse } from "@/lib/weather-calculations";
import type { FarmWeatherContext, WeatherApiResponse, WeatherLocation } from "@/lib/weather-types";

const provider = "open-meteo";
const cacheMinutes = 60;
const defaultForecastApiUrl = "https://api.open-meteo.com/v1/forecast";
const geocodingApiUrl = "https://geocoding-api.open-meteo.com/v1/search";
const brazilStateNames: Record<string, string> = {
  AC: "acre",
  AL: "alagoas",
  AP: "amapa",
  AM: "amazonas",
  BA: "bahia",
  CE: "ceara",
  DF: "distrito federal",
  ES: "espirito santo",
  GO: "goias",
  MA: "maranhao",
  MT: "mato grosso",
  MS: "mato grosso do sul",
  MG: "minas gerais",
  PA: "para",
  PB: "paraiba",
  PR: "parana",
  PE: "pernambuco",
  PI: "piaui",
  RJ: "rio de janeiro",
  RN: "rio grande do norte",
  RS: "rio grande do sul",
  RO: "rondonia",
  RR: "roraima",
  SC: "santa catarina",
  SP: "sao paulo",
  SE: "sergipe",
  TO: "tocantins",
};

type Coordinate = {
  latitude: number;
  longitude: number;
};

type OpenMeteoGeocodingResponse = {
  results?: {
    name?: string;
    admin1?: string;
    country_code?: string;
    latitude?: number;
    longitude?: number;
  }[];
};

type OpenMeteoRawResponse = {
  latitude?: number;
  longitude?: number;
  current?: Record<string, unknown>;
  daily?: Record<string, unknown[]>;
  hourly?: Record<string, unknown[]>;
  timezone?: string;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function parseCoordinates(value: string | null | undefined): Coordinate | null {
  if (!value) {
    return null;
  }

  const directMatch = value.match(/-?\d+(?:[.,]\d+)?\s*[,; ]\s*-?\d+(?:[.,]\d+)?/);
  if (!directMatch) {
    return null;
  }

  const parts = directMatch[0]
    .split(/[,; ]+/)
    .map((part) => Number(part.replace(",", ".")))
    .filter((part) => Number.isFinite(part));

  if (parts.length < 2) {
    return null;
  }

  const [latitude, longitude] = parts;

  if (Math.abs(latitude) > 90 || Math.abs(longitude) > 180) {
    return null;
  }

  return { latitude, longitude };
}

async function geocodeFarm(city: string, state: string): Promise<Coordinate | null> {
  const url = new URL(geocodingApiUrl);
  url.searchParams.set("name", city);
  url.searchParams.set("count", "5");
  url.searchParams.set("language", "pt");
  url.searchParams.set("format", "json");
  url.searchParams.set("country_code", "BR");

  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) {
    return null;
  }

  const payload = (await response.json().catch(() => null)) as OpenMeteoGeocodingResponse | null;
  const normalizedState = state.trim().toLocaleUpperCase("pt-BR");
  const stateName = brazilStateNames[normalizedState] ?? normalizedState.toLocaleLowerCase("pt-BR");
  const match =
    payload?.results?.find((result) => result.country_code === "BR" && result.admin1?.toLocaleLowerCase("pt-BR").normalize("NFD").replace(/[\u0300-\u036f]/g, "").includes(stateName)) ??
    payload?.results?.find((result) => result.country_code === "BR") ??
    payload?.results?.[0];

  if (typeof match?.latitude !== "number" || typeof match.longitude !== "number") {
    return null;
  }

  return { latitude: match.latitude, longitude: match.longitude };
}

async function resolveLocation(farm: FarmWeatherContext): Promise<WeatherLocation | null> {
  const farmCoordinates = parseCoordinates(farm.coordinates);

  if (farmCoordinates) {
    return {
      ...farmCoordinates,
      label: `${farm.name} (${farm.city}/${farm.state})`,
      city: farm.city,
      state: farm.state,
      source: "farm_coordinates",
    };
  }

  if (farm.city && farm.state) {
    const geocoded = await geocodeFarm(farm.city, farm.state);

    if (geocoded) {
      return {
        ...geocoded,
        label: `${farm.city}/${farm.state}`,
        city: farm.city,
        state: farm.state,
        source: "farm_city_state",
      };
    }
  }

  const fieldWithCoordinates = farm.fields.find((field) => parseCoordinates(field.coordinates));
  const fieldCoordinates = parseCoordinates(fieldWithCoordinates?.coordinates);

  if (fieldWithCoordinates && fieldCoordinates) {
    return {
      ...fieldCoordinates,
      label: `${fieldWithCoordinates.name} (${farm.name})`,
      city: farm.city,
      state: farm.state,
      source: "field_coordinates",
    };
  }

  return null;
}

function getForecastUrl(location: WeatherLocation) {
  const url = new URL(process.env.WEATHER_API_URL || defaultForecastApiUrl);
  url.searchParams.set("latitude", String(location.latitude));
  url.searchParams.set("longitude", String(location.longitude));
  url.searchParams.set(
    "current",
    "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_gusts_10m",
  );
  url.searchParams.set(
    "daily",
    "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,rain_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,uv_index_max",
  );
  url.searchParams.set("hourly", "relative_humidity_2m");
  url.searchParams.set("forecast_days", "7");
  url.searchParams.set("timezone", "America/Bahia");
  url.searchParams.set("wind_speed_unit", "kmh");
  url.searchParams.set("precipitation_unit", "mm");
  url.searchParams.set("temperature_unit", "celsius");

  return url;
}

function addDailyHumidity(raw: OpenMeteoRawResponse): OpenMeteoRawResponse {
  const dailyDates = raw.daily?.time;
  const hourlyTimes = raw.hourly?.time;
  const hourlyHumidity = raw.hourly?.relative_humidity_2m;

  if (!dailyDates || !hourlyTimes || !hourlyHumidity) {
    return raw;
  }

  const humidityMean = dailyDates.map((day) => {
    const values = hourlyTimes
      .map((time, index) => ({ time: typeof time === "string" ? time : "", value: hourlyHumidity[index] }))
      .filter((item) => item.time.startsWith(`${day}`) && typeof item.value === "number")
      .map((item) => item.value as number);

    if (values.length === 0) {
      return null;
    }

    return Math.round(values.reduce((total, value) => total + value, 0) / values.length);
  });

  return {
    ...raw,
    daily: {
      ...raw.daily,
      relative_humidity_2m_mean: humidityMean,
    },
  };
}

async function fetchOpenMeteoWeather(location: WeatherLocation): Promise<OpenMeteoRawResponse> {
  const response = await fetch(getForecastUrl(location), { cache: "no-store" });

  if (!response.ok) {
    const payload = await response.text().catch(() => "");
    throw new Error(payload || "Open-Meteo não retornou a previsão climática.");
  }

  const payload = (await response.json()) as OpenMeteoRawResponse;
  return addDailyHumidity(payload);
}

async function getFarmContext(userId: string): Promise<FarmWeatherContext | null> {
  const farm = await getPrisma().farm.findUnique({
    where: { userId },
    include: {
      fields: {
        orderBy: { name: "asc" },
        select: {
          id: true,
          name: true,
          area: true,
          currentCrop: true,
          coordinates: true,
        },
      },
    },
  });

  if (!farm) {
    return null;
  }

  return {
    id: farm.id,
    name: farm.name,
    city: farm.city,
    state: farm.state,
    productionType: farm.productionType,
    totalArea: farm.totalArea,
    coordinates: farm.coordinates,
    fields: farm.fields,
  };
}

async function getCachedSnapshot(userId: string, farmId: string) {
  const cutoff = new Date(Date.now() - cacheMinutes * 60 * 1000);

  return getPrisma().weatherSnapshot.findFirst({
    where: {
      userId,
      farmId,
      provider,
      fetchedAt: { gte: cutoff },
    },
    orderBy: { fetchedAt: "desc" },
  });
}

function rawDataFromSnapshot(rawData: Prisma.JsonValue): OpenMeteoRawResponse | null {
  if (!isRecord(rawData)) {
    return null;
  }

  return rawData as OpenMeteoRawResponse;
}

export async function getWeatherForUser(userId: string, forceRefresh = false): Promise<WeatherApiResponse> {
  const farm = await getFarmContext(userId);

  if (!farm) {
    return {
      status: "NO_FARM",
      message: "Cadastre sua fazenda para ver o clima da operação.",
    };
  }

  const location = await resolveLocation(farm);

  if (!location) {
    return {
      status: "MISSING_LOCATION",
      message: "Complete a localização da fazenda para buscar o clima real.",
    };
  }

  if (!forceRefresh) {
    const cachedSnapshot = await getCachedSnapshot(userId, farm.id);
    const rawData = cachedSnapshot ? rawDataFromSnapshot(cachedSnapshot.rawData) : null;

    if (cachedSnapshot && rawData) {
      const cacheAgeMinutes = Math.max(0, Math.round((Date.now() - cachedSnapshot.fetchedAt.getTime()) / 60000));
      const cachedLocation: WeatherLocation = {
        label: cachedSnapshot.location,
        latitude: cachedSnapshot.latitude ?? location.latitude,
        longitude: cachedSnapshot.longitude ?? location.longitude,
        city: location.city,
        state: location.state,
        source: location.source,
      };

      return {
        status: "READY",
        weather: normalizeWeatherApiResponse({
          raw: rawData,
          farm,
          location: cachedLocation,
          fetchedAt: cachedSnapshot.fetchedAt,
          fromCache: true,
          cacheAgeMinutes,
        }),
      };
    }
  }

  const rawData = await fetchOpenMeteoWeather(location);
  const normalized = normalizeWeatherApiResponse({
    raw: rawData,
    farm,
    location,
    fetchedAt: new Date(),
    fromCache: false,
    cacheAgeMinutes: null,
  });

  await getPrisma().weatherSnapshot.create({
    data: {
      farmId: farm.id,
      location: location.label,
      latitude: location.latitude,
      longitude: location.longitude,
      provider,
      rawData: rawData as Prisma.InputJsonValue,
      riskLevel: normalized.riskLevel,
      agroScore: normalized.agroScore.score,
      userId,
    },
  });

  return {
    status: "READY",
    weather: normalized,
  };
}

export async function saveWeatherAnalysis({
  snapshotUserId,
  farmId,
  aiSummary,
  riskLevel,
  agroScore,
}: {
  snapshotUserId: string;
  farmId: string;
  aiSummary: Prisma.InputJsonValue;
  riskLevel: "BAIXO" | "MEDIO" | "ALTO";
  agroScore: number;
}) {
  const latestSnapshot = await getPrisma().weatherSnapshot.findFirst({
    where: { userId: snapshotUserId, farmId, provider },
    orderBy: { fetchedAt: "desc" },
    select: { id: true },
  });

  if (!latestSnapshot) {
    return;
  }

  await getPrisma().weatherSnapshot.update({
    where: { id: latestSnapshot.id },
    data: { aiSummary, riskLevel, agroScore },
  });
}
