import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, PackageSearch } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AppShell } from "@/components/layout/app-shell";
import { requireProfile } from "@/lib/auth";
import {
  calculateInventorySituation,
  calculateInventoryValue,
  inventoryCategoryLabels,
  inventoryMovementTypeLabels,
  inventorySituationLabels,
  type SerializedInventoryItem,
} from "@/lib/inventory-calculations";
import { formatCurrencyBRL, formatDateBR } from "@/lib/formatters";
import { getPrisma } from "@/lib/prisma";

type EstoqueDetailsPageProps = {
  params: Promise<{ id: string }>;
};

export default async function EstoqueDetailsPage({ params }: EstoqueDetailsPageProps) {
  const user = await requireProfile();
  const { id } = await params;
  const item = await getPrisma().inventoryItem.findFirst({
    where: { id, userId: user.id },
    include: {
      movements: {
        include: { item: { select: { name: true, unit: true } } },
        orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }],
      },
    },
  });

  if (!item) {
    notFound();
  }

  const serializedItem: SerializedInventoryItem = {
    id: item.id,
    name: item.name,
    category: item.category,
    unit: item.unit as SerializedInventoryItem["unit"],
    quantity: item.quantity,
    minimumStock: item.minimumStock,
    unitCost: item.unitCost,
    supplier: item.supplier,
    expirationDate: item.expirationDate?.toISOString() ?? null,
    location: item.location,
    sku: item.sku,
    notes: item.notes,
    createdAt: item.createdAt.toISOString(),
    updatedAt: item.updatedAt.toISOString(),
    movements: item.movements.map((movement) => ({
      id: movement.id,
      itemId: movement.itemId,
      itemName: movement.item.name,
      itemUnit: movement.item.unit,
      type: movement.type,
      quantity: movement.quantity,
      unitCost: movement.unitCost,
      responsible: movement.responsible,
      originOrDestination: movement.originOrDestination,
      reason: movement.reason,
      notes: movement.notes,
      balanceAfter: movement.balanceAfter,
      occurredAt: movement.occurredAt.toISOString(),
      createdAt: movement.createdAt.toISOString(),
    })),
  };
  const situation = calculateInventorySituation(serializedItem);

  return (
    <AppShell title={item.name} subtitle="Detalhes do produto no estoque">
      <div className="space-y-6">
        <Button asChild variant="outline">
          <Link href="/estoque">
            <ArrowLeft className="h-4 w-4" />
            Voltar ao estoque
          </Link>
        </Button>

        <Card className="rounded-xl border-foreground/10 bg-card/80">
          <CardHeader>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <PackageSearch className="h-5 w-5 text-emerald-300" />
                  {item.name}
                </CardTitle>
                <p className="mt-2 text-sm text-muted-foreground">{item.notes || "Sem observacoes cadastradas."}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="border-emerald-500/20 bg-emerald-500/10 text-emerald-300">
                  {inventoryCategoryLabels[item.category]}
                </Badge>
                <Badge variant="outline">{inventorySituationLabels[situation]}</Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-3">
            <Metric label="Quantidade atual" value={`${item.quantity} ${item.unit}`} />
            <Metric label="Estoque minimo" value={`${item.minimumStock} ${item.unit}`} />
            <Metric label="Valor total" value={formatCurrencyBRL(calculateInventoryValue(serializedItem))} />
            <Metric label="Custo unitario" value={formatCurrencyBRL(item.unitCost)} />
            <Metric label="Fornecedor" value={item.supplier || "Nao informado"} />
            <Metric label="Validade" value={item.expirationDate ? formatDateBR(item.expirationDate) : "Sem validade"} />
            <Metric label="Localizacao" value={item.location || "Nao informada"} />
            <Metric label="SKU" value={item.sku || "Nao informado"} />
            <Metric label="Atualizado em" value={formatDateBR(item.updatedAt)} />
          </CardContent>
        </Card>

        <Card className="rounded-xl border-foreground/10 bg-card/80">
          <CardHeader>
            <CardTitle className="text-base">Historico de movimentacoes</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Quantidade</TableHead>
                  <TableHead>Responsavel</TableHead>
                  <TableHead>Saldo apos</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {serializedItem.movements.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-muted-foreground">
                      Nenhuma movimentacao registrada.
                    </TableCell>
                  </TableRow>
                ) : (
                  serializedItem.movements.map((movement) => (
                    <TableRow key={movement.id}>
                      <TableCell>{formatDateBR(movement.occurredAt)}</TableCell>
                      <TableCell>{inventoryMovementTypeLabels[movement.type]}</TableCell>
                      <TableCell>
                        {movement.quantity} {item.unit}
                      </TableCell>
                      <TableCell>{movement.responsible || "Nao informado"}</TableCell>
                      <TableCell>
                        {typeof movement.balanceAfter === "number" ? `${movement.balanceAfter} ${item.unit}` : "Nao calculado"}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-background/45 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 font-medium">{value}</p>
    </div>
  );
}
