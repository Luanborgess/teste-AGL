import { InventoryDashboard } from "@/components/estoque/inventory-dashboard";
import { AppShell } from "@/components/layout/app-shell";
import { requireProfile } from "@/lib/auth";
import type {
  SerializedInventoryItem,
  SerializedInventoryMovement,
} from "@/lib/inventory-calculations";
import { getPrisma } from "@/lib/prisma";

export default async function EstoquePage() {
  const user = await requireProfile();

  const [items, movements] = await Promise.all([
    getPrisma().inventoryItem.findMany({
      where: { userId: user.id },
      include: {
        movements: {
          include: { item: { select: { name: true, unit: true } } },
          orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }],
        },
      },
      orderBy: [{ updatedAt: "desc" }, { name: "asc" }],
    }),
    getPrisma().inventoryMovement.findMany({
      where: { userId: user.id },
      include: { item: { select: { name: true, unit: true } } },
      orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }],
    }),
  ]);

  const serializedItems: SerializedInventoryItem[] = items.map((item) => ({
    id: item.id,
    name: item.name,
    category: item.category,
    unit: item.unit as SerializedInventoryItem["unit"],
    quantity: item.quantity,
    minimumStock: item.minimumStock,
    unitCost: item.unitCost,
    supplier: item.supplier,
    expirationDate: item.expirationDate?.toISOString() ?? null,
    location: item.location,
    sku: item.sku,
    notes: item.notes,
    createdAt: item.createdAt.toISOString(),
    updatedAt: item.updatedAt.toISOString(),
    movements: item.movements.map((movement) => ({
      id: movement.id,
      itemId: movement.itemId,
      itemName: movement.item.name,
      itemUnit: movement.item.unit,
      type: movement.type,
      quantity: movement.quantity,
      unitCost: movement.unitCost,
      responsible: movement.responsible,
      originOrDestination: movement.originOrDestination,
      reason: movement.reason,
      notes: movement.notes,
      balanceAfter: movement.balanceAfter,
      occurredAt: movement.occurredAt.toISOString(),
      createdAt: movement.createdAt.toISOString(),
    })),
  }));

  const serializedMovements: SerializedInventoryMovement[] = movements.map((movement) => ({
    id: movement.id,
    itemId: movement.itemId,
    itemName: movement.item.name,
    itemUnit: movement.item.unit,
    type: movement.type,
    quantity: movement.quantity,
    unitCost: movement.unitCost,
    responsible: movement.responsible,
    originOrDestination: movement.originOrDestination,
    reason: movement.reason,
    notes: movement.notes,
    balanceAfter: movement.balanceAfter,
    occurredAt: movement.occurredAt.toISOString(),
    createdAt: movement.createdAt.toISOString(),
  }));

  return (
    <AppShell title="Estoque" subtitle="Controle de insumos, materiais e inventario da fazenda">
      <InventoryDashboard initialItems={serializedItems} initialMovements={serializedMovements} />
    </AppShell>
  );
}
