import { FuncionariosDashboard } from "@/components/funcionarios/funcionarios-dashboard";
import { AppShell } from "@/components/layout/app-shell";
import { requireProfile } from "@/lib/auth";
import type {
  SerializedEmployee,
  SerializedEmployeeAttendance,
  SerializedTeamAssignment,
} from "@/lib/employee-calculations";
import { getPrisma } from "@/lib/prisma";

export default async function FuncionariosPage() {
  const user = await requireProfile();

  const [employees, attendances, assignments] = await Promise.all([
    getPrisma().employee.findMany({
      where: { userId: user.id },
      include: {
        attendances: { orderBy: [{ date: "desc" }, { createdAt: "desc" }] },
        assignments: {
          include: {
            assignment: {
              include: {
                members: {
                  include: { employee: { select: { fullName: true, role: true, salary: true } } },
                  orderBy: { createdAt: "asc" },
                },
              },
            },
          },
          orderBy: { createdAt: "desc" },
        },
        salaryHistory: { orderBy: { changedAt: "desc" } },
      },
      orderBy: [{ updatedAt: "desc" }, { fullName: "asc" }],
    }),
    getPrisma().employeeAttendance.findMany({
      where: { userId: user.id },
      include: { employee: { select: { fullName: true } } },
      orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    }),
    getPrisma().teamAssignment.findMany({
      where: { userId: user.id },
      include: {
        members: {
          include: { employee: { select: { fullName: true, role: true, salary: true } } },
          orderBy: { createdAt: "asc" },
        },
      },
      orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    }),
  ]);

  const serializedAssignments: SerializedTeamAssignment[] = assignments.map((assignment) => ({
    id: assignment.id,
    activity: assignment.activity,
    location: assignment.location,
    date: assignment.date.toISOString(),
    startTime: assignment.startTime?.toISOString() ?? null,
    endTime: assignment.endTime?.toISOString() ?? null,
    transport: assignment.transport,
    vehicle: assignment.vehicle,
    driver: assignment.driver,
    status: assignment.status,
    notes: assignment.notes,
    createdAt: assignment.createdAt.toISOString(),
    updatedAt: assignment.updatedAt.toISOString(),
    members: assignment.members.map((member) => ({
      id: member.id,
      employeeId: member.employeeId,
      employeeName: member.employee.fullName,
      employeeRole: member.employee.role,
      employeeSalary: member.employee.salary,
      roleInActivity: member.roleInActivity,
      createdAt: member.createdAt.toISOString(),
    })),
  }));

  const serializedAttendances: SerializedEmployeeAttendance[] = attendances.map((attendance) => ({
    id: attendance.id,
    employeeId: attendance.employeeId,
    employeeName: attendance.employee.fullName,
    date: attendance.date.toISOString(),
    status: attendance.status,
    checkIn: attendance.checkIn?.toISOString() ?? null,
    checkOut: attendance.checkOut?.toISOString() ?? null,
    notes: attendance.notes,
    createdAt: attendance.createdAt.toISOString(),
  }));

  const serializedEmployees: SerializedEmployee[] = employees.map((employee) => ({
    id: employee.id,
    fullName: employee.fullName,
    cpf: employee.cpf,
    phone: employee.phone,
    email: employee.email,
    role: employee.role,
    department: employee.department,
    salary: employee.salary,
    status: employee.status,
    admissionDate: employee.admissionDate.toISOString(),
    address: employee.address,
    emergencyContact: employee.emergencyContact,
    notes: employee.notes,
    createdAt: employee.createdAt.toISOString(),
    updatedAt: employee.updatedAt.toISOString(),
    attendances: employee.attendances.map((attendance) => ({
      id: attendance.id,
      employeeId: attendance.employeeId,
      date: attendance.date.toISOString(),
      status: attendance.status,
      checkIn: attendance.checkIn?.toISOString() ?? null,
      checkOut: attendance.checkOut?.toISOString() ?? null,
      notes: attendance.notes,
      createdAt: attendance.createdAt.toISOString(),
    })),
    assignments: employee.assignments.map((member) => ({
      id: member.id,
      roleInActivity: member.roleInActivity,
      createdAt: member.createdAt.toISOString(),
      assignment: {
        id: member.assignment.id,
        activity: member.assignment.activity,
        location: member.assignment.location,
        date: member.assignment.date.toISOString(),
        startTime: member.assignment.startTime?.toISOString() ?? null,
        endTime: member.assignment.endTime?.toISOString() ?? null,
        transport: member.assignment.transport,
        vehicle: member.assignment.vehicle,
        driver: member.assignment.driver,
        status: member.assignment.status,
        notes: member.assignment.notes,
        createdAt: member.assignment.createdAt.toISOString(),
        updatedAt: member.assignment.updatedAt.toISOString(),
        members: member.assignment.members.map((assignmentMember) => ({
          id: assignmentMember.id,
          employeeId: assignmentMember.employeeId,
          employeeName: assignmentMember.employee.fullName,
          employeeRole: assignmentMember.employee.role,
          employeeSalary: assignmentMember.employee.salary,
          roleInActivity: assignmentMember.roleInActivity,
          createdAt: assignmentMember.createdAt.toISOString(),
        })),
      },
    })),
    salaryHistory: employee.salaryHistory.map((history) => ({
      id: history.id,
      employeeId: history.employeeId,
      oldSalary: history.oldSalary,
      newSalary: history.newSalary,
      reason: history.reason,
      changedAt: history.changedAt.toISOString(),
    })),
  }));

  return (
    <AppShell title="Funcionarios" subtitle="Gestao de equipe, escala e logistica operacional">
      <FuncionariosDashboard
        initialEmployees={serializedEmployees}
        initialAttendances={serializedAttendances}
        initialAssignments={serializedAssignments}
      />
    </AppShell>
  );
}
