import type { Metadata } from "next";
import { LandingExampleCalculation } from "@/components/landing/landing-example-calculation";
import { LandingFAQ } from "@/components/landing/landing-faq";
import { LandingFeatureGrid } from "@/components/landing/landing-feature-grid";
import { LandingFinalCTA } from "@/components/landing/landing-final-cta";
import { LandingFooter } from "@/components/landing/landing-footer";
import { LandingHero } from "@/components/landing/landing-hero";
import { LandingHowItWorks } from "@/components/landing/landing-how-it-works";
import { LandingNavbar } from "@/components/landing/landing-navbar";
import { LandingOperationalIntelligence } from "@/components/landing/landing-operational-intelligence";
import { LandingPricing } from "@/components/landing/landing-pricing";
import { LandingSecurity } from "@/components/landing/landing-security";
import { LandingTrustSignals } from "@/components/landing/landing-trust-signals";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = {
  title: "AgroLogistic | ERP agrícola inteligente",
  description:
    "Controle produção, estoque, logística, financeiro, maquinário e equipe da fazenda com dados reais em um painel simples.",
};

export default async function Home() {
  const user = await getCurrentUser();
  const primaryCtaHref = user ? (user.farmProfile ? "/dashboard" : "/onboarding") : "/login";
  const demoHref = user?.farmProfile ? "/dashboard" : "/login";

  return (
    <main className="dark min-h-screen overflow-hidden bg-[#050806] text-foreground">
      <LandingNavbar primaryCtaHref={primaryCtaHref} />
      <LandingHero primaryCtaHref={primaryCtaHref} demoHref={demoHref} />
      <LandingTrustSignals />
      <LandingFeatureGrid />
      <LandingHowItWorks />
      <LandingOperationalIntelligence />
      <LandingExampleCalculation />
      <LandingSecurity />
      <LandingPricing primaryCtaHref={primaryCtaHref} />
      <LandingFAQ />
      <LandingFinalCTA primaryCtaHref={primaryCtaHref} />
      <LandingFooter />
    </main>
  );
}
