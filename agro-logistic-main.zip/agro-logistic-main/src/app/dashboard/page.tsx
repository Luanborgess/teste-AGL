import Link from "next/link";
import {
  AreaChart,
  Boxes,
  CircleDollarSign,
  ClipboardEdit,
  FileText,
  Gauge,
  Leaf,
  PackageCheck,
  Route,
  Sprout,
  Tractor,
  TrendingUp,
  WalletCards,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { OperationCharts } from "@/components/charts/operation-charts";
import { PdfReportButton } from "@/components/forms/pdf-report-button";
import { AppShell } from "@/components/layout/app-shell";
import { StatCard } from "@/components/dashboard/stat-card";
import { getDashboardData } from "@/lib/dashboard";
import {
  formatCurrency,
  formatInteger,
  formatNumber,
  formatPercent,
  insufficientData,
} from "@/lib/formatters";
import { requireProfile } from "@/lib/auth";

export default async function DashboardPage() {
  const user = await requireProfile();
  const profile = user.farmProfile;
  const data = getDashboardData(profile, user.financialEntries, user.stockMovements, user.shipments);
  const metrics = data.operationalMetrics;

  const cards = [
    {
      label: "Área produtiva",
      value: formatNumber(profile?.productiveArea, " ha"),
      helper: "Base produtiva informada no questionário.",
      icon: AreaChart,
    },
    {
      label: "Produção estimada",
      value: formatNumber(metrics?.production, " sacas"),
      helper: "Área produtiva x produtividade por hectare.",
      icon: Leaf,
      tone: "good" as const,
    },
    {
      label: "Receita estimada",
      value: formatCurrency(metrics?.revenue),
      helper: "Produção estimada x preço informado.",
      icon: CircleDollarSign,
      tone: "good" as const,
    },
    {
      label: "Lucro estimado",
      value: formatCurrency(metrics?.profit),
      helper: "Receita estimada menos custos estimados.",
      icon: TrendingUp,
    },
    {
      label: "Margem",
      value: formatPercent(metrics?.margin),
      helper: "Lucro dividido pela receita estimada.",
      icon: Gauge,
    },
    {
      label: "Estoque atual",
      value: formatNumber(data.stock, " sacas"),
      helper: "Estoque inicial + entradas - saídas.",
      icon: Boxes,
    },
    {
      label: "Cargas necessárias",
      value: formatInteger(metrics?.loads),
      helper: "Produção dividida pela capacidade por carga.",
      icon: Route,
    },
    {
      label: "Meses para escoar",
      value: formatNumber(metrics?.monthsToShip, " meses"),
      helper: "Produção dividida pelo volume mensal.",
      icon: Tractor,
    },
    {
      label: "Custo por hectare",
      value: formatCurrency(metrics?.costPerHectare),
      helper: "Custos estimados divididos pela área produtiva.",
      icon: WalletCards,
    },
    {
      label: "Custo por saca",
      value: formatCurrency(metrics?.costPerUnit),
      helper: "Custos estimados divididos pela produção.",
      icon: PackageCheck,
    },
  ];

  return (
    <AppShell
      title={profile?.farmName ?? "Dashboard"}
      subtitle="Visão geral da operação com base no questionário e nos módulos."
    >
      <div className="space-y-6">
        <div className="flex flex-col gap-4 rounded-md border border-emerald-500/15 bg-card/82 p-5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/15">
                {profile?.mainCrop ?? "Cultura não informada"}
              </Badge>
              <Badge variant="outline">{profile?.operationType}</Badge>
              <Badge variant="outline">{profile?.city}/{profile?.state}</Badge>
            </div>
            <p className="mt-3 max-w-3xl text-sm text-muted-foreground">
              Responsável: {profile?.responsible}. O painel não usa dados aleatórios; quando um
              insumo operacional falta, a métrica mostra {insufficientData}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline">
              <Link href="/producao">
                <Sprout className="mr-2 h-4 w-4" />
                Produção
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/onboarding">
                <ClipboardEdit className="mr-2 h-4 w-4" />
                Editar perfil
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/relatorios">
                <FileText className="mr-2 h-4 w-4" />
                Relatório
              </Link>
            </Button>
            <PdfReportButton />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          {cards.map((card) => (
            <StatCard key={card.label} {...card} />
          ))}
        </div>

        <OperationCharts
          production={metrics?.production ?? null}
          shipped={data.shipmentTotals.volume}
          stock={data.stock}
          revenue={metrics?.revenue ?? null}
          costs={profile?.estimatedCosts ?? null}
          expenses={data.financialTotals.expenses}
        />

        <div className="grid gap-4 lg:grid-cols-[0.95fr_1.05fr]">
          <Alert className="rounded-md border-amber-500/25 bg-amber-500/10">
            <Gauge className="h-4 w-4" />
            <AlertTitle>Alertas operacionais</AlertTitle>
            <AlertDescription>
              {data.stock !== null && data.stock <= 0
                ? "Estoque zerado ou negativo. Registre entradas ou revise saídas."
                : data.shipmentTotals.volume > 0 && metrics?.production
                  ? `Volume embarcado representa ${formatPercent(data.shipmentTotals.volume / metrics.production)} da produção estimada.`
                  : "Sem alertas críticos. Complete movimentações para enriquecer a leitura operacional."}
            </AlertDescription>
          </Alert>

          <Card className="rounded-md bg-card/82">
            <CardHeader>
              <CardTitle className="text-base">Resumo operacional</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 text-sm sm:grid-cols-2">
              <p><span className="text-muted-foreground">Máquinas:</span> {profile?.machines}</p>
              <p><span className="text-muted-foreground">Capacidade por carga:</span> {formatNumber(profile?.loadCapacity, " sacas")}</p>
              <p><span className="text-muted-foreground">Volume mensal:</span> {formatNumber(profile?.monthlyVolume, " sacas")}</p>
              <p><span className="text-muted-foreground">Saldo financeiro real:</span> {formatCurrency(data.financialTotals.balance)}</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
