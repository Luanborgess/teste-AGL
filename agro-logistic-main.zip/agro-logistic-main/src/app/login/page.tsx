import { Leaf } from "lucide-react";
import { LoginForm } from "@/components/forms/login-form";
import { ThemeToggle } from "@/components/layout/theme-toggle";

export default function LoginPage() {
  return (
    <main className="grid min-h-screen lg:grid-cols-[0.95fr_1.05fr]">
      <section className="hidden border-r border-emerald-500/15 bg-[radial-gradient(circle_at_top,rgba(16,185,129,0.22),transparent_28rem),hsl(var(--sidebar))] p-10 lg:flex lg:flex-col lg:justify-between">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-md bg-emerald-500/15 text-emerald-300">
            <Leaf className="h-5 w-5" />
          </span>
          <span>
            <span className="block text-lg font-semibold">AgroLogistic</span>
            <span className="text-sm text-muted-foreground">Gestão Rural</span>
          </span>
        </div>
        <div>
          <p className="text-4xl font-semibold tracking-tight">Entre, responda o questionário e opere com números reais.</p>
          <p className="mt-4 max-w-md text-muted-foreground">
            Login simples para MVP. O perfil operacional é a fonte única dos cálculos.
          </p>
        </div>
      </section>
      <section className="flex min-h-screen items-center justify-center bg-background p-5">
        <div className="absolute right-5 top-5">
          <ThemeToggle />
        </div>
        <LoginForm />
      </section>
    </main>
  );
}
