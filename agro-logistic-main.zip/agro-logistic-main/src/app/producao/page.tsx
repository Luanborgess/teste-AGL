import { AppShell } from "@/components/layout/app-shell";
import { ProducaoDashboard } from "@/components/producao/producao-dashboard";
import { requireProfile } from "@/lib/auth";
import { getPrisma } from "@/lib/prisma";

export default async function ProducaoPage() {
  const user = await requireProfile();
  const crops = await getPrisma().crop.findMany({
    where: { userId: user.id },
    orderBy: [{ expectedHarvestDate: "asc" }, { plantingDate: "desc" }],
  });

  return (
    <AppShell title="Produção" subtitle="Controle de cultivos, plantios e colheitas">
      <ProducaoDashboard
        initialCrops={crops.map((crop) => ({
          id: crop.id,
          name: crop.name,
          variety: crop.variety,
          plantedArea: crop.plantedArea,
          plantingDate: crop.plantingDate.toISOString(),
          expectedHarvestDate: crop.expectedHarvestDate.toISOString(),
          expectedProduction: crop.expectedProduction,
          harvestedProduction: crop.harvestedProduction,
          status: crop.status,
          notes: crop.notes,
          createdAt: crop.createdAt.toISOString(),
          updatedAt: crop.updatedAt.toISOString(),
        }))}
      />
    </AppShell>
  );
}
