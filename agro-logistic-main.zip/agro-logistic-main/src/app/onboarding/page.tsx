import { AppShell } from "@/components/layout/app-shell";
import { OnboardingForm } from "@/components/forms/onboarding-form";
import { requireUser } from "@/lib/auth";

export default async function OnboardingPage() {
  const user = await requireUser();

  return (
    <AppShell
      title="Perfil operacional"
      subtitle="Esses dados alimentam todos os cálculos e relatórios do AgroLogistic."
    >
      <OnboardingForm profile={user.farmProfile} />
    </AppShell>
  );
}
