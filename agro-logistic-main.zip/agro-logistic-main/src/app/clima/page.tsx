import { AppShell } from "@/components/layout/app-shell";
import { WeatherDashboard } from "@/components/clima/weather-dashboard";
import { requireProfile } from "@/lib/auth";
import { analyzeWeatherRecommendations } from "@/lib/weather-ai";
import { getWeatherForUser } from "@/lib/weather-service";

export default async function ClimaPage() {
  const user = await requireProfile();
  const weatherResult = await getWeatherForUser(user.id);
  const analysis = weatherResult.weather ? await analyzeWeatherRecommendations(weatherResult.weather) : null;

  return (
    <AppShell title="Clima" subtitle="Previsão, riscos e recomendações para a operação agrícola">
      <WeatherDashboard initialResult={weatherResult} initialAnalysis={analysis} />
    </AppShell>
  );
}
