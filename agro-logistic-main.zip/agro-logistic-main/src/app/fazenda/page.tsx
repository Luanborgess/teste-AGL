import { AppShell } from "@/components/layout/app-shell";
import { FazendaDashboard } from "@/components/fazenda/fazenda-dashboard";
import { requireProfile } from "@/lib/auth";
import { getPrisma } from "@/lib/prisma";

export default async function FazendaPage() {
  const user = await requireProfile();
  const farm = await getPrisma().farm.findUnique({
    where: { userId: user.id },
    include: {
      fields: {
        orderBy: [{ name: "asc" }],
      },
    },
  });

  return (
    <AppShell title="Fazenda" subtitle="Gestao da propriedade, areas e talhoes">
      <FazendaDashboard
        initialFarm={
          farm
            ? {
                id: farm.id,
                name: farm.name,
                owner: farm.owner,
                city: farm.city,
                state: farm.state,
                totalArea: farm.totalArea,
                productionType: farm.productionType,
                coordinates: farm.coordinates,
                notes: farm.notes,
                createdAt: farm.createdAt.toISOString(),
                updatedAt: farm.updatedAt.toISOString(),
                fields: farm.fields.map((field) => ({
                  id: field.id,
                  farmId: field.farmId,
                  name: field.name,
                  area: field.area,
                  soilType: field.soilType,
                  currentCrop: field.currentCrop,
                  expectedProductivity: field.expectedProductivity,
                  status: field.status,
                  coordinates: field.coordinates,
                  notes: field.notes,
                  createdAt: field.createdAt.toISOString(),
                  updatedAt: field.updatedAt.toISOString(),
                })),
              }
            : null
        }
      />
    </AppShell>
  );
}
