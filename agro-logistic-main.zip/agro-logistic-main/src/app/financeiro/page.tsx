import { FinanceiroDashboard } from "@/components/financeiro/financeiro-dashboard";
import { AppShell } from "@/components/layout/app-shell";
import { requireProfile } from "@/lib/auth";
import { getPrisma } from "@/lib/prisma";

export default async function FinanceiroPage() {
  const user = await requireProfile();
  const transactions = await getPrisma().transaction.findMany({
    where: { userId: user.id },
    orderBy: { date: "desc" },
  });

  return (
    <AppShell title="Financeiro" subtitle="Controle de receitas, despesas e fluxo de caixa">
      <FinanceiroDashboard
        initialTransactions={transactions.map((transaction) => ({
          id: transaction.id,
          description: transaction.description,
          amount: transaction.amount,
          category: transaction.category,
          type: transaction.type,
          notes: transaction.notes,
          date: transaction.date.toISOString(),
          createdAt: transaction.createdAt.toISOString(),
          updatedAt: transaction.updatedAt.toISOString(),
        }))}
      />
    </AppShell>
  );
}
