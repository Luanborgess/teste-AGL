import Link from "next/link";
import { FileText, Leaf, Route, WalletCards } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/dashboard/stat-card";
import { PdfReportButton } from "@/components/forms/pdf-report-button";
import { AppShell } from "@/components/layout/app-shell";
import { getDashboardData } from "@/lib/dashboard";
import {
  formatCurrency,
  formatInteger,
  formatNumber,
  formatPercent,
} from "@/lib/formatters";
import { requireProfile } from "@/lib/auth";

export default async function RelatoriosPage() {
  const user = await requireProfile();
  const profile = user.farmProfile;
  const data = getDashboardData(profile, user.financialEntries, user.stockMovements, user.shipments);
  const metrics = data.operationalMetrics;

  return (
    <AppShell title="Relatórios" subtitle="Relatório operacional gerado a partir dos mesmos dados do dashboard.">
      <div className="space-y-6">
        <Card className="rounded-md border-emerald-500/20 bg-card/82">
          <CardHeader className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle>Relatório operacional</CardTitle>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge className="bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/15">
                  {profile?.farmName}
                </Badge>
                <Badge variant="outline">{profile?.mainCrop}</Badge>
                <Badge variant="outline">{profile?.responsible}</Badge>
              </div>
            </div>
            <div className="flex gap-2">
              <Button asChild variant="outline">
                <Link href="/dashboard">Voltar ao dashboard</Link>
              </Button>
              <PdfReportButton />
            </div>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <StatCard label="Produção estimada" value={formatNumber(metrics?.production, " sacas")} helper="Área produtiva x produtividade." icon={Leaf} tone="good" />
            <StatCard label="Receita estimada" value={formatCurrency(metrics?.revenue)} helper="Produção x preço." icon={WalletCards} tone="good" />
            <StatCard label="Cargas necessárias" value={formatInteger(metrics?.loads)} helper="Produção / capacidade por carga." icon={Route} />
            <StatCard label="Margem estimada" value={formatPercent(metrics?.margin)} helper="Lucro / receita." icon={FileText} />
          </CardContent>
        </Card>

        <Card className="rounded-md bg-card/82">
          <CardHeader>
            <CardTitle>Detalhamento</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 text-sm md:grid-cols-2">
            <p><span className="text-muted-foreground">Lucro estimado:</span> {formatCurrency(metrics?.profit)}</p>
            <p><span className="text-muted-foreground">Estoque atual:</span> {formatNumber(data.stock, " sacas")}</p>
            <p><span className="text-muted-foreground">Meses para escoar:</span> {formatNumber(metrics?.monthsToShip, " meses")}</p>
            <p><span className="text-muted-foreground">Custo por hectare:</span> {formatCurrency(metrics?.costPerHectare)}</p>
            <p><span className="text-muted-foreground">Custo por saca:</span> {formatCurrency(metrics?.costPerUnit)}</p>
            <p><span className="text-muted-foreground">Volume embarcado:</span> {formatNumber(data.shipmentTotals.volume, " sacas")}</p>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
