import { AppShell } from "@/components/layout/app-shell";
import { MaquinarioDashboard } from "@/components/maquinario/maquinario-dashboard";
import { requireProfile } from "@/lib/auth";
import { getPrisma } from "@/lib/prisma";
import { serializeMachine, serializeMachineFuelLog, serializeMachineMaintenance } from "@/lib/machine-serializers";

export default async function MaquinarioPage() {
  const user = await requireProfile();
  const prisma = getPrisma();

  const [machines, maintenances, fuelLogs] = await Promise.all([
    prisma.machine.findMany({
      where: { userId: user.id },
      include: {
        maintenances: { orderBy: { performedAt: "desc" } },
        fuelLogs: { orderBy: { date: "desc" } },
        hourMeterLogs: { orderBy: { date: "desc" } },
      },
      orderBy: { name: "asc" },
    }),
    prisma.machineMaintenance.findMany({
      where: { userId: user.id },
      include: { machine: { select: { name: true } } },
      orderBy: { performedAt: "desc" },
    }),
    prisma.machineFuelLog.findMany({
      where: { userId: user.id },
      include: { machine: { select: { name: true } } },
      orderBy: { date: "desc" },
    }),
  ]);

  return (
    <AppShell title="Maquinario" subtitle="Gestao de equipamentos, manutencoes e custos operacionais">
      <MaquinarioDashboard
        initialMachines={machines.map(serializeMachine)}
        initialMaintenances={maintenances.map(serializeMachineMaintenance)}
        initialFuelLogs={fuelLogs.map(serializeMachineFuelLog)}
      />
    </AppShell>
  );
}
