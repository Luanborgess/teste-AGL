import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { serializeMachineFuelLog } from "@/lib/machine-serializers";
import { machineFuelLogSchema } from "@/lib/validations";

export async function GET() {
  const user = await requireProfile();

  const fuelLogs = await getPrisma().machineFuelLog.findMany({
    where: { userId: user.id },
    include: { machine: { select: { name: true } } },
    orderBy: { date: "desc" },
  });

  return NextResponse.json({ fuelLogs: fuelLogs.map(serializeMachineFuelLog) });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = machineFuelLogSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Consumo invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const machine = await getPrisma().machine.findFirst({
    where: { id: payload.data.machineId, userId: user.id },
    select: { id: true, hourMeter: true },
  });

  if (!machine) {
    return NextResponse.json({ error: "Maquina nao encontrada." }, { status: 404 });
  }

  try {
    const fuelLog = await getPrisma().$transaction(async (tx) => {
      const created = await tx.machineFuelLog.create({
        data: {
          machineId: payload.data.machineId,
          date: parseDateInput(payload.data.date),
          liters: payload.data.liters,
          pricePerLiter: payload.data.pricePerLiter,
          totalCost: payload.data.liters * payload.data.pricePerLiter,
          hourMeter: payload.data.hourMeter ?? null,
          responsible: payload.data.responsible || null,
          notes: payload.data.notes || null,
          userId: user.id,
        },
        include: { machine: { select: { name: true } } },
      });

      if (typeof payload.data.hourMeter === "number" && payload.data.hourMeter > machine.hourMeter) {
        await tx.machine.update({
          where: { id: payload.data.machineId },
          data: { hourMeter: payload.data.hourMeter },
        });
      }

      return created;
    });

    return NextResponse.json({ fuelLog: serializeMachineFuelLog(fuelLog) }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel registrar o consumo." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao registrar o consumo." }, { status: 500 });
  }
}
