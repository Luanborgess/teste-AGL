import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { serializeMachineMaintenance } from "@/lib/machine-serializers";
import { machineMaintenanceSchema } from "@/lib/validations";

export async function GET() {
  const user = await requireProfile();

  const maintenances = await getPrisma().machineMaintenance.findMany({
    where: { userId: user.id },
    include: { machine: { select: { name: true } } },
    orderBy: { performedAt: "desc" },
  });

  return NextResponse.json({ maintenances: maintenances.map(serializeMachineMaintenance) });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = machineMaintenanceSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Manutencao invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const machine = await getPrisma().machine.findFirst({
    where: { id: payload.data.machineId, userId: user.id },
    select: { id: true },
  });

  if (!machine) {
    return NextResponse.json({ error: "Maquina nao encontrada." }, { status: 404 });
  }

  try {
    const maintenance = await getPrisma().$transaction(async (tx) => {
      const created = await tx.machineMaintenance.create({
        data: {
          machineId: payload.data.machineId,
          type: payload.data.type,
          description: payload.data.description || null,
          cost: payload.data.cost,
          performedAt: parseDateInput(payload.data.performedAt),
          nextReview: payload.data.nextReview ? parseDateInput(payload.data.nextReview) : null,
          partsChanged: payload.data.partsChanged || null,
          responsible: payload.data.responsible || null,
          hourMeter: payload.data.hourMeter ?? null,
          notes: payload.data.notes || null,
          userId: user.id,
        },
        include: { machine: { select: { name: true } } },
      });

      const machineUpdate: Prisma.MachineUpdateInput = {};

      if (payload.data.nextReview) {
        machineUpdate.nextMaintenance = parseDateInput(payload.data.nextReview);
      }

      if (payload.data.statusAfterMaintenance) {
        machineUpdate.status = payload.data.statusAfterMaintenance;
      }

      if (Object.keys(machineUpdate).length > 0) {
        await tx.machine.update({
          where: { id: payload.data.machineId },
          data: machineUpdate,
        });
      }

      return created;
    });

    return NextResponse.json({ maintenance: serializeMachineMaintenance(maintenance) }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel registrar a manutencao." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao registrar a manutencao." }, { status: 500 });
  }
}
