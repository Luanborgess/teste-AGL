import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { serializeMachineHourMeterLog } from "@/lib/machine-serializers";
import { machineHourMeterSchema } from "@/lib/validations";

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = machineHourMeterSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Horimetro invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const machine = await getPrisma().machine.findFirst({
    where: { id: payload.data.machineId, userId: user.id },
    select: { id: true, hourMeter: true },
  });

  if (!machine) {
    return NextResponse.json({ error: "Maquina nao encontrada." }, { status: 404 });
  }

  if (payload.data.newValue < machine.hourMeter) {
    return NextResponse.json({ error: "O novo horimetro nao pode ser menor que o atual." }, { status: 422 });
  }

  try {
    const hourMeterLog = await getPrisma().$transaction(async (tx) => {
      const created = await tx.machineHourMeterLog.create({
        data: {
          machineId: payload.data.machineId,
          previousValue: machine.hourMeter,
          newValue: payload.data.newValue,
          date: parseDateInput(payload.data.date),
          notes: payload.data.notes || null,
          userId: user.id,
        },
        include: { machine: { select: { name: true } } },
      });

      await tx.machine.update({
        where: { id: payload.data.machineId },
        data: { hourMeter: payload.data.newValue },
      });

      return created;
    });

    return NextResponse.json({ hourMeterLog: serializeMachineHourMeterLog(hourMeterLog) }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel atualizar o horimetro." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao atualizar o horimetro." }, { status: 500 });
  }
}
