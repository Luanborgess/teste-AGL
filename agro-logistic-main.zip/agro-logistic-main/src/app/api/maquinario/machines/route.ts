import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { serializeMachine } from "@/lib/machine-serializers";
import { machineSchema } from "@/lib/validations";

const includeHistory = {
  maintenances: { orderBy: { performedAt: "desc" as const } },
  fuelLogs: { orderBy: { date: "desc" as const } },
  hourMeterLogs: { orderBy: { date: "desc" as const } },
};

export async function GET() {
  const user = await requireProfile();

  const machines = await getPrisma().machine.findMany({
    where: { userId: user.id },
    include: includeHistory,
    orderBy: [{ name: "asc" }],
  });

  return NextResponse.json({ machines: machines.map(serializeMachine) });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = machineSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Maquina invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  try {
    const machine = await getPrisma().machine.create({
      data: {
        name: payload.data.name,
        type: payload.data.type,
        brand: payload.data.brand,
        model: payload.data.model || null,
        year: payload.data.year,
        identifier: payload.data.identifier || null,
        hourMeter: payload.data.hourMeter,
        fuelConsumption: payload.data.fuelConsumption,
        operationalCost: payload.data.operationalCost,
        nextMaintenance: payload.data.nextMaintenance ? parseDateInput(payload.data.nextMaintenance) : null,
        status: payload.data.status,
        notes: payload.data.notes || null,
        userId: user.id,
      },
      include: includeHistory,
    });

    return NextResponse.json({ machine: serializeMachine(machine) }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel salvar a maquina." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao salvar a maquina." }, { status: 500 });
  }
}
