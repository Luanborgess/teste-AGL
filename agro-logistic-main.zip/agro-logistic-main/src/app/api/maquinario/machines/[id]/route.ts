import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { serializeMachine } from "@/lib/machine-serializers";
import { machineSchema } from "@/lib/validations";

type MachineRouteContext = {
  params: Promise<{ id: string }>;
};

const includeHistory = {
  maintenances: { orderBy: { performedAt: "desc" as const } },
  fuelLogs: { orderBy: { date: "desc" as const } },
  hourMeterLogs: { orderBy: { date: "desc" as const } },
};

export async function GET(_request: Request, context: MachineRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const machine = await getPrisma().machine.findFirst({
    where: { id, userId: user.id },
    include: includeHistory,
  });

  if (!machine) {
    return NextResponse.json({ error: "Maquina nao encontrada." }, { status: 404 });
  }

  return NextResponse.json({ machine: serializeMachine(machine) });
}

export async function PUT(request: Request, context: MachineRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const payload = machineSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Maquina invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const existing = await getPrisma().machine.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Maquina nao encontrada." }, { status: 404 });
  }

  try {
    const machine = await getPrisma().machine.update({
      where: { id },
      data: {
        name: payload.data.name,
        type: payload.data.type,
        brand: payload.data.brand,
        model: payload.data.model || null,
        year: payload.data.year,
        identifier: payload.data.identifier || null,
        hourMeter: payload.data.hourMeter,
        fuelConsumption: payload.data.fuelConsumption,
        operationalCost: payload.data.operationalCost,
        nextMaintenance: payload.data.nextMaintenance ? parseDateInput(payload.data.nextMaintenance) : null,
        status: payload.data.status,
        notes: payload.data.notes || null,
      },
      include: includeHistory,
    });

    return NextResponse.json({ machine: serializeMachine(machine) });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel atualizar a maquina." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao atualizar a maquina." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, context: MachineRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const existing = await getPrisma().machine.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Maquina nao encontrada." }, { status: 404 });
  }

  await getPrisma().machine.delete({
    where: { id },
  });

  return NextResponse.json({ ok: true });
}
