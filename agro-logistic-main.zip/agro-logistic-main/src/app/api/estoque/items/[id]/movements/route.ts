import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { getPrisma } from "@/lib/prisma";

type InventoryItemMovementsRouteContext = {
  params: Promise<{ id: string }>;
};

export async function GET(_request: Request, context: InventoryItemMovementsRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const item = await getPrisma().inventoryItem.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!item) {
    return NextResponse.json({ error: "Item nao encontrado." }, { status: 404 });
  }

  const movements = await getPrisma().inventoryMovement.findMany({
    where: { itemId: id, userId: user.id },
    include: { item: { select: { name: true, unit: true } } },
    orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }],
  });

  return NextResponse.json({ movements });
}
