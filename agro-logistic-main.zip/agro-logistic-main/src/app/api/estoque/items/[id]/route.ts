import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { inventoryItemSchema } from "@/lib/validations";

type InventoryItemRouteContext = {
  params: Promise<{ id: string }>;
};

export async function GET(_request: Request, context: InventoryItemRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const item = await getPrisma().inventoryItem.findFirst({
    where: { id, userId: user.id },
    include: {
      movements: {
        include: { item: { select: { name: true, unit: true } } },
        orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }],
      },
    },
  });

  if (!item) {
    return NextResponse.json({ error: "Item nao encontrado." }, { status: 404 });
  }

  return NextResponse.json({ item });
}

export async function PUT(request: Request, context: InventoryItemRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const payload = inventoryItemSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Item de estoque invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const existing = await getPrisma().inventoryItem.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Item nao encontrado." }, { status: 404 });
  }

  try {
    const item = await getPrisma().inventoryItem.update({
      where: { id },
      data: {
        name: payload.data.name,
        category: payload.data.category,
        unit: payload.data.unit,
        quantity: payload.data.quantity,
        minimumStock: payload.data.minimumStock,
        unitCost: payload.data.unitCost,
        supplier: payload.data.supplier || null,
        expirationDate: payload.data.expirationDate ? parseDateInput(payload.data.expirationDate) : null,
        location: payload.data.location || null,
        sku: payload.data.sku || null,
        notes: payload.data.notes || null,
      },
    });

    return NextResponse.json({ item });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel atualizar o item." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao atualizar o item." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, context: InventoryItemRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const existing = await getPrisma().inventoryItem.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Item nao encontrado." }, { status: 404 });
  }

  await getPrisma().inventoryItem.delete({ where: { id } });

  return NextResponse.json({ ok: true });
}
