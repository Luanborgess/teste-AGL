import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { inventoryItemSchema } from "@/lib/validations";

export async function GET() {
  const user = await requireProfile();

  const items = await getPrisma().inventoryItem.findMany({
    where: { userId: user.id },
    include: {
      movements: {
        include: { item: { select: { name: true, unit: true } } },
        orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }],
      },
    },
    orderBy: [{ updatedAt: "desc" }, { name: "asc" }],
  });

  return NextResponse.json({ items });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = inventoryItemSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Item de estoque invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  try {
    const item = await getPrisma().inventoryItem.create({
      data: {
        name: payload.data.name,
        category: payload.data.category,
        unit: payload.data.unit,
        quantity: payload.data.quantity,
        minimumStock: payload.data.minimumStock,
        unitCost: payload.data.unitCost,
        supplier: payload.data.supplier || null,
        expirationDate: payload.data.expirationDate ? parseDateInput(payload.data.expirationDate) : null,
        location: payload.data.location || null,
        sku: payload.data.sku || null,
        notes: payload.data.notes || null,
        userId: user.id,
      },
    });

    return NextResponse.json({ item }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel salvar o item." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao salvar o item." }, { status: 500 });
  }
}
