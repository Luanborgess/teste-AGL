import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { currentStock } from "@/lib/calculations";
import { getStockTotals } from "@/lib/dashboard";
import { getPrisma } from "@/lib/prisma";
import { stockMovementSchema } from "@/lib/validations";

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = stockMovementSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json({ error: "Movimentação de estoque inválida." }, { status: 400 });
  }

  const totals = getStockTotals(user.stockMovements);
  const available = currentStock({
    initialStock: user.farmProfile?.initialStock,
    entries: totals.entries,
    exits: totals.exits,
  });

  if (payload.data.type === "OUT" && available !== null && payload.data.quantity > available) {
    return NextResponse.json(
      { error: "Saída maior que o saldo atual do estoque." },
      { status: 422 },
    );
  }

  await getPrisma().stockMovement.create({
    data: {
      ...payload.data,
      userId: user.id,
      date: new Date(payload.data.date),
    },
  });

  return NextResponse.json({ ok: true });
}
