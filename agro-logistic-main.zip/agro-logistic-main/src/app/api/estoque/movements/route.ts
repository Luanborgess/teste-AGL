import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { calculateNextBalance } from "@/lib/inventory-calculations";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { inventoryMovementSchema } from "@/lib/validations";

export async function GET() {
  const user = await requireProfile();

  const movements = await getPrisma().inventoryMovement.findMany({
    where: { userId: user.id },
    include: { item: { select: { name: true, unit: true } } },
    orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }],
  });

  return NextResponse.json({ movements });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = inventoryMovementSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Movimentacao de estoque invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const prisma = getPrisma();

  try {
    const result = await prisma.$transaction(async (tx) => {
      const item = await tx.inventoryItem.findFirst({
        where: { id: payload.data.itemId, userId: user.id },
      });

      if (!item) {
        throw new Error("ITEM_NOT_FOUND");
      }

      const decreasesStock = ["SAIDA", "CONSUMO", "PERDA"].includes(payload.data.type);

      if (decreasesStock && payload.data.quantity > item.quantity) {
        throw new Error("INSUFFICIENT_STOCK");
      }

      const nextBalance = calculateNextBalance(item.quantity, payload.data.type, payload.data.quantity);

      const movement = await tx.inventoryMovement.create({
        data: {
          itemId: item.id,
          type: payload.data.type,
          quantity: payload.data.quantity,
          unitCost: payload.data.unitCost ?? null,
          responsible: payload.data.responsible || null,
          originOrDestination: payload.data.originOrDestination || null,
          reason: payload.data.reason || null,
          notes: payload.data.notes || null,
          balanceAfter: nextBalance,
          occurredAt: parseDateInput(payload.data.date),
          userId: user.id,
        },
      });

      const updatedItem = await tx.inventoryItem.update({
        where: { id: item.id },
        data: {
          quantity: nextBalance,
          unitCost:
            payload.data.type === "ENTRADA" && typeof payload.data.unitCost === "number"
              ? payload.data.unitCost
              : item.unitCost,
        },
      });

      return { movement, item: updatedItem };
    });

    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "ITEM_NOT_FOUND") {
      return NextResponse.json({ error: "Item nao encontrado." }, { status: 404 });
    }

    if (error instanceof Error && error.message === "INSUFFICIENT_STOCK") {
      return NextResponse.json(
        { error: "Saldo insuficiente para registrar esta movimentacao." },
        { status: 422 },
      );
    }

    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel registrar a movimentacao." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao registrar a movimentacao." }, { status: 500 });
  }
}
