import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { buildFarmSummary } from "@/lib/farm-calculations";
import { getPrisma } from "@/lib/prisma";
import { farmSchema } from "@/lib/validations";

function farmInclude() {
  return {
    fields: {
      orderBy: [{ name: "asc" as const }],
    },
  };
}

function farmDataFromPayload(payload: ReturnType<typeof farmSchema.parse>) {
  return {
    name: payload.name,
    owner: payload.owner,
    city: payload.city,
    state: payload.state.toLocaleUpperCase("pt-BR"),
    totalArea: payload.totalArea,
    productionType: payload.productionType || null,
    coordinates: payload.coordinates || null,
    notes: payload.notes || null,
  };
}

export async function GET() {
  const user = await requireProfile();

  const farm = await getPrisma().farm.findUnique({
    where: { userId: user.id },
    include: farmInclude(),
  });

  return NextResponse.json({ farm, summary: farm ? buildFarmSummary(farm) : null });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const body = await request.json().catch(() => null);
  const payload = farmSchema.safeParse(body);

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Fazenda invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const existingFarm = await getPrisma().farm.findUnique({
    where: { userId: user.id },
    select: { id: true },
  });

  if (existingFarm) {
    return NextResponse.json(
      { error: "Esta conta ja possui uma fazenda cadastrada. Edite a fazenda existente." },
      { status: 409 },
    );
  }

  try {
    const farm = await getPrisma().farm.create({
      data: {
        ...farmDataFromPayload(payload.data),
        userId: user.id,
      },
      include: farmInclude(),
    });

    return NextResponse.json({ farm, summary: buildFarmSummary(farm) }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return NextResponse.json({ error: "Esta conta ja possui uma fazenda cadastrada." }, { status: 409 });
    }

    return NextResponse.json({ error: "Erro inesperado ao salvar a fazenda." }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  const user = await requireProfile();
  const body = await request.json().catch(() => null);
  const payload = farmSchema.safeParse(body);

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Fazenda invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const currentFarm = await getPrisma().farm.findUnique({
    where: { userId: user.id },
    include: { fields: true },
  });

  if (!currentFarm) {
    return NextResponse.json({ error: "Cadastre a fazenda antes de editar." }, { status: 404 });
  }

  const usedArea = currentFarm.fields.reduce((total, field) => total + field.area, 0);
  if (payload.data.totalArea < usedArea) {
    return NextResponse.json(
      {
        error: `A area total informada e menor que a soma dos talhoes (${usedArea.toLocaleString("pt-BR")} ha).`,
      },
      { status: 422 },
    );
  }

  const farm = await getPrisma().farm.update({
    where: { userId: user.id },
    data: farmDataFromPayload(payload.data),
    include: farmInclude(),
  });

  return NextResponse.json({ farm, summary: buildFarmSummary(farm) });
}
