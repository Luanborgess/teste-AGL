import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { canFitFieldArea } from "@/lib/farm-calculations";
import { getPrisma } from "@/lib/prisma";
import { fieldSchema, type FieldValues } from "@/lib/validations";

function fieldDataFromPayload(payload: FieldValues) {
  return {
    name: payload.name,
    area: payload.area,
    soilType: payload.soilType || null,
    currentCrop: payload.currentCrop || null,
    expectedProductivity: payload.expectedProductivity ?? null,
    status: payload.status,
    coordinates: payload.coordinates || null,
    notes: payload.notes || null,
  };
}

export async function GET() {
  const user = await requireProfile();

  const farm = await getPrisma().farm.findUnique({
    where: { userId: user.id },
    select: { id: true },
  });

  if (!farm) {
    return NextResponse.json({ error: "Cadastre a fazenda antes de listar talhoes." }, { status: 404 });
  }

  const fields = await getPrisma().field.findMany({
    where: { farmId: farm.id },
    orderBy: [{ name: "asc" }],
  });

  return NextResponse.json({ fields });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const body = await request.json().catch(() => null);
  const payload = fieldSchema.safeParse(body);

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Talhao invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const farm = await getPrisma().farm.findUnique({
    where: { userId: user.id },
    include: { fields: true },
  });

  if (!farm) {
    return NextResponse.json({ error: "Cadastre a fazenda antes de criar talhoes." }, { status: 404 });
  }

  if (!canFitFieldArea({ totalArea: farm.totalArea, fields: farm.fields, nextArea: payload.data.area })) {
    const usedArea = farm.fields.reduce((total, field) => total + field.area, 0);
    return NextResponse.json(
      {
        error: `A soma dos talhoes chegaria a ${(usedArea + payload.data.area).toLocaleString(
          "pt-BR",
        )} ha e ultrapassaria a area total da fazenda.`,
      },
      { status: 422 },
    );
  }

  try {
    const field = await getPrisma().field.create({
      data: {
        ...fieldDataFromPayload(payload.data),
        farmId: farm.id,
      },
    });

    return NextResponse.json({ field }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel salvar o talhao." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao salvar o talhao." }, { status: 500 });
  }
}
