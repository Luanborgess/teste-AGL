import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { canFitFieldArea } from "@/lib/farm-calculations";
import { getPrisma } from "@/lib/prisma";
import { fieldSchema, type FieldValues } from "@/lib/validations";

type FieldRouteContext = {
  params: Promise<{ id: string }>;
};

function fieldDataFromPayload(payload: FieldValues) {
  return {
    name: payload.name,
    area: payload.area,
    soilType: payload.soilType || null,
    currentCrop: payload.currentCrop || null,
    expectedProductivity: payload.expectedProductivity ?? null,
    status: payload.status,
    coordinates: payload.coordinates || null,
    notes: payload.notes || null,
  };
}

async function getUserFarm(userId: string) {
  return getPrisma().farm.findUnique({
    where: { userId },
    include: { fields: true },
  });
}

export async function GET(_request: Request, context: FieldRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const farm = await getUserFarm(user.id);

  if (!farm) {
    return NextResponse.json({ error: "Fazenda nao encontrada." }, { status: 404 });
  }

  const field = await getPrisma().field.findFirst({
    where: { id, farmId: farm.id },
  });

  if (!field) {
    return NextResponse.json({ error: "Talhao nao encontrado." }, { status: 404 });
  }

  return NextResponse.json({ field });
}

export async function PUT(request: Request, context: FieldRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const body = await request.json().catch(() => null);
  const payload = fieldSchema.safeParse(body);

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Talhao invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const farm = await getUserFarm(user.id);

  if (!farm) {
    return NextResponse.json({ error: "Fazenda nao encontrada." }, { status: 404 });
  }

  const existing = farm.fields.find((field) => field.id === id);

  if (!existing) {
    return NextResponse.json({ error: "Talhao nao encontrado." }, { status: 404 });
  }

  if (!canFitFieldArea({ totalArea: farm.totalArea, fields: farm.fields, nextArea: payload.data.area, ignoredFieldId: id })) {
    const usedArea = farm.fields.filter((field) => field.id !== id).reduce((total, field) => total + field.area, 0);
    return NextResponse.json(
      {
        error: `A soma dos talhoes chegaria a ${(usedArea + payload.data.area).toLocaleString(
          "pt-BR",
        )} ha e ultrapassaria a area total da fazenda.`,
      },
      { status: 422 },
    );
  }

  try {
    const field = await getPrisma().field.update({
      where: { id },
      data: fieldDataFromPayload(payload.data),
    });

    return NextResponse.json({ field });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel atualizar o talhao." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao atualizar o talhao." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, context: FieldRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const farm = await getUserFarm(user.id);

  if (!farm) {
    return NextResponse.json({ error: "Fazenda nao encontrada." }, { status: 404 });
  }

  const existing = farm.fields.find((field) => field.id === id);

  if (!existing) {
    return NextResponse.json({ error: "Talhao nao encontrado." }, { status: 404 });
  }

  await getPrisma().field.delete({
    where: { id },
  });

  return NextResponse.json({ ok: true });
}
