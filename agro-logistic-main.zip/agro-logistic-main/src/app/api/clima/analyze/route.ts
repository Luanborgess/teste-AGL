import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { analyzeWeatherRecommendations } from "@/lib/weather-ai";
import { getWeatherForUser, saveWeatherAnalysis } from "@/lib/weather-service";

export async function POST() {
  const user = await requireProfile();

  try {
    const result = await getWeatherForUser(user.id);

    if (result.status !== "READY" || !result.weather) {
      return NextResponse.json(result, { status: 404 });
    }

    const analysis = await analyzeWeatherRecommendations(result.weather);

    await saveWeatherAnalysis({
      snapshotUserId: user.id,
      farmId: result.weather.farm.id,
      aiSummary: analysis.recommendations as unknown as Prisma.InputJsonValue,
      riskLevel: analysis.recommendations.nivelRisco,
      agroScore: result.weather.agroScore.score,
    });

    return NextResponse.json({
      status: "READY",
      analysis: analysis.recommendations,
      source: analysis.source,
      warning: analysis.warning,
    });
  } catch {
    return NextResponse.json(
      {
        error: "Não foi possível gerar a análise climática. O clima atual continua disponível se já foi carregado.",
      },
      { status: 500 },
    );
  }
}
