import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { getWeatherForUser } from "@/lib/weather-service";

export async function GET() {
  const user = await requireProfile();

  try {
    const result = await getWeatherForUser(user.id);
    return NextResponse.json(result, { status: result.status === "READY" ? 200 : 404 });
  } catch {
    return NextResponse.json(
      {
        status: "MISSING_LOCATION",
        error: "Não foi possível buscar o clima real agora. Tente atualizar novamente em alguns minutos.",
      },
      { status: 502 },
    );
  }
}
