import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { getWeatherForUser } from "@/lib/weather-service";

export async function GET() {
  const user = await requireProfile();

  try {
    const result = await getWeatherForUser(user.id);

    if (result.status !== "READY" || !result.weather) {
      return NextResponse.json(result, { status: 404 });
    }

    return NextResponse.json({
      status: "READY",
      forecast: result.weather.forecast,
      location: result.weather.location,
      fetchedAt: result.weather.fetchedAt,
      fromCache: result.weather.fromCache,
    });
  } catch {
    return NextResponse.json({ error: "Não foi possível buscar a previsão real agora." }, { status: 502 });
  }
}
