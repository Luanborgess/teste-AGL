import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { getWeatherForUser } from "@/lib/weather-service";

export async function POST() {
  const user = await requireProfile();

  try {
    const result = await getWeatherForUser(user.id, true);
    return NextResponse.json(result, { status: result.status === "READY" ? 200 : 404 });
  } catch {
    return NextResponse.json(
      {
        error: "A API de clima está indisponível ou não retornou dados válidos. Nenhuma previsão foi inventada.",
      },
      { status: 502 },
    );
  }
}
