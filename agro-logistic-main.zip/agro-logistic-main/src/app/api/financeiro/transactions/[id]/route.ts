import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { transactionSchema } from "@/lib/validations";

type TransactionRouteContext = {
  params: Promise<{ id: string }>;
};

export async function GET(_request: Request, context: TransactionRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const transaction = await getPrisma().transaction.findFirst({
    where: { id, userId: user.id },
  });

  if (!transaction) {
    return NextResponse.json({ error: "Transacao nao encontrada." }, { status: 404 });
  }

  return NextResponse.json({ transaction });
}

export async function PUT(request: Request, context: TransactionRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const payload = transactionSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Transacao financeira invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const existing = await getPrisma().transaction.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Transacao nao encontrada." }, { status: 404 });
  }

  try {
    const transaction = await getPrisma().transaction.update({
      where: { id },
      data: {
        description: payload.data.description,
        amount: payload.data.amount,
        category: payload.data.category,
        type: payload.data.type,
        notes: payload.data.notes || null,
        date: parseDateInput(payload.data.date),
      },
    });

    return NextResponse.json({ transaction });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel atualizar a transacao." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao atualizar a transacao." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, context: TransactionRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const existing = await getPrisma().transaction.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Transacao nao encontrada." }, { status: 404 });
  }

  await getPrisma().transaction.delete({
    where: { id },
  });

  return NextResponse.json({ ok: true });
}
