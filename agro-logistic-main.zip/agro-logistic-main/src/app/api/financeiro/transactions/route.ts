import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { transactionSchema } from "@/lib/validations";

export async function GET() {
  const user = await requireProfile();

  const transactions = await getPrisma().transaction.findMany({
    where: { userId: user.id },
    orderBy: { date: "desc" },
  });

  return NextResponse.json({ transactions });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = transactionSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Transacao financeira invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  try {
    const transaction = await getPrisma().transaction.create({
      data: {
        description: payload.data.description,
        amount: payload.data.amount,
        category: payload.data.category,
        type: payload.data.type,
        notes: payload.data.notes || null,
        date: parseDateInput(payload.data.date),
        userId: user.id,
      },
    });

    return NextResponse.json({ transaction }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel salvar a transacao." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao salvar a transacao." }, { status: 500 });
  }
}
