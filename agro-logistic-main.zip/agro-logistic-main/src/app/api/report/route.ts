import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { getDashboardData } from "@/lib/dashboard";
import {
  formatCurrency,
  formatInteger,
  formatNumber,
  formatPercent,
} from "@/lib/formatters";

export async function GET() {
  const user = await requireProfile();
  const dashboard = getDashboardData(
    user.farmProfile,
    user.financialEntries,
    user.stockMovements,
    user.shipments,
  );
  const metrics = dashboard.operationalMetrics;

  return NextResponse.json({
    farm: user.farmProfile?.farmName,
    responsible: user.farmProfile?.responsible,
    crop: user.farmProfile?.mainCrop,
    city: user.farmProfile?.city,
    state: user.farmProfile?.state,
    metrics: {
      production: formatNumber(metrics?.production, " sacas"),
      revenue: formatCurrency(metrics?.revenue),
      profit: formatCurrency(metrics?.profit),
      margin: formatPercent(metrics?.margin),
      loads: formatInteger(metrics?.loads),
      monthsToShip: formatNumber(metrics?.monthsToShip, " meses"),
      costPerHectare: formatCurrency(metrics?.costPerHectare),
      costPerUnit: formatCurrency(metrics?.costPerUnit),
      stock: formatNumber(dashboard.stock, " sacas"),
    },
  });
}
