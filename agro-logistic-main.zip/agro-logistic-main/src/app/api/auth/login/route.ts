import { NextResponse } from "next/server";
import { setSession } from "@/lib/auth";
import { getPrisma } from "@/lib/prisma";
import { loginSchema } from "@/lib/validations";

export async function POST(request: Request) {
  const payload = loginSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json({ error: "Dados de login inválidos." }, { status: 400 });
  }

  const user = await getPrisma().user.upsert({
    where: { email: payload.data.email.toLowerCase() },
    update: { name: payload.data.name },
    create: {
      name: payload.data.name,
      email: payload.data.email.toLowerCase(),
    },
  });

  await setSession(user.id);

  return NextResponse.json({ ok: true, hasProfile: false });
}
