import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { onlyDigits } from "@/lib/formatters";
import { getPrisma } from "@/lib/prisma";
import { employeeSchema } from "@/lib/validations";

type EmployeeRouteContext = {
  params: Promise<{ id: string }>;
};

function nullableText(value: string | undefined) {
  const text = value?.trim();
  return text ? text : null;
}

function includeEmployeeDetails() {
  return {
    attendances: { orderBy: [{ date: "desc" as const }, { createdAt: "desc" as const }] },
    assignments: {
      include: {
        assignment: {
          include: {
            members: {
              include: { employee: { select: { fullName: true, role: true, salary: true } } },
              orderBy: { createdAt: "asc" as const },
            },
          },
        },
      },
      orderBy: { createdAt: "desc" as const },
    },
    salaryHistory: { orderBy: { changedAt: "desc" as const } },
  };
}

export async function GET(_request: Request, context: EmployeeRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const employee = await getPrisma().employee.findFirst({
    where: { id, userId: user.id },
    include: includeEmployeeDetails(),
  });

  if (!employee) {
    return NextResponse.json({ error: "Funcionario nao encontrado." }, { status: 404 });
  }

  return NextResponse.json({ employee });
}

export async function PUT(request: Request, context: EmployeeRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const payload = employeeSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Funcionario invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const existing = await getPrisma().employee.findFirst({
    where: { id, userId: user.id },
    select: { id: true, salary: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Funcionario nao encontrado." }, { status: 404 });
  }

  try {
    const employee = await getPrisma().$transaction(async (tx) => {
      const updated = await tx.employee.update({
        where: { id },
        data: {
          fullName: payload.data.fullName,
          cpf: onlyDigits(payload.data.cpf),
          phone: payload.data.phone,
          email: nullableText(payload.data.email),
          role: payload.data.role,
          department: nullableText(payload.data.department),
          salary: payload.data.salary,
          status: payload.data.status,
          admissionDate: parseDateInput(payload.data.admissionDate),
          address: nullableText(payload.data.address),
          emergencyContact: nullableText(payload.data.emergencyContact),
          notes: nullableText(payload.data.notes),
        },
        include: includeEmployeeDetails(),
      });

      if (existing.salary !== payload.data.salary) {
        await tx.employeeSalaryHistory.create({
          data: {
            employeeId: id,
            oldSalary: existing.salary,
            newSalary: payload.data.salary,
            reason: nullableText(payload.data.salaryChangeReason),
            userId: user.id,
          },
        });
      }

      return updated;
    });

    return NextResponse.json({ employee });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return NextResponse.json({ error: "Ja existe um funcionario com este CPF." }, { status: 409 });
    }

    return NextResponse.json({ error: "Erro inesperado ao atualizar o funcionario." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, context: EmployeeRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const existing = await getPrisma().employee.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Funcionario nao encontrado." }, { status: 404 });
  }

  await getPrisma().employee.delete({ where: { id } });

  return NextResponse.json({ ok: true });
}
