import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { onlyDigits } from "@/lib/formatters";
import { getPrisma } from "@/lib/prisma";
import { employeeSchema } from "@/lib/validations";

function nullableText(value: string | undefined) {
  const text = value?.trim();
  return text ? text : null;
}

export async function GET() {
  const user = await requireProfile();

  const employees = await getPrisma().employee.findMany({
    where: { userId: user.id },
    include: {
      attendances: { orderBy: [{ date: "desc" }, { createdAt: "desc" }] },
      assignments: {
        include: {
          assignment: {
            include: {
              members: {
                include: { employee: { select: { fullName: true, role: true, salary: true } } },
                orderBy: { createdAt: "asc" },
              },
            },
          },
        },
        orderBy: { createdAt: "desc" },
      },
      salaryHistory: { orderBy: { changedAt: "desc" } },
    },
    orderBy: [{ updatedAt: "desc" }, { fullName: "asc" }],
  });

  return NextResponse.json({ employees });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = employeeSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Funcionario invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  try {
    const employee = await getPrisma().employee.create({
      data: {
        fullName: payload.data.fullName,
        cpf: onlyDigits(payload.data.cpf),
        phone: payload.data.phone,
        email: nullableText(payload.data.email),
        role: payload.data.role,
        department: nullableText(payload.data.department),
        salary: payload.data.salary,
        status: payload.data.status,
        admissionDate: parseDateInput(payload.data.admissionDate),
        address: nullableText(payload.data.address),
        emergencyContact: nullableText(payload.data.emergencyContact),
        notes: nullableText(payload.data.notes),
        userId: user.id,
      },
    });

    return NextResponse.json({ employee }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return NextResponse.json({ error: "Ja existe um funcionario com este CPF." }, { status: 409 });
    }

    return NextResponse.json({ error: "Erro inesperado ao salvar o funcionario." }, { status: 500 });
  }
}
