import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { employeeAttendanceSchema } from "@/lib/validations";

function parseTimeOnDate(dateInput: string, timeInput: string | undefined) {
  if (!timeInput) {
    return null;
  }

  return new Date(`${dateInput}T${timeInput}:00`);
}

export async function GET() {
  const user = await requireProfile();

  const attendances = await getPrisma().employeeAttendance.findMany({
    where: { userId: user.id },
    include: { employee: { select: { fullName: true } } },
    orderBy: [{ date: "desc" }, { createdAt: "desc" }],
  });

  return NextResponse.json({ attendances });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = employeeAttendanceSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Registro de presenca invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const employee = await getPrisma().employee.findFirst({
    where: { id: payload.data.employeeId, userId: user.id },
    select: { id: true },
  });

  if (!employee) {
    return NextResponse.json({ error: "Funcionario nao encontrado." }, { status: 404 });
  }

  const date = parseDateInput(payload.data.date);
  const attendance = await getPrisma().employeeAttendance.upsert({
    where: {
      employeeId_date: {
        employeeId: payload.data.employeeId,
        date,
      },
    },
    create: {
      employeeId: payload.data.employeeId,
      date,
      status: payload.data.status,
      checkIn: parseTimeOnDate(payload.data.date, payload.data.checkIn),
      checkOut: parseTimeOnDate(payload.data.date, payload.data.checkOut),
      notes: payload.data.notes || null,
      userId: user.id,
    },
    update: {
      status: payload.data.status,
      checkIn: parseTimeOnDate(payload.data.date, payload.data.checkIn),
      checkOut: parseTimeOnDate(payload.data.date, payload.data.checkOut),
      notes: payload.data.notes || null,
    },
    include: { employee: { select: { fullName: true } } },
  });

  return NextResponse.json({ attendance }, { status: 201 });
}
