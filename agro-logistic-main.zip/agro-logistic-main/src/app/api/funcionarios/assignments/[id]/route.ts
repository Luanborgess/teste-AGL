import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { teamAssignmentSchema } from "@/lib/validations";

type AssignmentRouteContext = {
  params: Promise<{ id: string }>;
};

function nullableText(value: string | undefined) {
  const text = value?.trim();
  return text ? text : null;
}

function parseTimeOnDate(dateInput: string, timeInput: string | undefined) {
  if (!timeInput) {
    return null;
  }

  return new Date(`${dateInput}T${timeInput}:00`);
}

function includeAssignmentDetails() {
  return {
    members: {
      include: { employee: { select: { fullName: true, role: true, salary: true } } },
      orderBy: { createdAt: "asc" as const },
    },
  };
}

export async function PUT(request: Request, context: AssignmentRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const payload = teamAssignmentSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Alocacao invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const existing = await getPrisma().teamAssignment.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Alocacao nao encontrada." }, { status: 404 });
  }

  const employeeIds = [...new Set(payload.data.employeeIds)];
  const employees = await getPrisma().employee.findMany({
    where: { id: { in: employeeIds }, userId: user.id },
    select: { id: true },
  });

  if (employees.length !== employeeIds.length) {
    return NextResponse.json({ error: "Selecione apenas funcionarios cadastrados neste usuario." }, { status: 400 });
  }

  const assignment = await getPrisma().$transaction(async (tx) => {
    await tx.teamAssignmentMember.deleteMany({ where: { assignmentId: id } });

    return tx.teamAssignment.update({
      where: { id },
      data: {
        activity: payload.data.activity,
        location: payload.data.location,
        date: parseDateInput(payload.data.date),
        startTime: parseTimeOnDate(payload.data.date, payload.data.startTime),
        endTime: parseTimeOnDate(payload.data.date, payload.data.endTime),
        transport: nullableText(payload.data.transport),
        vehicle: nullableText(payload.data.vehicle),
        driver: nullableText(payload.data.driver),
        status: payload.data.status,
        notes: nullableText(payload.data.notes),
        members: {
          create: employeeIds.map((employeeId) => ({ employeeId })),
        },
      },
      include: includeAssignmentDetails(),
    });
  });

  return NextResponse.json({ assignment });
}

export async function DELETE(_request: Request, context: AssignmentRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const existing = await getPrisma().teamAssignment.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Alocacao nao encontrada." }, { status: 404 });
  }

  await getPrisma().teamAssignment.delete({ where: { id } });

  return NextResponse.json({ ok: true });
}
