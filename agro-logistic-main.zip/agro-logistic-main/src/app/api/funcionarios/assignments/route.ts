import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { teamAssignmentSchema } from "@/lib/validations";

function nullableText(value: string | undefined) {
  const text = value?.trim();
  return text ? text : null;
}

function parseTimeOnDate(dateInput: string, timeInput: string | undefined) {
  if (!timeInput) {
    return null;
  }

  return new Date(`${dateInput}T${timeInput}:00`);
}

function includeAssignmentDetails() {
  return {
    members: {
      include: { employee: { select: { fullName: true, role: true, salary: true } } },
      orderBy: { createdAt: "asc" as const },
    },
  };
}

export async function GET() {
  const user = await requireProfile();

  const assignments = await getPrisma().teamAssignment.findMany({
    where: { userId: user.id },
    include: includeAssignmentDetails(),
    orderBy: [{ date: "desc" }, { createdAt: "desc" }],
  });

  return NextResponse.json({ assignments });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = teamAssignmentSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Alocacao invalida.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const employees = await getPrisma().employee.findMany({
    where: { id: { in: payload.data.employeeIds }, userId: user.id },
    select: { id: true },
  });

  if (employees.length !== new Set(payload.data.employeeIds).size) {
    return NextResponse.json({ error: "Selecione apenas funcionarios cadastrados neste usuario." }, { status: 400 });
  }

  const assignment = await getPrisma().teamAssignment.create({
    data: {
      activity: payload.data.activity,
      location: payload.data.location,
      date: parseDateInput(payload.data.date),
      startTime: parseTimeOnDate(payload.data.date, payload.data.startTime),
      endTime: parseTimeOnDate(payload.data.date, payload.data.endTime),
      transport: nullableText(payload.data.transport),
      vehicle: nullableText(payload.data.vehicle),
      driver: nullableText(payload.data.driver),
      status: payload.data.status,
      notes: nullableText(payload.data.notes),
      userId: user.id,
      members: {
        create: [...new Set(payload.data.employeeIds)].map((employeeId) => ({ employeeId })),
      },
    },
    include: includeAssignmentDetails(),
  });

  return NextResponse.json({ assignment }, { status: 201 });
}
