import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { cropSchema } from "@/lib/validations";

export async function GET() {
  const user = await requireProfile();

  const crops = await getPrisma().crop.findMany({
    where: { userId: user.id },
    orderBy: [{ expectedHarvestDate: "asc" }, { plantingDate: "desc" }],
  });

  return NextResponse.json({ crops });
}

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = cropSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Cultivo invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  try {
    const crop = await getPrisma().crop.create({
      data: {
        name: payload.data.name,
        variety: payload.data.variety || null,
        plantedArea: payload.data.plantedArea,
        plantingDate: parseDateInput(payload.data.plantingDate),
        expectedHarvestDate: parseDateInput(payload.data.expectedHarvestDate),
        expectedProduction: payload.data.expectedProduction,
        harvestedProduction: payload.data.harvestedProduction,
        status: payload.data.status,
        notes: payload.data.notes || null,
        userId: user.id,
      },
    });

    return NextResponse.json({ crop }, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel salvar o cultivo." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao salvar o cultivo." }, { status: 500 });
  }
}
