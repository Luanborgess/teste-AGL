import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { parseDateInput } from "@/lib/dates";
import { getPrisma } from "@/lib/prisma";
import { cropSchema } from "@/lib/validations";

type CropRouteContext = {
  params: Promise<{ id: string }>;
};

export async function GET(_request: Request, context: CropRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const crop = await getPrisma().crop.findFirst({
    where: { id, userId: user.id },
  });

  if (!crop) {
    return NextResponse.json({ error: "Cultivo nao encontrado." }, { status: 404 });
  }

  return NextResponse.json({ crop });
}

export async function PUT(request: Request, context: CropRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;
  const payload = cropSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json(
      {
        error: "Cultivo invalido.",
        issues: payload.error.flatten().fieldErrors,
      },
      { status: 400 },
    );
  }

  const existing = await getPrisma().crop.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Cultivo nao encontrado." }, { status: 404 });
  }

  try {
    const crop = await getPrisma().crop.update({
      where: { id },
      data: {
        name: payload.data.name,
        variety: payload.data.variety || null,
        plantedArea: payload.data.plantedArea,
        plantingDate: parseDateInput(payload.data.plantingDate),
        expectedHarvestDate: parseDateInput(payload.data.expectedHarvestDate),
        expectedProduction: payload.data.expectedProduction,
        harvestedProduction: payload.data.harvestedProduction,
        status: payload.data.status,
        notes: payload.data.notes || null,
      },
    });

    return NextResponse.json({ crop });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      return NextResponse.json({ error: "Nao foi possivel atualizar o cultivo." }, { status: 400 });
    }

    return NextResponse.json({ error: "Erro inesperado ao atualizar o cultivo." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, context: CropRouteContext) {
  const user = await requireProfile();
  const { id } = await context.params;

  const existing = await getPrisma().crop.findFirst({
    where: { id, userId: user.id },
    select: { id: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Cultivo nao encontrado." }, { status: 404 });
  }

  await getPrisma().crop.delete({
    where: { id },
  });

  return NextResponse.json({ ok: true });
}
