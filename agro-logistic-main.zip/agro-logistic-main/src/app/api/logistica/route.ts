import { NextResponse } from "next/server";
import { requireProfile } from "@/lib/auth";
import { getPrisma } from "@/lib/prisma";
import { shipmentSchema } from "@/lib/validations";

export async function POST(request: Request) {
  const user = await requireProfile();
  const payload = shipmentSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json({ error: "Embarque inválido." }, { status: 400 });
  }

  await getPrisma().shipment.create({
    data: {
      ...payload.data,
      userId: user.id,
      date: new Date(payload.data.date),
    },
  });

  return NextResponse.json({ ok: true });
}
