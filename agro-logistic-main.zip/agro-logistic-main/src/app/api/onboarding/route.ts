import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { getPrisma } from "@/lib/prisma";
import { farmProfileSchema } from "@/lib/validations";

export async function POST(request: Request) {
  const user = await requireUser();
  const payload = farmProfileSchema.safeParse(await request.json());

  if (!payload.success) {
    return NextResponse.json({ error: "Perfil operacional inválido." }, { status: 400 });
  }

  await getPrisma().farmProfile.upsert({
    where: { userId: user.id },
    update: payload.data,
    create: {
      ...payload.data,
      userId: user.id,
    },
  });

  return NextResponse.json({ ok: true });
}
