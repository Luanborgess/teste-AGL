import { Route, Truck, WalletCards } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { StatCard } from "@/components/dashboard/stat-card";
import { ShipmentForm } from "@/components/forms/shipment-form";
import { AppShell } from "@/components/layout/app-shell";
import { estimatedProduction } from "@/lib/calculations";
import { getDashboardData } from "@/lib/dashboard";
import { formatCurrency, formatDate, formatNumber, formatPercent } from "@/lib/formatters";
import { requireProfile } from "@/lib/auth";

const statusLabels = {
  PLANNED: "Planejado",
  IN_TRANSIT: "Em trânsito",
  DELIVERED: "Entregue",
  DELAYED: "Atrasado",
  CANCELED: "Cancelado",
};

export default async function LogisticaPage() {
  const user = await requireProfile();
  const profile = user.farmProfile;
  const data = getDashboardData(profile, user.financialEntries, user.stockMovements, user.shipments);
  const production = estimatedProduction(profile ?? {});
  const shippedShare = production ? data.shipmentTotals.volume / production : null;

  return (
    <AppShell title="Logística" subtitle="Embarques, cargas, status e custo de frete.">
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-3">
          <StatCard label="Volume embarcado" value={formatNumber(data.shipmentTotals.volume, " sacas")} helper="Embarques não cancelados." icon={Truck} tone="good" />
          <StatCard label="Produção embarcada" value={formatPercent(shippedShare)} helper="Comparação com produção estimada." icon={Route} />
          <StatCard label="Frete total" value={formatCurrency(data.shipmentTotals.freight)} helper="Soma de custos de frete registrados." icon={WalletCards} />
        </div>

        <Card className="rounded-md bg-card/82">
          <CardHeader>
            <CardTitle>Novo embarque</CardTitle>
          </CardHeader>
          <CardContent>
            <ShipmentForm />
          </CardContent>
        </Card>

        <Card className="rounded-md bg-card/82">
          <CardHeader>
            <CardTitle>Embarques</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Origem</TableHead>
                  <TableHead>Destino</TableHead>
                  <TableHead>Transportadora</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Volume</TableHead>
                  <TableHead className="text-right">Frete</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {user.shipments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-muted-foreground">
                      Nenhum embarque criado.
                    </TableCell>
                  </TableRow>
                ) : (
                  user.shipments.map((shipment) => (
                    <TableRow key={shipment.id}>
                      <TableCell>{formatDate(shipment.date)}</TableCell>
                      <TableCell>{shipment.origin}</TableCell>
                      <TableCell>{shipment.destination}</TableCell>
                      <TableCell>{shipment.carrier}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{statusLabels[shipment.status]}</Badge>
                      </TableCell>
                      <TableCell className="text-right">{formatNumber(shipment.volume, " sacas")}</TableCell>
                      <TableCell className="text-right">{formatCurrency(shipment.freightCost)}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
